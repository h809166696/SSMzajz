//
//  userManager.m
//  yuanZhengTong
//
//  Created by jack on 2017/10/21.
//  Copyright © 2017年 tianyixin. All rights reserved.
//

#import "userManager.h"

@implementation userManager
+(void)userMessageWriteToFile:(UserMessageModel *)model{
    model.userImage = [UIImage imageWithData:[NSData dataWithContentsOfURL:PingJieImageUrl(model.avatar)]];
    [NSKeyedArchiver archiveRootObject:model toFile:WLZUserInfoFilePath];
}
+(void)writeToToken:(NSDictionary *)token{
    NSUserDefaults *userDeafault =  [NSUserDefaults standardUserDefaults];
    [userDeafault setObject:token forKey:WLZTokenKey];
    [userDeafault synchronize];
}
+(NSString *)getUserToken{
    @try {
        NSUserDefaults *userDeafault =  [NSUserDefaults standardUserDefaults];
        NSDictionary *tokenDic = [userDeafault objectForKey:WLZTokenKey];
        
        NSLog(@"地址为+==%@",NSHomeDirectory());
        NSString *tokenDate = tokenDic[@"expired_at"];
        if ([tokenDate judgeWithNow] == 1) {
            return tokenDic[@"token"];
        }else
        {
            return nil;
        }
    } @catch (NSException *exception) {
        return  nil;
    } @finally {
        
    }
    return nil;
   
}
+(UserMessageModel *)getUserModel{
    UserMessageModel *model = [NSKeyedUnarchiver unarchiveObjectWithFile:WLZUserInfoFilePath];
    return model;
}
+(void)logOut{
    NSUserDefaults *userDeafault =  [NSUserDefaults standardUserDefaults];
    [userDeafault setObject:nil forKey:WLZTokenKey];
    [userDeafault synchronize];
}
@end
