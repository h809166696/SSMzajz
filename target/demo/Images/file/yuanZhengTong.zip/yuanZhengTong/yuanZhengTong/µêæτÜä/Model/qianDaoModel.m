//
//  qianDaoModel.m
//  yuanZhengTong
//
//  Created by jack on 2017/10/22.
//  Copyright © 2017年 tianyixin. All rights reserved.
//

#import "qianDaoModel.h"

@implementation qianDaoModel
+ (NSDictionary *)objectClassInArray{
    return @{
             @"sign_in_con_point" : [signPointModel class]};
}
+(void)getUserQianDaoModelWithToken:(NSString *)token SUCB:(signModelSUCB)sucb Fail:(signModelFAIL)faiB{
    [HJHTTPManager requestWithType:SkyHttpRequestTypeGet UrlString:[TRUEURLHEAD addStr:@"user_sign_in_data"] Parameters:@{@"token":token} SuccessBlock:^(id responseObject) {
        NSData *data = [responseObject dataUsingEncoding:NSUTF8StringEncoding];
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
        NSLog(@"---%@",dic);
        if ([[NSString stringWithFormat:@"%@",dic[@"code"]] isEqualToString:@"0"]) {
            qianDaoModel *model = [qianDaoModel mj_objectWithKeyValues:dic[@"data"]];
            sucb(model);
        }else
        {
            faiB(nil,dic[@"msg"]);
        }
    } FailureBlock:^(NSError *error) {
        faiB(error,@"请求失败");
    }];
}
+(void)userSignWithToken:(NSString *)token SUCB:(signModelSUCB)sucb Fail:(signModelFAIL)faiB{
    [HJHTTPManager requestWithType:SkyHttpRequestTypePost UrlString:[TRUEURLHEAD addStr:@"user_sign_in"] Parameters:@{@"token":token} SuccessBlock:^(id responseObject) {
//        NSData *data = [responseObject dataUsingEncoding:NSUTF8StringEncoding];
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
        if ([[NSString stringWithFormat:@"%@",dic[@"code"]] isEqualToString:@"0"]) {
            qianDaoModel *model = [qianDaoModel mj_objectWithKeyValues:dic[@"data"]];
            sucb(model);
        }else
        {
            faiB(nil,dic[@"msg"]);
        }
    } FailureBlock:^(NSError *error) {
        faiB(error,@"请求失败");
    }];
}
@end
@implementation signPointModel

@end
