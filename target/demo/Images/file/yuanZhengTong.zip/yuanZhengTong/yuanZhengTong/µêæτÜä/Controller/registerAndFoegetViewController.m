//
//  registerAndFoegetViewController.m
//  yuanZhengTong
//
//  Created by jack on 2017/10/21.
//  Copyright © 2017年 tianyixin. All rights reserved.
//

#import "registerAndFoegetViewController.h"
#import "resgisterModel.h"
@interface registerAndFoegetViewController ()
@property (strong, nonatomic) IBOutlet UILabel *naviTitleLabel;
@property (strong, nonatomic) IBOutlet UITextField *phoneTextField;
@property (strong, nonatomic) IBOutlet UITextField *codeTextField;
@property (strong, nonatomic) IBOutlet UITextField *passwordTextField;
@property (strong, nonatomic) IBOutlet UITextField *surePasswordTextField;
@property (strong, nonatomic) IBOutlet UIButton *registerAndResetButton;
@property (strong, nonatomic) IBOutlet UIButton *getCodeButton;
@property (strong, nonatomic) IBOutlet UIView *TitleView;
@property (nonatomic,strong)NSTimer         *timer;
@property (nonatomic,assign)int            count;

@end

@implementation registerAndFoegetViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.phoneTextField becomeFirstResponder];
    _count = 60;
    skyViewBorderRadius(self.getCodeButton, 5, 0, [UIColor clearColor]);
    skyViewBorderRadius(self.registerAndResetButton, 10, 0, [UIColor clearColor]);
    if (self.isRegister) {
        self.naviTitleLabel.text = @"注册";
        [self.registerAndResetButton setTitle:@"注册" forState:UIControlStateNormal];
    }else
    {
        self.naviTitleLabel.text = @"忘记密码";
        [self.registerAndResetButton setTitle:@"重置密码" forState:UIControlStateNormal];
    }
    if (iPhoneX) {
        [self.TitleView mas_updateConstraints:^(MASConstraintMaker *make) {
            make.height.mas_equalTo(@(NAVIGATION_BAR_HEIGHT));
        }];
    }
    // Do any additional setup after loading the view from its nib.
}
-(void)dealloc{
    
    [self.timer invalidate];
    self.timer = nil;
}
- (IBAction)backButtonClick:(UIButton *)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}
- (IBAction)resgisterClick:(UIButton *)sender {
    NSString *alertSttr = @"";
    if (skyStringIsEmpty(self.codeTextField.text) || skyStringIsEmpty(self.phoneTextField.text) ||skyStringIsEmpty(self.passwordTextField.text)||skyStringIsEmpty(self.surePasswordTextField.text)) {
        alertSttr = @"填写不能为空";
    }
    if (![self.phoneTextField.text checkPhoneNumInput]) {
        alertSttr = @"不是正确的手机号";
    }
    if (![self.passwordTextField.text isEqualToString:self.surePasswordTextField.text]) {
        alertSttr = @"两次密码不一致";
    }
//    if (self.passwordTextField.text.length < 6 || [self.passwordTextField.text i]) {
//        <#statements#>
//    }
    if (!skyStringIsEmpty(alertSttr)) {
        [self showAlertWithTitle:@"温馨提示" message:alertSttr handler:^(UIAlertAction *action) {
            
        }];
    }else{
         WS(weakSelf);
    if (_isRegister) {
        [SVProgressHUD show];
        [resgisterModel registerUser:self.phoneTextField.text password:self.passwordTextField.text verifyCode:self.codeTextField.text suc:^(NSString *code) {
            
            if ([code isEqualToString:@"0"]) {
                [SVProgressHUD showInfoWithStatus:@"注册成功"];
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.8 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    [SVProgressHUD dismiss];
                });
                [weakSelf dismissViewControllerAnimated:YES completion:nil];
            }else
            {
                [SVProgressHUD showErrorWithStatus:@"注册失败"];
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    [SVProgressHUD dismiss];
                });
            }
        } Fail:^(NSError *error) {
            [SVProgressHUD showErrorWithStatus:@"请求失败,请稍后再试"];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [SVProgressHUD dismiss];
            });
        }];
    }else{
         [SVProgressHUD show];
        [resgisterModel resetPssword:self.phoneTextField.text password:self.passwordTextField.text verifyCode:self.codeTextField.text suc:^(NSString *code) {
            if ([code isEqualToString:@"0"]) {
                [SVProgressHUD showInfoWithStatus:@"重置密码成功成功"];
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.8 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    [SVProgressHUD dismiss];
                });
                [weakSelf dismissViewControllerAnimated:YES completion:nil];
            }else
            {
                [SVProgressHUD showErrorWithStatus:@"重置密码失败"];
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    [SVProgressHUD dismiss];
                });
            }
        } Fail:^(NSError *error) {
            [SVProgressHUD showErrorWithStatus:@"请求失败,请稍后再试"];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [SVProgressHUD dismiss];
            });
        }];
    }
    }
}
- (IBAction)getCodeButtonClick:(UIButton *)sender {
    if (![self.phoneTextField.text checkPhoneNumInput]) {
        [self showAlertWithTitle:@"温馨提示" message:@"不是正确的手机号" handler:^(UIAlertAction *action) {
            
        }];
    }else
    {
          self.getCodeButton.enabled = NO;
        [self getverfiCode];
      
        self.count = 60;
        self.timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(timeRun) userInfo:nil repeats:YES];
        [self.timer fire];
    }
}
#pragma makr--获取验证码
-(void)getverfiCode{
    NSLog(@"进入获取验证码界面");
    [resgisterModel registerGetCode:self.phoneTextField.text isResgister:_isRegister suc:^(NSString *code) {
        if ([code isEqualToString:@"0"]) {
            [SVProgressHUD showInfoWithStatus:@"验证码已发送"];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.8 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [SVProgressHUD dismiss];
            });
        }else if([code isEqualToString:@"8207"]){
            [SVProgressHUD showErrorWithStatus:@"手机号已存在"];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [SVProgressHUD dismiss];
            });
        }else{
             [self resetCodeButton];
            [SVProgressHUD showErrorWithStatus:@"验证码发送失败"];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [SVProgressHUD dismiss];
            });
        }
    } Fail:^(NSError *error) {
         [self resetCodeButton];
        [SVProgressHUD showErrorWithStatus:@"验证码发送失败"];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [SVProgressHUD dismiss];
        });
    }];
}

#pragma mark---定时器开启
-(void)timeRun{
    _count  = _count - 1;
    [self.getCodeButton setTitle:[NSString stringWithFormat:@"%d秒",_count] forState:UIControlStateNormal];
    if (_count  <= 0) {
        [self resetCodeButton];
    }
}
-(void)resetCodeButton{
    [_timer invalidate];
    [self.getCodeButton setTitle:@"获取验证码" forState:UIControlStateNormal];
    self.getCodeButton.enabled = YES;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
