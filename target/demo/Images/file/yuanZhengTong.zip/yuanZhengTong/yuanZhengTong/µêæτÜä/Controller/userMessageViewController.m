//
//  userMessageViewController.m
//  yuanZhengTong
//
//  Created by jack on 2017/10/22.
//  Copyright © 2017年 tianyixin. All rights reserved.
//

#import "userMessageViewController.h"
#import "userManager.h"
#import "UserModel.h"
#import "userMessageTableViewCell.h"
#import "changeSexViewController.h"
#import "changeHeadImgViewController.h"
#import "changeNickNameViewController.h"
@interface userMessageViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic,strong)UITableView *usermessageTableView;
@property (nonatomic,strong)UserMessageModel *userModle;
@end

@implementation userMessageViewController
static NSString *ceereuse = @"cell";
-(UITableView *)usermessageTableView
{
    if (_usermessageTableView == nil) {
        _usermessageTableView  = [[UITableView alloc]initWithFrame:[UIScreen mainScreen].bounds style:UITableViewStylePlain];
        _usermessageTableView.delegate = self;
        _usermessageTableView.dataSource  = self;
        [_usermessageTableView registerNib:[UINib nibWithNibName:@"userMessageTableViewCell" bundle:nil] forCellReuseIdentifier:ceereuse];
        _usermessageTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        [self.view addSubview:_usermessageTableView];
    }
    return _usermessageTableView;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self getUserData];
    self.view.backgroundColor = [UIColor whiteColor];
    self.title = @"我的资料";
    // Do any additional setup after loading the view.
}
#pragma mark---获取用户数据
-(void)getUserData{
    [SVProgressHUD show];
    WS(weakSelf);
    NSString *token = [userManager getUserToken];
    [HJHTTPManager requestWithType:SkyHttpRequestTypeGet UrlString:[TRUEURLHEAD addStr:@"user_info"] Parameters:@{@"token":token} SuccessBlock:^(id responseObject) {
        @try {
            NSData *data = [responseObject dataUsingEncoding:NSUTF8StringEncoding];
            NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
            if ([[NSString stringWithFormat:@"%@",dic[@"code"]] isEqualToString:@"0"]) {
                weakSelf.userModle = [UserMessageModel mj_objectWithKeyValues:dic[@"data"]];
                [userManager userMessageWriteToFile:weakSelf.userModle];
                [weakSelf.usermessageTableView reloadData];
                [SVProgressHUD dismiss];
            }else
            {
                [weakSelf showErrorMessage2WithMessage:dic[@"msg"]];
            }
        } @catch (NSException *exception) {
            [weakSelf showErrorMessage];
        } @finally {
            
        }
    } FailureBlock:^(NSError *error) {
        [weakSelf showErrorMessage];
    }];
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 3;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    userMessageTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:ceereuse forIndexPath:indexPath];
    if (indexPath.row == 0) {
        cell.namneLabel.text = @"头像";
        cell.messageLabel.hidden = YES;
        cell.rightImageWidth.constant = 50;
        cell.rightImageHeight.constant = 50;
        if (skyStringIsEmpty(self.userModle.avatar)) {
            cell.rightImageView.image = [UIImage imageNamed:@"ic_launcher"];
        }else
        {
            hj_setImage(cell.rightImageView, self.userModle.avatar);
        }
       
    }
    if (indexPath.row == 1) {
        cell.namneLabel.text = @"昵称";
        cell.rightImageView.hidden = YES;
        cell.messageLabel.text = self.userModle.nickname;
    }
    if (indexPath.row == 2) {
        cell.namneLabel.text = @"性别";
        if ([self.userModle.sex isEqualToString:@"0"]) {
            cell.rightImageView.image = [UIImage imageNamed:@"global_male"];
        }else
        {
            cell.rightImageView.image = [UIImage imageNamed:@"global_female"];
        }
        cell.messageLabel.hidden = YES;
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 0) {
        return 80;
    }else
    {
        return 50;
    }
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
       WS(weakSelf);
    switch (indexPath.row) {
        case 0:
            {
                changeHeadImgViewController *HeadVC = [[changeHeadImgViewController alloc]init];
                HeadVC.sucB = ^{
                     [weakSelf getUserData];
                };
                
                HeadVC.UsewrHeadImg = self.userModle.userImage;
                [self.navigationController pushViewController:HeadVC animated:YES
                 ];
            }
            break;
        case 1:
        {
            changeNickNameViewController *nickVC = [[changeNickNameViewController alloc]init];
         
            nickVC.sucb = ^{
                [weakSelf getUserData];
            };
            [self.navigationController pushViewController:nickVC animated:YES
             ];
        }
            break;
        case 2:
        { changeSexViewController *sexVC = [[changeSexViewController alloc]init];
            sexVC.sex = self.userModle.sex;
            sexVC.sucb = ^{
                 [weakSelf getUserData];
            };
            [self.navigationController pushViewController:sexVC animated:YES
             ];
            
        }
            break;
        default:
            break;
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
