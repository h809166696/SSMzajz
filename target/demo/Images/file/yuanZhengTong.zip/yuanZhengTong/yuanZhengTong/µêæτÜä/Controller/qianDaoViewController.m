//
//  qianDaoViewController.m
//  yuanZhengTong
//
//  Created by jack on 2017/10/22.
//  Copyright © 2017年 tianyixin. All rights reserved.
//

#import "qianDaoViewController.h"
#import "QianDaoView.h"
#import "qianDaoModel.h"
#import "userManager.h"
@interface qianDaoViewController ()
@property (strong, nonatomic) IBOutlet UIView *bottomContentView;
@property (strong, nonatomic) IBOutlet UILabel *qiandaoXizeLabel;
@property (nonatomic,strong)UIButton   *qianDaoButton;
@property (nonatomic,strong)UILabel    *qianDaoContentLabel;
@property (nonatomic,strong)UILabel    *jiFenLabel;
@property (nonatomic,strong)UIView     *signNextView;
@property (nonatomic,strong)qianDaoModel *Model;
@end

@implementation qianDaoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"签到";
    if (IOS11) {
        
    }else{
        self.automaticallyAdjustsScrollViewInsets = NO;
    }
    [self initView];
    [self getsignData];
    // Do any additional setup after loading the view from its nib.
}
-(void)initView{
    skyViewBorderRadius(self.bottomContentView, 8, 1,skyColorWithHex(0xFFAD35));
    skyViewBorderRadius(self.qiandaoXizeLabel, 0, 1, skyColorWithHex(0xFFAD35));
    UIImageView *HeadImageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, NAVIGATION_BAR_HEIGHT, WIDTH, 150)];
    HeadImageView.userInteractionEnabled = YES;
    HeadImageView.image = [UIImage imageNamed:@"sign_in_bg"];
    HeadImageView.contentMode = UIViewContentModeScaleToFill;
    [self.view addSubview:HeadImageView];
    
    UIButton *qianDaoButton = [UIButton buttonWithType:UIButtonTypeCustom];
    qianDaoButton.frame = CGRectMake((WIDTH/2) - 45, 15, 90, 90);
    qianDaoButton.backgroundColor  = [UIColor blueColor];
    [qianDaoButton setTitle:@"签到" forState:UIControlStateNormal];
    [qianDaoButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [qianDaoButton addTarget:self action:@selector(qianDaoButtonClick) forControlEvents:UIControlEventTouchUpInside];
    skyViewBorderRadius(qianDaoButton, 45, 0, [UIColor clearColor]);
    [HeadImageView addSubview:qianDaoButton];
    self.qianDaoButton = qianDaoButton;
    
    UILabel *qianDaolabel = [[UILabel alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(qianDaoButton.frame)+15, WIDTH, 20)];
    qianDaolabel.font = [UIFont systemFontOfSize:14];
    qianDaolabel.textAlignment = NSTextAlignmentCenter;
    qianDaolabel.textColor = [UIColor whiteColor];
    qianDaolabel.text = @"已连续签到1天,明天奖励更丰厚哦";
    self.qianDaoContentLabel = qianDaolabel;
    [HeadImageView addSubview:qianDaolabel];
    
    UILabel *jiFemnLabel = [[UILabel alloc]initWithFrame:CGRectMake(10,CGRectGetMaxY(HeadImageView.frame)+5,WIDTH-20, 25)];
    jiFemnLabel.text = @"已拥有积分   10";
    jiFemnLabel.backgroundColor = defaultBackColor;
    jiFemnLabel.textAlignment = NSTextAlignmentCenter;
    jiFemnLabel.font = [UIFont systemFontOfSize:14];
    jiFemnLabel.textColor = skyColorWithHex(0xFFAD35);
    skyViewBorderRadius(jiFemnLabel, 8, 1, skyColorWithHex(0xFFAD35));
    [self.view addSubview:jiFemnLabel];
    self.jiFenLabel = jiFemnLabel;
    
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0,CGRectGetMaxY(jiFemnLabel.frame)+8, WIDTH, 117)];
    self.signNextView = view;
    [self.view addSubview:view];
}
#pragma mark---获取数据完成后刷新
-(void)refreshView{
    for (UIView *subView in self.signNextView.subviews) {
        [subView removeFromSuperview];
    }
    self.qianDaoContentLabel.text = [NSString stringWithFormat:@"已连续签到%@天,明天奖励更丰厚哦",self.Model.sign_in_num];
    [_qianDaoContentLabel wl_changeColorWithTextColor:[UIColor redColor] changeText:self.Model.sign_in_num];
    [_qianDaoContentLabel wl_changeBgColorWithBgTextColor:[UIColor yellowColor] changeText:self.Model.sign_in_num];
    self.jiFenLabel.text = [NSString stringWithFormat:@"已拥有积分   %@",self.Model.sign_in_user_point];
    [_jiFenLabel wl_changeFontWithTextFont:[UIFont boldSystemFontOfSize:18] changeText:self.Model.sign_in_user_point];
     [_jiFenLabel wl_changeColorWithTextColor:[UIColor redColor] changeText:self.Model.sign_in_user_point];
    CGFloat jianGe = 8;
    CGFloat zongWidth = WIDTH - 20;
    CGFloat width = (zongWidth - jianGe*5)/5;
    CGFloat height = 117;
    for (int i = 0; i<self.Model.sign_in_con_point.count; i++) {
        signPointModel *model = self.Model.sign_in_con_point[i];
        if (i == 0) {
            
            if ([model.signed_today isEqualToString:@"1"]) {
                [self.qianDaoButton setTitle:@"签到完成" forState:UIControlStateNormal];
                self.qianDaoButton.enabled = NO;
            };
           
        }
        QianDaoView *view = [[QianDaoView alloc]initWithFrame:CGRectMake(10+(width+jianGe)*i, 0, width, height)];
        view.dayLabelText = model.next_point;
        view.dateText = model.next_time.MMdddateStr;
        view.isQianDao = [model.signed_today isEqualToString:@"0"]?NO:YES;
        [self.signNextView addSubview:view];
    }
}
#pragma mark---签到
-(void)qianDaoButtonClick{
    WS(weakSelf);
    [SVProgressHUD show];
    [SVProgressHUD setDefaultMaskType:SVProgressHUDMaskTypeClear];
    NSString *token = [userManager getUserToken];
    [qianDaoModel userSignWithToken:token SUCB:^(qianDaoModel *qiandaoM) {
        [SVProgressHUD dismiss];
        [SVProgressHUD setDefaultMaskType:SVProgressHUDMaskTypeNone];
        weakSelf.Model = qiandaoM;
        [weakSelf refreshView];
        
    } Fail:^(NSError *error, NSString *wrongmsg) {
        [SVProgressHUD dismiss];
        [SVProgressHUD setDefaultMaskType:SVProgressHUDMaskTypeNone];
        [weakSelf showinfoMessage:wrongmsg];
    }];
}
#pragma mark---获取数据
-(void)getsignData{
    WS(weakSelf);
    [SVProgressHUD show];
    [SVProgressHUD setDefaultMaskType:SVProgressHUDMaskTypeClear];
    NSString *token = [userManager getUserToken];
    [qianDaoModel getUserQianDaoModelWithToken:token SUCB:^(qianDaoModel *qiandaoM) {
        [SVProgressHUD dismiss];
        [SVProgressHUD setDefaultMaskType:SVProgressHUDMaskTypeNone];
        weakSelf.Model = qiandaoM;
        [weakSelf refreshView];
       
    } Fail:^(NSError *error, NSString *wrongmsg) {
        [SVProgressHUD dismiss];
        [SVProgressHUD setDefaultMaskType:SVProgressHUDMaskTypeNone];
        [weakSelf showinfoMessage:wrongmsg];
    }];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
