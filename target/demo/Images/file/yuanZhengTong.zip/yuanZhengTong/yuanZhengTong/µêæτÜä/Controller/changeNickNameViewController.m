//
//  changeNickNameViewController.m
//  yuanZhengTong
//
//  Created by jack on 2017/10/22.
//  Copyright © 2017年 tianyixin. All rights reserved.
//

#import "changeNickNameViewController.h"
#import "resgisterModel.h"
#import "userManager.h"
#import "UserModel.h"
@interface changeNickNameViewController ()
@property (strong, nonatomic) IBOutlet UITextField *nickTextField;
@property (strong, nonatomic) IBOutlet UIButton *saveButton;

@end

@implementation changeNickNameViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"修改昵称";
    skyViewBorderRadius(self.saveButton, 10, 0, [UIColor clearColor]);
    // Do any additional setup after loading the view from its nib.
}
- (IBAction)saveButtonClick:(UIButton *)sender {
    NSString *alertStr = @"";
    if (skyStringIsEmpty(self.nickTextField.text)) {
        alertStr = @"昵称不能为空";
    }
    if (self.nickTextField.text.length>8) {
         alertStr = @"昵称最多8位数";
    }
    if (skyStringIsEmpty(alertStr)) {
        WS(weakSelf);
       UserMessageModel *model =  [userManager getUserModel];
        NSString *token = [userManager getUserToken];
        [resgisterModel changeUserMessageWithToken:token email:@"" sex:model.sex nickname:self.nickTextField.text suc:^(NSString *code) {
            if ([[NSString stringWithFormat:@"%@",code] isEqualToString:@"0"]) {
                [weakSelf showinfoMessage:@"修改成功"];
                if (weakSelf.sucb) {
                    weakSelf.sucb();
                }
                
                [weakSelf.navigationController popViewControllerAnimated:YES];
            }else
            {
                 [weakSelf showErrorMessage2WithMessage:@"修改失败"];
            }
        } Fail:^(NSError *error) {
            [weakSelf showErrorMessage];
        }];
    }else
    {
        [self showAlertWithTitle:@"温馨提示" message:alertStr handler:^(UIAlertAction *action) {
            
        }];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
