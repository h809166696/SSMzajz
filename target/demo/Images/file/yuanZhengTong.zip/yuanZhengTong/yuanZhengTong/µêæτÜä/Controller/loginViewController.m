//
//  loginViewController.m
//  yuanZhengTong
//
//  Created by jack on 2017/10/21.
//  Copyright © 2017年 tianyixin. All rights reserved.
//

#import "loginViewController.h"
#import "UserModel.h"
#import "userManager.h"
#import "registerAndFoegetViewController.h"
@interface loginViewController ()
@property (strong, nonatomic) IBOutlet UITextField *phoneTextField;
@property (strong, nonatomic) IBOutlet UITextField *passwordTextField;
@property (strong, nonatomic) IBOutlet UIButton *loginButton;
@property (strong, nonatomic) IBOutlet UIView *titleView;

@end

@implementation loginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.phoneTextField becomeFirstResponder];
    [self initView];
    // Do any additional setup after loading the view from its nib.
}
#pragma mark---初始化视图
-(void)initView{
    skyViewBorderRadius(self.loginButton, 10, 0, [UIColor clearColor]);
//    [self.titleView mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.height.mas_equalTo(@(NAVIGATION_BAR_HEIGHT));
//        make.left.top.equalTo(self.view);
//    }];
    if (iPhoneX) {
        [self.titleView mas_updateConstraints:^(MASConstraintMaker *make) {
            make.height.mas_equalTo(@(NAVIGATION_BAR_HEIGHT));
        }];
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)forgetClick:(UIButton *)sender {
    registerAndFoegetViewController *registerVC = [[registerAndFoegetViewController alloc]init];
    registerVC.isRegister = NO;
    [self presentViewController:registerVC animated:YES completion:nil];
}
- (IBAction)loginButtonClick:(UIButton *)sender {
    [self.view endEditing:YES];
    NSString *alertStt = @"";
    if (skyStringIsEmpty(self.phoneTextField.text) || skyStringIsEmpty(self.passwordTextField.text)) {
        alertStt = @"手机号或密码不能为空";
    }
    WS(weakSelf);
    if (skyStringIsEmpty(alertStt)) {
        [SVProgressHUD show];
        [SVProgressHUD setDefaultMaskType:SVProgressHUDMaskTypeClear];
        [UserMessageModel userLoginWithPhone:self.phoneTextField.text password:self.passwordTextField.text  SUC:^(UserMessageModel *model, NSDictionary *tokenDic) {
            [userManager writeToToken:tokenDic];
            [userManager userMessageWriteToFile:model];
            if (weakSelf.loginB) {
                weakSelf.loginB(tokenDic[@"token"]);
            }
            [weakSelf dismissViewControllerAnimated:YES completion:nil];
            [SVProgressHUD dismiss];
            [SVProgressHUD setDefaultMaskType:SVProgressHUDMaskTypeNone];
        } Fail:^(NSError *error, NSString *wrongCode) {
            if ([wrongCode isEqualToString:@"8409"]) {
                [SVProgressHUD showErrorWithStatus:@"用户不存在"];
            }else if([wrongCode isEqualToString:@"8405"]){
                [SVProgressHUD showErrorWithStatus:@"密码错误"];
                
            }else{
            [SVProgressHUD showErrorWithStatus:@"登录失败,请稍后再试"];
            }
            [SVProgressHUD setDefaultMaskType:SVProgressHUDMaskTypeNone];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [SVProgressHUD dismiss];
            });
        }];
        
    }else
    {
        [self showAlertWithTitle:@"温馨提示" message:alertStt handler:^(UIAlertAction *action) {
            
        }];
    }
}
- (IBAction)registerCllick:(UIButton *)sender {
    registerAndFoegetViewController *registerVC = [[registerAndFoegetViewController alloc]init];
    registerVC.isRegister = YES;
    [self presentViewController:registerVC animated:YES completion:nil];
}
- (IBAction)backButtonClick:(UIButton *)sender {
    [self dismissViewControllerAnimated:YES completion:^{
        
    }];
}
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
