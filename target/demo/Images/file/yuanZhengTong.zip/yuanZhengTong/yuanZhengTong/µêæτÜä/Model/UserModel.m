//
//  UserModel.m
//  yuanZhengTong
//
//  Created by jack on 2017/10/21.
//  Copyright © 2017年 tianyixin. All rights reserved.
//

#import "UserModel.h"

@implementation UserModel

@end
@implementation UserMessageModel
/** Key */
static NSString *ID = @"ID";
static NSString *username = @"username";
static NSString *email = @"email";
static NSString *sex = @"sex";
static NSString *money = @"money";
static NSString *point = @"point";
static NSString *nickname = @"nickname";
static NSString *logintime = @"logintime";
static NSString *role_id = @"role_id";
static NSString *status = @"status";
static NSString *mobile = @"mobile";
static NSString *avatar = @"avatar";
static NSString *create_at = @"create_at";
static NSString *loginip = @"loginip";
static NSString *sign_in_time = @"sign_in_time";
static NSString *sign_in_num = @"sign_in_num";
/** 设置需要存储的数据 */
- (void)encodeWithCoder:(NSCoder *)aCoder
{
    [aCoder encodeObject:_ID forKey:ID];
    [aCoder encodeObject:_username forKey:username];
    [aCoder encodeObject:_email forKey:email];
    [aCoder encodeObject:_sex forKey:sex];
    [aCoder encodeObject:_money forKey:money];
    [aCoder encodeObject:_point forKey:point];
     [aCoder encodeObject:_nickname forKey:nickname];
     [aCoder encodeObject:_logintime forKey:logintime];
     [aCoder encodeObject:_role_id forKey:role_id];
     [aCoder encodeObject:_status forKey:status];
     [aCoder encodeObject:_mobile forKey:mobile];
     [aCoder encodeObject:_avatar forKey:avatar];
     [aCoder encodeObject:_create_at forKey:create_at];
     [aCoder encodeObject:_loginip forKey:loginip];
    [aCoder encodeObject:_sign_in_time forKey:sign_in_time];
    [aCoder encodeObject:_sign_in_num forKey:sign_in_num];
}

/** 解析数据 */
- (instancetype)initWithCoder:(NSCoder *)aDecoder
{
    if (self = [super init]) {
        self.ID = [aDecoder decodeObjectForKey:ID];
        self.username = [aDecoder decodeObjectForKey:username];
        self.email = [aDecoder decodeObjectForKey:email];
        self.sex = [aDecoder decodeObjectForKey:sex];
        self.money = [aDecoder decodeObjectForKey:money];
        self.point = [aDecoder decodeObjectForKey:point];
         self.nickname = [aDecoder decodeObjectForKey:nickname];
         self.logintime = [aDecoder decodeObjectForKey:logintime];
         self.role_id = [aDecoder decodeObjectForKey:role_id];
         self.status = [aDecoder decodeObjectForKey:status];
         self.mobile = [aDecoder decodeObjectForKey:mobile];
         self.avatar = [aDecoder decodeObjectForKey:avatar];
         self.create_at = [aDecoder decodeObjectForKey:create_at];
         self.loginip = [aDecoder decodeObjectForKey:loginip];
         self.sign_in_time = [aDecoder decodeObjectForKey:sign_in_time];
         self.sign_in_num = [aDecoder decodeObjectForKey:sign_in_num];
    }
    
    return  self;
}
+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
    return @{@"ID": @"id"};
}
+(void)userLoginWithPhone:(NSString *)phone password:(NSString *)passeord SUC:(SUCBlock)sucb Fail:(FailBlock)failB{
    [HJHTTPManager requestWithType:SkyHttpRequestTypePost UrlString:[TRUEURLHEAD addStr:@"user_login"] Parameters:@{@"mobile":phone,@"password":passeord} SuccessBlock:^(id responseObject) {
        @try {

            NSDictionary *dataDic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
            if ([[NSString stringWithFormat:@"%@",dataDic[@"code"]] isEqualToString:@"0"]) {
                UserMessageModel *model = [UserMessageModel mj_objectWithKeyValues:dataDic[@"data"][@"user"]];
                NSDictionary *tokenDic = dataDic[@"data"][@"token"];
                sucb(model,tokenDic);
            }else if ([[NSString stringWithFormat:@"%@",dataDic[@"code"]] isEqualToString:@"8409"]){
                failB(nil,@"8409");
            }else
            {
                failB(nil,@"");
            }
        } @catch (NSException *exception) {
            failB(nil,@"");
        } @finally {
            
        }
    } FailureBlock:^(NSError *error) {
        failB(error,@"");
    }];
}
@end
