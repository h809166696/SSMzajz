//
//  changeHeadImgViewController.m
//  yuanZhengTong
//
//  Created by jack on 2017/10/22.
//  Copyright © 2017年 tianyixin. All rights reserved.
//

#import "changeHeadImgViewController.h"
#import <AVFoundation/AVFoundation.h>
#import "AJPhotoBrowserViewController.h"
#import "AJPhotoPickerViewController.h"
#import "userManager.h"
@interface changeHeadImgViewController ()<AJPhotoPickerProtocol>
@property (strong, nonatomic) IBOutlet UIImageView *headImageView;
@property (nonatomic,strong)UIImage *image;
@end

@implementation changeHeadImgViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"上传头像";
    if (self.UsewrHeadImg == nil) {
        self.headImageView.image = [UIImage imageNamed:@"ic_launcher"];
    }else
    {
        
    self.headImageView.image = self.UsewrHeadImg;
    }
    // Do any additional setup after loading the view from its nib.
}
- (IBAction)picbuttonClick:(UIButton *)sender {
    [self aJPhotoPicker];
}
#pragma mark --- 相片选择框架
- (void)aJPhotoPicker
{
    AJPhotoPickerViewController *picker = [[AJPhotoPickerViewController alloc] init];
    picker.maximumNumberOfSelection = 1;
    picker.multipleSelection = YES;
    picker.assetsFilter = [ALAssetsFilter allPhotos];
    picker.showEmptyGroups = YES;
    picker.delegate = self;
    picker.selectionFilter = [NSPredicate predicateWithBlock:^BOOL(id evaluatedObject, NSDictionary *bindings) {
        return YES;
    }];
    [[UIApplication sharedApplication].delegate.window.rootViewController presentViewController:picker animated:YES completion:nil];
}
#pragma mark - AJPhotoPickerProtocol 图片选择器的代理

- (void)photoPickerDidCancel:(AJPhotoPickerViewController *)picker {
    [picker dismissViewControllerAnimated:YES completion:nil];
}

- (void)photoPicker:(AJPhotoPickerViewController *)picker didSelectAssets:(NSArray *)assets {
    NSArray *photos = [NSArray arrayWithArray:assets];
    for (ALAsset *asset in photos) {
        UIImage *tempImg = [UIImage imageWithCGImage:asset.defaultRepresentation.fullScreenImage];
        self.image = tempImg;
        self.headImageView.image = self.image;
          [self uploadPic];
    }
    
   
    
    [picker dismissViewControllerAnimated:NO completion:nil];
}

- (void)photoPicker:(AJPhotoPickerViewController *)picker didSelectAsset:(ALAsset *)asset {
    NSLog(@"%s",__func__);
}

- (void)photoPicker:(AJPhotoPickerViewController *)picker didDeselectAsset:(ALAsset *)asset {
    NSLog(@"%s",__func__);
}

//超过最大选择项时
- (void)photoPickerDidMaximum:(AJPhotoPickerViewController *)picker {
    NSLog(@"%s",__func__);
    [[[UIAlertView alloc] initWithTitle:@"最多只能添加1张图片" message:nil delegate:nil cancelButtonTitle:@"知道了" otherButtonTitles:nil] show];
}

//低于最低选择项时
- (void)photoPickerDidMinimum:(AJPhotoPickerViewController *)picker {
    NSLog(@"%s",__func__);
}

- (void)photoPickerTapCameraAction:(AJPhotoPickerViewController *)picker {
    [self checkCameraAvailability:^(BOOL auth) {
        if (!auth) {
            NSLog(@"没有访问相机权限");
            return;
        }
        
        [picker dismissViewControllerAnimated:NO completion:nil];
        UIImagePickerController *cameraUI = [UIImagePickerController new];
        cameraUI.allowsEditing = NO;
        cameraUI.delegate = self;
        cameraUI.sourceType = UIImagePickerControllerSourceTypeCamera;
        cameraUI.cameraFlashMode=UIImagePickerControllerCameraFlashModeAuto;
        
        [[UIApplication sharedApplication].delegate.window.rootViewController presentViewController: cameraUI animated: YES completion:nil];
    }];
}
- (void)checkCameraAvailability:(void (^)(BOOL auth))block {
    BOOL status = NO;
    AVAuthorizationStatus authStatus = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo];
    if(authStatus == AVAuthorizationStatusAuthorized) {
        status = YES;
    } else if (authStatus == AVAuthorizationStatusDenied) {
        status = NO;
    } else if (authStatus == AVAuthorizationStatusRestricted) {
        status = NO;
    } else if (authStatus == AVAuthorizationStatusNotDetermined) {
        [AVCaptureDevice requestAccessForMediaType:AVMediaTypeVideo completionHandler:^(BOOL granted) {
            if(granted){
                if (block) {
                    block(granted);
                }
            } else {
                if (block) {
                    block(granted);
                }
            }
        }];
        return;
    }
    if (block) {
        block(status);
    }
}

#pragma mark - UIImagePickerDelegate
- (void)imagePickerControllerDidCancel:(UIImagePickerController *) picker {
    [picker dismissViewControllerAnimated:YES completion:nil];
}

- (void)image:(UIImage*)image didFinishSavingWithError:(NSError*)error contextInfo:(void*)contextInfo {
    if (!error) {
        NSLog(@"保存到相册成功");
    }else{
        NSLog(@"保存到相册出错%@", error);
    }
}
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    NSString *mediaType = [info objectForKey: UIImagePickerControllerMediaType];
    UIImage *originalImage;
    if (CFStringCompare((CFStringRef) mediaType,kUTTypeImage, 0)== kCFCompareEqualTo) {
        originalImage = (UIImage *) [info objectForKey:UIImagePickerControllerOriginalImage];
    }
    self.image = originalImage;
     self.headImageView.image = self.image;
    [self uploadPic];
//    [self.writeDiaryView.imageEntry addObject:originalImage];
//    [self.pickerCollectionView reloadData];
//    //获取图片的信息
//    //照片mediaInfo
//    NSDictionary * imageMetadata = info[@"UIImagePickerControllerMediaMetadata"];
//    NSDictionary *tIFFDictionary =  [imageMetadata objectForKey:(NSString *)kCGImagePropertyTIFFDictionary];
//    NSString * pictureTime = tIFFDictionary[@"DateTime"];//2016:01:05 11:45:36
//    SLog(@"pictureDate = %@",pictureTime);
//    if (!skyStringIsEmpty(pictureTime)) {
//        [self changetimeBtnTitleWithDatatime:pictureTime];
//    }
    
    [[UIApplication sharedApplication].delegate.window.rootViewController dismissViewControllerAnimated:YES completion:nil];
}

-(void)uploadPic{
    WS(weakSelf);
    [SVProgressHUD show];
    [SVProgressHUD setDefaultMaskType:SVProgressHUDMaskTypeClear];
    NSString *token = [userManager getUserToken];
    [HJHTTPManager uploadImageUrlString:[TRUEURLHEAD addStr:@"user_update_avatar"] Parameters:@{@"token":token,@"avatar":@"avatar.jpg"} image:self.image SuccessBlock:^(id responseObject) {
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
        if ([[NSString stringWithFormat:@"%@",dic[@"code"]] isEqualToString:@"0"]) {
            [weakSelf showinfoMessage:@"更换成功!"];
            if (weakSelf.sucB) {
                weakSelf.sucB();
            }
        }else
        {
             [weakSelf showinfoMessage:dic[@"msg"]];
        }
         [SVProgressHUD setDefaultMaskType:SVProgressHUDMaskTypeNone];
    } FailureBlock:^(NSError *error) {
       
        NSLog(@"错误描述%@", [error description]);
        [weakSelf showErrorMessage];
      [SVProgressHUD setDefaultMaskType:SVProgressHUDMaskTypeNone];
    }];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
