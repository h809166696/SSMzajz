//
//  yiJianFanKuiViewController.m
//  yuanZhengTong
//
//  Created by jack on 2017/10/22.
//  Copyright © 2017年 tianyixin. All rights reserved.
//

#import "yiJianFanKuiViewController.h"
#import "HJTextView.h"
#import "userManager.h"
#import "UserModel.h"
@interface yiJianFanKuiViewController ()
@property (nonatomic,strong)UIView   *contentView;
@property (nonatomic,strong)HJTextView *textView;
@property (nonatomic,strong)UITextField *phoneTextField;

@end

@implementation yiJianFanKuiViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"意见反馈";
    self.view.backgroundColor = [UIColor whiteColor];
    [self initView];
    
    // Do any additional setup after loading the view from its nib.
}
#pragma mark---初始化视图
-(void)initView{
    UIView *contentView = [[UIView alloc]initWithFrame:CGRectMake(0, NAVIGATION_BAR_HEIGHT+20, WIDTH, HEIGHT - NAVIGATION_BAR_HEIGHT - 20)];
    contentView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:contentView];
    self.contentView = contentView;
    
    UILabel *label1 = [[UILabel alloc]initWithFrame:CGRectMake(10, 5, 60, 20)];
    label1.font  = [UIFont systemFontOfSize:14];
    label1.textAlignment = NSTextAlignmentLeft;
    label1.text  = @"内容";
    [contentView addSubview:label1];
    
    HJTextView *textView = [[HJTextView alloc]initWithFrame:CGRectMake(60, 0, WIDTH - 60, 100)];
    textView.placeholder = @"请输入反馈内容(255字以内)";
    textView.showCountLabel = YES;
    self.textView = textView;
    [contentView addSubview:textView];
    
    UILabel *grayLabel1 = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(textView.frame)+5, WIDTH, 1)];
    grayLabel1.backgroundColor = kColorWithHex(0xdddddd);
    [contentView addSubview:grayLabel1];
    
    UILabel *label2 = [[UILabel alloc]initWithFrame:CGRectMake(10, 115, 60, 20)];
    label2.font  = [UIFont systemFontOfSize:14];
    label2.textAlignment = NSTextAlignmentLeft;
    label2.text  = @"手机号";
    [contentView addSubview:label2];
    
    UITextField *phoneTextField = [[UITextField alloc]initWithFrame:CGRectMake(60, 110, WIDTH-60, 30)];
    phoneTextField.placeholder = @"选填";
    self.phoneTextField = phoneTextField;
    [contentView addSubview:phoneTextField];
    
    
    UILabel *grayLabel2 = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(phoneTextField.frame)+5, WIDTH, 1)];
    grayLabel2.backgroundColor = kColorWithHex(0xdddddd);
    [contentView addSubview:grayLabel2];
    
    UIButton *subMitButton = [UIButton buttonWithType:UIButtonTypeCustom];
    subMitButton.frame  =CGRectMake(10, CGRectGetMaxY(phoneTextField.frame)+20, WIDTH - 20, 40);
    [subMitButton setBackgroundColor:skyColorWithHex(0xf0e68c)];
    [subMitButton setTitle:@"反馈" forState:UIControlStateNormal];
    [subMitButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [subMitButton addTarget:self action:@selector(submitClick) forControlEvents:UIControlEventTouchUpInside];
    skyViewBorderRadius(subMitButton, 10, 0, [UIColor clearColor]);
    [contentView addSubview:subMitButton];
}
-(void)submitClick{
    
    NSString *alertStr = @"";
    if (![_phoneTextField.text isEqualToString:@""] && ![_phoneTextField.text checkPhoneNumInput]) {
        alertStr = @"不是正确的手机号";
    }
    if (self.textView.contentText.length > 255) {
        alertStr = @"反馈内容不能超过255个字";
    }
    if (self.textView.contentText.length == 0) {
        alertStr = @"反馈内容不能为空";
    }
    if (skyStringIsEmpty(alertStr)) {
       UserMessageModel *model =  [userManager getUserModel];
        NSString *uid = model != nil?model.ID:@"";
        [SVProgressHUD show];
        WS(weakSelf);
        [HJHTTPManager requestWithType:SkyHttpRequestTypePost UrlString:[TRUEURLHEAD addStr:@"feedback_add"] Parameters:@{@"content":self.textView.contentText,@"mobile":_phoneTextField.text,@"uid":uid} SuccessBlock:^(id responseObject) {
            @try {
                NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
                if ([[NSString stringWithFormat:@"%@",dic[@"code"]] isEqualToString:@"0"]){
                    [SVProgressHUD showInfoWithStatus:@"反馈成功,感谢您的反馈"];
                    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                        [SVProgressHUD dismiss];
                        [weakSelf.navigationController popViewControllerAnimated:YES];
                    });
                }else
                {
                    [SVProgressHUD showErrorWithStatus:dic[@"msg"]];
                    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                        [SVProgressHUD dismiss];
                    });
                }
            } @catch (NSException *exception) {
                [SVProgressHUD showErrorWithStatus:@"请求失败"];
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    [SVProgressHUD dismiss];
                });
            } @finally {
                
            }
        } FailureBlock:^(NSError *error) {
            [SVProgressHUD showErrorWithStatus:@"请求失败"];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [SVProgressHUD dismiss];
            });
        }];
    }else{
        [self showAlertWithTitle:@"温馨提示" message:alertStr handler:^(UIAlertAction *action) {
            
        }];
    }
   
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
