//
//  UserModel.h
//  yuanZhengTong
//
//  Created by jack on 2017/10/21.
//  Copyright © 2017年 tianyixin. All rights reserved.
//

#import <Foundation/Foundation.h>
@class UserMessageModel;
typedef void (^SUCBlock)(UserMessageModel *model,NSDictionary *tokenDic);
typedef void (^FailBlock)(NSError *error,NSString *wrongCode);
@interface UserModel : NSObject
@property (nonatomic,copy)NSString *imageName;
@property (nonatomic,copy)NSString *name;
@end
@interface UserMessageModel : NSObject<NSCoding>
@property (nonatomic,copy)NSString *ID;
@property (nonatomic,copy)NSString *username;
@property (nonatomic,copy)NSString *email;
@property (nonatomic,copy)NSString *sex;
@property (nonatomic,copy)NSString *money;
@property (nonatomic,copy)NSString *point;
@property (nonatomic,copy)NSString *nickname;
@property (nonatomic,copy)NSString *logintime;
@property (nonatomic,copy)NSString *role_id;
@property (nonatomic,copy)NSString *status;
@property (nonatomic,copy)NSString *mobile;
@property (nonatomic,copy)NSString *avatar;
@property (nonatomic,copy)NSString *create_at;
@property (nonatomic,copy)NSString *loginip;
@property (nonatomic,copy)NSString *sign_in_time;
@property (nonatomic,copy)NSString *sign_in_num;
@property (nonatomic,strong)UIImage *userImage;
+(void)userLoginWithPhone:(NSString *)phone password:(NSString *)passeord SUC:(SUCBlock)sucb Fail:(FailBlock)failB;
@end
