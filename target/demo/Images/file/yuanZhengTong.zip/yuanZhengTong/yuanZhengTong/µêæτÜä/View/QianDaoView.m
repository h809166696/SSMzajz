//
//  QianDaoView.m
//  yuanZhengTong
//
//  Created by jack on 2017/10/22.
//  Copyright © 2017年 tianyixin. All rights reserved.
//

#import "QianDaoView.h"
@interface QianDaoView()
@property (nonatomic,strong)UILabel *dayLabel;
@property (nonatomic,strong)UILabel *dateLabel;
@property (nonatomic,strong)UILabel *lingQuLabel;
@end
@implementation QianDaoView
-(instancetype)initWithFrame:(CGRect)frame
{
    if (self=[super initWithFrame:frame]) {
        CGFloat width = frame.size.width;
        CGFloat height = frame.size.height;
        UILabel *dayLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, width,80)];
        dayLabel.textAlignment = NSTextAlignmentCenter;
        dayLabel.backgroundColor = [UIColor lightGrayColor];
        dayLabel.textColor = [UIColor blackColor];
        skyViewBorderRadius(dayLabel, 5, 0, [UIColor clearColor]);
        [self addSubview:dayLabel];
        self.dayLabel = dayLabel;
        
        UILabel *lingQuLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(dayLabel.frame)+5, width, 15)];
        lingQuLabel.textAlignment = NSTextAlignmentCenter;
        lingQuLabel.textColor = skyColorWithHex(0x8a8a8a);
        lingQuLabel.text = @"未领取";
        lingQuLabel.font  = [UIFont systemFontOfSize:13];
       [self addSubview:lingQuLabel];
       self.lingQuLabel = lingQuLabel;
        
        
        UILabel *dateLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(lingQuLabel.frame)+2, width, 15)];
        dateLabel.textAlignment = NSTextAlignmentCenter;
        dateLabel.font  = [UIFont systemFontOfSize:13];
        [self addSubview:dateLabel];
        self.dateLabel = dateLabel;
        
        
    }
    return self;
}
-(void)setDateText:(NSString *)dateText{
    _dateText = dateText;
    self.dateLabel.text = dateText;
}
-(void)setDayLabelText:(NSString *)dayLabelText
{
    _dayLabelText = dayLabelText;
    self.dayLabel.text = dayLabelText;
}
-(void)setIsQianDao:(BOOL)isQianDao
{
    _isQianDao = isQianDao;
    if (isQianDao) {
        self.lingQuLabel.text = @"已领取";
        self.lingQuLabel.textColor = defaultOrangeColor;
        self.dayLabel.backgroundColor = defaultOrangeColor;
        self.dayLabel.textColor = [UIColor whiteColor];
    }
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
