//
//  resgisterModel.h
//  yuanZhengTong
//
//  Created by jack on 2017/10/21.
//  Copyright © 2017年 tianyixin. All rights reserved.
//

#import <Foundation/Foundation.h>
typedef void (^registerSUCBlock)(NSString *code);
typedef void (^registerFailBlock)(NSError *error);
@interface resgisterModel : NSObject
+(void)registerGetCode:(NSString *)mobile isResgister:(BOOL)isRegister suc:(registerSUCBlock)sucB Fail:(registerFailBlock)FailB;
+(void)registerUser:(NSString *)mobile password:(NSString *)password verifyCode:(NSString *)verfiCode suc:(registerSUCBlock)sucB Fail:(registerFailBlock)FailB;
+(void)resetPssword:(NSString *)mobile password:(NSString *)password verifyCode:(NSString *)verfiCode suc:(registerSUCBlock)sucB Fail:(registerFailBlock)FailB;
+(void)changeUserMessageWithToken:(NSString *)token email:(NSString *)email sex:(NSString *)sex nickname:(NSString *)nickName suc:(registerSUCBlock)sucB Fail:(registerFailBlock)FailB;
+(void)judgeVersion:(void(^)(NSDictionary *dataDic))sucB fail:(registerFailBlock)failb;
@end
