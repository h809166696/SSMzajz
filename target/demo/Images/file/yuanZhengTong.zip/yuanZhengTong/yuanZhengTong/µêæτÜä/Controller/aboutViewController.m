//
//  aboutViewController.m
//  yuanZhengTong
//
//  Created by jack on 2017/10/22.
//  Copyright © 2017年 tianyixin. All rights reserved.
//

#import "aboutViewController.h"

@interface aboutViewController ()
@property (strong, nonatomic) IBOutlet UIWebView *webView;
@property (weak, nonatomic) IBOutlet UIButton *checkButton;

@end

@implementation aboutViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self getData];
    NSString *judeStr = [[NSUserDefaults standardUserDefaults] objectForKey:IOSVersionJudge];
    if ([judeStr isEqualToString:@"-1"]) {
        self.checkButton.alpha = 0;
    }else
    {
        self.checkButton.alpha = 1;
    }
   
    self.title = @"关于我们";
    
    // Do any additional setup after loading the view from its nib.
}
-(void)getData{
    [SVProgressHUD show];
    WS(weakSelf);
    [HJHTTPManager requestWithType:SkyHttpRequestTypeGet UrlString:[TRUEURLHEAD addStr:@"single_page"] Parameters:@{@"pageName":@"about"} SuccessBlock:^(id responseObject) {
        NSData *data = [responseObject dataUsingEncoding:NSUTF8StringEncoding];
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
        if ([[NSString stringWithFormat:@"%@",dic[@"code"]] isEqualToString:@"0"]) {
            [weakSelf.webView loadHTMLString:dic[@"data"][@"body"] baseURL:nil];
            [SVProgressHUD dismiss];
        }else
        {
            [SVProgressHUD showErrorWithStatus:@"请求失败"];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [SVProgressHUD dismiss];
            });
        }
        
    } FailureBlock:^(NSError *error) {
        [SVProgressHUD showErrorWithStatus:@"请求失败"];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [SVProgressHUD dismiss];
        });
    }];
}
- (IBAction)checkButtonClick:(UIButton *)sender {
    NSString *judeStr = [[NSUserDefaults standardUserDefaults] objectForKey:IOSVersionJudge];
    if ([judeStr isEqualToString:@"0"]) {
        [self showinfoMessage:@"已经是最新版本"];
    }
    if ([judeStr isEqualToString:@"1"]) {
        NSString *str = [NSString stringWithFormat:@"https://itunes.apple.com/app/id1166846252"];
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:str]];
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
