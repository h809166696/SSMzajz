//
//  changeSexViewController.m
//  yuanZhengTong
//
//  Created by jack on 2017/10/22.
//  Copyright © 2017年 tianyixin. All rights reserved.
//

#import "changeSexViewController.h"
#import "JXLayoutButton.h"
#import "resgisterModel.h"
#import "UserModel.h"
#import "userManager.h"
@interface changeSexViewController ()
@property (nonatomic,strong)JXLayoutButton *manButton;
@property (nonatomic,strong)JXLayoutButton *womenButton;
@end

@implementation changeSexViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"性别";
    [self initView];
    // Do any additional setup after loading the view from its nib.
}
-(void)initView{
    JXLayoutButton *manbutton = [JXLayoutButton buttonWithType:UIButtonTypeCustom];
//    manbutton.center = CGPointMake(self.view.centerX, NAVIGATION_BAR_HEIGHT+100);
//    manbutton.bounds = CGRectMake(0, 0, 60, 100);
    manbutton.frame = CGRectMake(WIDTH/2-30, NAVIGATION_BAR_HEIGHT+50,60, 100);
    [manbutton setTitle:@"男" forState:UIControlStateNormal];
    [manbutton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    NSString *imageName = [self.sex isEqualToString:@"0"]?@"choice_sex_male":@"choice_sex_un_male";
    [manbutton setImage:[UIImage imageNamed:imageName] forState:UIControlStateNormal];
    manbutton.tag = 1;
    manbutton.layoutStyle = JXLayoutButtonStyleUpImageDownTitle;
    manbutton.imageSize = CGSizeMake(60, 60);
    [manbutton addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:manbutton];
    self.manButton = manbutton;
    
    JXLayoutButton *womenbutton = [JXLayoutButton buttonWithType:UIButtonTypeCustom];
//    womenbutton.center = CGPointMake(self.view.centerX, NAVIGATION_BAR_HEIGHT+100+100);
//    womenbutton.bounds = CGRectMake(0, 0, 60, 100);
    womenbutton.frame = CGRectMake(WIDTH/2-30, NAVIGATION_BAR_HEIGHT+150,60, 100);
    womenbutton.tag = 2;
    [womenbutton setTitle:@"女" forState:UIControlStateNormal];
    [womenbutton addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchUpInside];
    [womenbutton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    NSString *imageName1 = [self.sex isEqualToString:@"0"]?@"choice_sex_un_femal":@"choice_sex_femal";
    [womenbutton setImage:[UIImage imageNamed:imageName1] forState:UIControlStateNormal];
    womenbutton.layoutStyle = JXLayoutButtonStyleUpImageDownTitle;
    womenbutton.imageSize = CGSizeMake(60, 60);
    [self.view addSubview:womenbutton];
    self.womenButton = womenbutton;
}
-(void)buttonClick:(UIButton *)sender
{
    switch (sender.tag) {
        case 1:
            {
                if ([self.sex isEqualToString:@"0"]) {
                    return;
                }
                self.sex = @"0";
                [self commanFunc];
                
            }
            break;
        case 2:
        {
            if ([self.sex isEqualToString:@"1"]) {
            return;
        }
             self.sex = @"1";
              [self commanFunc];
        }
            break;
        default:
            break;
    }
}
-(void)commanFunc{
     [self changeStatus];
    self.womenButton.enabled = NO;
    self.manButton.enabled = NO;
    WS(weakSelf);
    UserMessageModel *model =  [userManager getUserModel];
    NSString *token = [userManager getUserToken];
    [resgisterModel changeUserMessageWithToken:token email:@"" sex:self.sex nickname:model.nickname suc:^(NSString *code) {
        if ([[NSString stringWithFormat:@"%@",code] isEqualToString:@"0"]) {
            [weakSelf showinfoMessage:@"修改成功!"];
            if (weakSelf.sucb) {
                weakSelf.sucb();
            }
        }else
        {
            [weakSelf showErrorMessage];
            weakSelf.sex = [weakSelf.sex isEqualToString:@"0"]?@"1":@"0";
            [weakSelf changeStatus];
        }
        weakSelf.womenButton.enabled = YES;
        weakSelf.manButton.enabled = YES;
    } Fail:^(NSError *error) {
        [weakSelf showErrorMessage];
        weakSelf.sex = [weakSelf.sex isEqualToString:@"0"]?@"1":@"0";
         [weakSelf changeStatus];
        weakSelf.womenButton.enabled = YES;
        weakSelf.manButton.enabled = YES;
    }];
}
-(void)changeStatus{
    
    NSString *imageName = [self.sex isEqualToString:@"0"]?@"choice_sex_male":@"choice_sex_un_male";
    [self.manButton setImage:[UIImage imageNamed:imageName] forState:UIControlStateNormal];
    NSString *imageName1 = [self.sex isEqualToString:@"0"]?@"choice_sex_un_femal":@"choice_sex_femal";
    [self.womenButton setImage:[UIImage imageNamed:imageName1] forState:UIControlStateNormal];

}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
