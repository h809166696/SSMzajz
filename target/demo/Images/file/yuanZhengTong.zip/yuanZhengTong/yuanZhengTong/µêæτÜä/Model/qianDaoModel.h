//
//  qianDaoModel.h
//  yuanZhengTong
//
//  Created by jack on 2017/10/22.
//  Copyright © 2017年 tianyixin. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void (^signModelFAIL)(NSError *error,NSString *wrongmsg);
@class signPointModel;
@interface qianDaoModel : NSObject
typedef void (^signModelSUCB)(qianDaoModel *qiandaoM);
@property (nonatomic,strong)NSString *sign_in_num;
@property (nonatomic,strong)NSString *sign_in_base_point;
@property (nonatomic,strong)NSString *signin_point_inc;
@property (nonatomic,strong)NSString *sign_in_time;
@property (nonatomic,strong)NSString *sign_in_user_point;
@property (nonatomic,strong)NSArray *sign_in_con_point;
+(void)getUserQianDaoModelWithToken:(NSString *)token SUCB:(signModelSUCB)sucb Fail:(signModelFAIL)faiB;
+(void)userSignWithToken:(NSString *)token SUCB:(signModelSUCB)sucb Fail:(signModelFAIL)faiB;
@end
@interface signPointModel : NSObject
@property (nonatomic,copy)NSString *next_point;
@property (nonatomic,copy)NSString *next_time;
@property (nonatomic,copy)NSString *signed_today;
@end
