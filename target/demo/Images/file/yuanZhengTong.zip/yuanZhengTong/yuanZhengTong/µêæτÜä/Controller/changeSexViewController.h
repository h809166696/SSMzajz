//
//  changeSexViewController.h
//  yuanZhengTong
//
//  Created by jack on 2017/10/22.
//  Copyright © 2017年 tianyixin. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void (^changeSexSucB)();
@interface changeSexViewController : UIViewController
@property (nonatomic,strong)NSString *sex;
@property (nonatomic,copy)changeSexSucB sucb;
@end
