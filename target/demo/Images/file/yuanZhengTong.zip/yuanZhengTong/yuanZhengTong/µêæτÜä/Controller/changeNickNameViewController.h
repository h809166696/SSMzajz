//
//  changeNickNameViewController.h
//  yuanZhengTong
//
//  Created by jack on 2017/10/22.
//  Copyright © 2017年 tianyixin. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void (^nickSUCblock)();
@interface changeNickNameViewController : UIViewController
@property (nonatomic,copy)nickSUCblock  sucb;
@end
