//
//  userMessageTableViewCell.h
//  yuanZhengTong
//
//  Created by jack on 2017/10/22.
//  Copyright © 2017年 tianyixin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface userMessageTableViewCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *messageLabel;
@property (strong, nonatomic) IBOutlet UILabel *namneLabel;
@property (strong, nonatomic) IBOutlet UIImageView *rightImageView;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *rightImageHeight;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *rightImageWidth;

@end
