//
//  TSStack.h
//  myCaculator
//
//  Created by Rudy on 14-5-30.
//  Copyright (c) 2014年 EfficientEducation. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface TSStack : NSObject
{
    int count_;
    NSMutableArray *array_;
    NSMutableString *allElementString_;
}

@property(atomic,readonly) int count;
@property(nonatomic,retain)  NSMutableString *allElementString;


-(void)push:(id)anObject;
-(NSString *)pop;
-(void)clear;
-(BOOL)contains:(id)anObject;
-(id)peek;

@end
