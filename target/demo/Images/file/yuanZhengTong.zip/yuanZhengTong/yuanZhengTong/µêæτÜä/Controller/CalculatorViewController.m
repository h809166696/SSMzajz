//
//  CalculatorViewController.m
//  yuanZhengTong
//
//  Created by hongyj on 2017/10/22.
//  Copyright © 2017年 tianyixin. All rights reserved.
//

#import "CalculatorViewController.h"
#import "TSStack.h"
@interface CalculatorViewController ()
{
    NSMutableString *inputString_;
    NSString  *operatorStr_;
    NSMutableString *expression_;
}
@property TSStack *inputStack_;
@property TSStack *numbersStack_;
@property TSStack *operatorStack_;
@property (nonatomic,strong)UILabel *calculationLabel;
@property (nonatomic,strong)UILabel *resultLabel;
@property(nonatomic,assign) double num1,num2;

@end

@implementation CalculatorViewController
@synthesize inputStack_;
@synthesize numbersStack_;
@synthesize operatorStack_;

- (void)viewDidLoad {
    [super viewDidLoad];
    operatorStr_=@"+-*/";
    expression_=[NSMutableString stringWithCapacity:30];
    inputString_=[NSMutableString stringWithCapacity:30];
    inputStack_=[[TSStack alloc]init];
    numbersStack_=[[TSStack alloc]init];
    operatorStack_=[[TSStack alloc]init];
    self.view.backgroundColor = [UIColor whiteColor];
    [self layoutButton];
    // Do any additional setup after loading the view.
}
- (void)pushOperator:(NSString *)btnText
{
    
    
    if (inputString_.length>0) {
        [inputStack_ push:inputString_];
    }
    if (inputStack_.count>0) {
        bool isOperator=[self isStackTopOperator:inputStack_];
        if (isOperator) {
            [inputStack_ pop];
        }
    }
    [inputString_ deleteCharactersInRange:NSMakeRange(0, inputString_.length)];
    [inputStack_ push:btnText];
}
-(BOOL)isStackTopOperator:(TSStack *)stack{
    NSString *topStr=[NSString stringWithString:[stack peek]];
    NSRange childRange= [operatorStr_ rangeOfString:topStr];
    bool isOperator=(childRange.location!=NSNotFound);
    return isOperator;
}
-(BOOL)canCaculate:(NSString *)currentOperator compareWith:(NSString *)stackTopOperator{
    if ([currentOperator isEqualToString:@"*"]) {
        if ([stackTopOperator isEqualToString:@"/"]) {
            return NO;
        }
        else{
            return YES;
        }
    }
    if ([currentOperator isEqualToString:@"/"]) {
        if ([stackTopOperator isEqualToString:@"/"]||[stackTopOperator isEqualToString:@"*"]) {
            return NO;
        }
        else{
            return YES;
        }
    }
    if ([currentOperator isEqualToString:@"+"]) {
        if ([stackTopOperator isEqualToString:@"+"]) {
            return YES;
        }
        else{
            return NO;
        }
    }
    if ([currentOperator isEqualToString:@"-"]) {
        if ([stackTopOperator isEqualToString:@"+"]) {
            return YES;
        }
        else{
            return NO;
        }
    }
    return NO;
}
- (void)CaculateNumber
{
    //caculate here
    double number1=[[numbersStack_ pop] doubleValue];
    double number2=[[numbersStack_ pop] doubleValue];
    double resultNumber=0;
    
    NSString *caculateOperator=[operatorStack_ pop];
    if ([caculateOperator isEqualToString:@"+"]) {
        resultNumber=number1+number2;
    }
    else if ([caculateOperator isEqualToString:@"-"]) {
        resultNumber=number1-number2;
    }
    else if ([caculateOperator isEqualToString:@"*"]) {
        resultNumber=number1*number2;
    }
    else if ([caculateOperator isEqualToString:@"/"]) {
        resultNumber=number1/number2;
    }
    if (resultNumber!=0) {
        NSString *resultStr=[NSString stringWithFormat:@"%.3f",resultNumber];
        
        [numbersStack_ push:resultStr];
    }
}
- (void)btnClick:(UIButton *)btn{
    NSString *btnText= btn.titleLabel.text;
    if ([btn.titleLabel.text isEqualToString:@"X"]) {
        btnText = @"*";
    }
    if ([btn.titleLabel.text isEqualToString:@"÷"]) {
        btnText = @"/";
    }
    if([btnText isEqualToString:@"+"]){
        [self pushOperator:btnText];
    }
    else if([btnText isEqualToString:@"-"]){
        [self pushOperator:btnText];
    }
    else if([btnText isEqualToString:@"*"]){
        [self pushOperator:btnText];
    }
    else if([btnText isEqualToString:@"/"]){
        [self pushOperator:btnText];
        
    }
    else if ([btnText isEqualToString:@"="]){
        
        if (inputStack_.count>1) {
            
            bool isOperator=[self isStackTopOperator:inputStack_];
            if (isOperator) {
                if (inputString_.length>0) {
                    [inputStack_ push:inputString_];
                    [inputString_ deleteCharactersInRange:NSMakeRange(0, inputString_.length)];
                    
                    [self.resultLabel setText:inputStack_.allElementString];
                    //start caculate
                    
                    //pop inputStack_
                    while (inputStack_.count>0) {
                        
                        if (operatorStack_.count>0&&numbersStack_.count>1) {
                            NSString *popStr=[inputStack_ peek];
                            bool istopOperator=[self isStackTopOperator:inputStack_];
                            if (istopOperator) {
                                bool caculateable=[self canCaculate:[operatorStack_ peek] compareWith:popStr];
                                if (caculateable) {
                                    [self CaculateNumber];
                                }
                                else{
                                    NSString *cannotCaculate=[inputStack_ pop];
                                    [operatorStack_ push:cannotCaculate];
                                }
                            }
                            else{
                                NSString *popStr= [inputStack_ pop];
                                [numbersStack_ push:popStr];
                                //inputStack used up
                                if (inputStack_.count==0) {
                                    while (numbersStack_.count>1) {
                                        [self CaculateNumber];
                                    }
                                }
                            }
                            
                        }
                        else{
                            bool istopOperator=[self isStackTopOperator:inputStack_];
                            if (istopOperator) {
                                NSString *popStr= [inputStack_ pop];
                                [operatorStack_ push:popStr];
                            }
                            else{
                                NSString *popStr= [inputStack_ pop];
                                [numbersStack_ push:popStr];
                            }
                            //inputStack used up
                            if (inputStack_.count==0) {
                                while (numbersStack_.count>1) {
                                    [self CaculateNumber];
                                }
                            }
                        }
                    }
                    
                }
            }
        }
        
    }
    else if([btnText isEqualToString:@"C"]){
        [inputStack_ clear];
        [inputString_ deleteCharactersInRange:NSMakeRange(0, inputString_.length)];
        
    }
    else if([btnText isEqualToString:@"DEL"]){
        
        if (inputString_.length>0) {
            NSRange deleteRange=NSMakeRange(inputString_.length-1, 1);
            [inputString_ deleteCharactersInRange:deleteRange];
        }
        else {
            if (inputStack_.count>0) {
                [inputString_ appendString:[inputStack_ pop]];
                if (inputString_.length>0) {
                    NSRange deleteRange=NSMakeRange(inputString_.length-1, 1);
                    [inputString_ deleteCharactersInRange:deleteRange];
                }
                
            }
        }
    }
    else if([btnText isEqualToString:@"."]){
        if (inputString_.length>0) {
            NSRange childRange= [inputString_ rangeOfString:btnText];
            if (childRange.location==NSNotFound) {
                [inputString_ appendString:btnText];
            }
            
        }
        
    }
    else if([btnText isEqualToString:@"0"]){
        
//        if (inputString_.length>0) {
            [inputString_ appendString:btnText];
//        }
    }
    else{
        if (inputStack_.count>0) {
            if (![self isStackTopOperator:inputStack_]&&inputString_.length==0) {
                [inputStack_ clear];
            }
        }
        [inputString_ appendString:btnText];
    }
    if (expression_.length>0) {
        NSRange expressionRange=NSMakeRange(0, expression_.length);
        [expression_ deleteCharactersInRange:expressionRange];
    }
    if (numbersStack_.count==1&&inputStack_.count==0&&operatorStack_.count==0) {
        [inputStack_ push:[numbersStack_  pop]];
    }
    if (inputStack_.count>0) {
        [expression_ appendString:inputStack_.allElementString];
    }
    if (inputString_.length>0) {
        [expression_ appendString:inputString_];
    }
    
    if (![btnText isEqualToString:@"="]) {
        [self.resultLabel setText:@""];
    }
    
    [self.calculationLabel setText:expression_];
    if ([btnText isEqualToString:@"C"]) {
        self.calculationLabel.text = @"0";
    }
    if ([btnText isEqualToString:@"="]) {
        [self.resultLabel setText:expression_];
        [self.calculationLabel setText:@""];
    }
    
}

- (UILabel *)calculationLabel{
    if (!_calculationLabel) {
        _calculationLabel = [[UILabel alloc]init];
        _calculationLabel.text = @"0";
//        _calculationLabel.font = [UIFont systemFontOfSize:50];
        _calculationLabel.textAlignment = NSTextAlignmentRight;
        _calculationLabel.backgroundColor = [UIColor clearColor];
        _calculationLabel.textColor = [UIColor blackColor];
    }
    return _calculationLabel;
}
- (UILabel *)resultLabel{
    if (!_resultLabel) {
        _resultLabel = [[UILabel alloc]init];

//        _resultLabel.font = [UIFont systemFontOfSize:50];
        _resultLabel.textAlignment = NSTextAlignmentRight;
        _resultLabel.backgroundColor = [UIColor clearColor];
        _resultLabel.textColor = [UIColor blackColor];
    }
    return _resultLabel;
}
-(void)layoutButton{
    
    
    //申明区域，displayView是显示区域，keyboardView是键盘区域
    UIView *displayView = [UIView new];
    [displayView.layer setBorderWidth:1];
    displayView.backgroundColor =[UIColor redColor];
    
    [displayView setBackgroundColor:[UIColor whiteColor]];
    [self.view addSubview:displayView];
    
    UIView *keyboardView = [UIView new];
    [self.view addSubview:keyboardView];
    [displayView addSubview:self.calculationLabel];
    [displayView addSubview:self.resultLabel];
    //先按1：3分割 displView（显示结果区域）和 keyboardView（键盘区域）
    [displayView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view.mas_top).offset(NAVIGATION_BAR_HEIGHT+5);
        make.left.equalTo(self.view.mas_left).offset(5);
        make.right.equalTo(self.view.mas_right).offset(-5);
        make.height.equalTo(keyboardView).multipliedBy(0.3f).offset(-15);

    }];
    [self.calculationLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(displayView);
        make.left.and.right.equalTo(displayView);
        make.height.equalTo(displayView).multipliedBy(0.45f);
    }];
    [self.resultLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.calculationLabel.mas_bottom);
        make.left.and.right.equalTo(displayView);
        make.height.equalTo(displayView).multipliedBy(0.5f);
    }];
    [keyboardView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(displayView.mas_bottom).offset(15);
        make.bottom.equalTo(self.view.mas_bottom);
//        make.left.and.right.equalTo(self.view);
        make.left.equalTo(self.view).offset(5);
        make.right.equalTo(self.view).offset(-5);
    }];
    
//    //设置显示位置的数字为0
//
//    UILabel *displayNum = [[UILabel alloc]init];
//    [displayView addSubview:displayNum];
//    displayNum.text = @"0";
//    displayNum.font = [UIFont fontWithName:@"HeiTi SC" size:70];
//    displayNum.textColor = [UIColor whiteColor];
//    displayNum.textAlignment = NSTextAlignmentRight;
//    [displayNum mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.left.and.right.equalTo(displayView).with.offset(-10);
//        make.bottom.equalTo(displayView).with.offset(-10);
//    }];
    
    CGFloat height = 0.19;
    //定义键盘键名称，？号代表合并的单元格
    NSArray *keys = @[@"C",@"DEL",@"X",@"÷"
                      ,@"7",@"8",@"9",@"-"
                      ,@"4",@"5",@"6",@"+"
                      ,@"1",@"2",@"3",@"?"
                      ,@"0",@"?",@".",@"="];
    
    UIButton *zeroBtn = nil;
    int indexOfKeys = 0;
    for (NSString *key in keys){
        //循环所有键
        indexOfKeys++;
        int rowNum = indexOfKeys %4 ==0? indexOfKeys/4:indexOfKeys/4 +1;
        int colNum = indexOfKeys %4 ==0? 4 :indexOfKeys %4;
        NSLog(@"index is:%d and row:%d,col:%d",indexOfKeys,rowNum,colNum);
        
        //键样式
        UIButton *keyView = [UIButton buttonWithType:UIButtonTypeCustom];
        [keyboardView addSubview:keyView];
        keyView.tag = indexOfKeys;
        [keyView addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
        [keyView setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [keyView setTitle:key forState:UIControlStateNormal];
        [keyView.layer setBorderWidth:1];
        [keyView.layer setBorderColor:[[UIColor lightGrayColor] CGColor]];
        [keyView.titleLabel setFont:[UIFont fontWithName:@"Helvetica-Bold" size:15]];
        if ([key isEqualToString:@"0"]) {
            zeroBtn = keyView;
        }
        //键约束
        [keyView mas_makeConstraints:^(MASConstraintMaker *make) {
            
            //处理 0 合并单元格
            if([key isEqualToString:@"."] || [key isEqualToString:@"?"]|| [key isEqualToString:@"="]){
                
                if([key isEqualToString:@"."]){
                    [keyView mas_makeConstraints:^(MASConstraintMaker *make) {
                        make.height.equalTo(keyboardView.mas_height).with.multipliedBy(height);
                        make.width.equalTo(keyboardView.mas_width).multipliedBy(.5);
                        make.left.equalTo(zeroBtn.mas_right);
                        make.baseline.equalTo(keyboardView.mas_baseline).with.multipliedBy(.9f);
                    }];
                }
                if ([key isEqualToString:@"="]) {
                    [keyView mas_makeConstraints:^(MASConstraintMaker *make) {
                        make.height.equalTo(keyboardView.mas_height).with.multipliedBy(height*2.05);
                        make.width.equalTo(keyboardView.mas_width).multipliedBy(.25f);
                        make.right.equalTo(keyboardView.mas_right);
                        make.baseline.equalTo(keyboardView.mas_baseline).with.multipliedBy(.8f);
                    }];
                }
                if([key isEqualToString:@"?"]){
                    [keyView removeFromSuperview];
                }
                
            }
            //正常的单元格
            else{
                make.width.equalTo(keyboardView.mas_width).with.multipliedBy(.25f);
                make.height.equalTo(keyboardView.mas_height).with.multipliedBy(height);
                
                //按照行和列添加约束，这里添加行约束
                switch (rowNum) {
                    case 1:
                    {
                        make.baseline.equalTo(keyboardView.mas_baseline).with.multipliedBy(.1f);
                        keyView.backgroundColor = [UIColor colorWithRed:205 green:205 blue:205 alpha:1];
                        
                    }
                        break;
                    case 2:
                    {
                        make.baseline.equalTo(keyboardView.mas_baseline).with.multipliedBy(.3f);
                    }
                        break;
                    case 3:
                    {
                        make.baseline.equalTo(keyboardView.mas_baseline).with.multipliedBy(.5f);
                    }
                        break;
                    case 4:
                    {
                        make.baseline.equalTo(keyboardView.mas_baseline).with.multipliedBy(.7f);
                    }
                        break;
                    case 5:
                    {
                        make.baseline.equalTo(keyboardView.mas_baseline).with.multipliedBy(.9f);
                    }
                        break;
                    default:
                        break;
                }
                //按照行和列添加约束，这里添加列约束
                switch (colNum) {
                    case 1:
                    {
                        make.left.equalTo(keyboardView.mas_left);
                        
                    }
                        break;
                    case 2:
                    {
                        make.right.equalTo(keyboardView.mas_centerX);
                        
                    }
                        break;
                    case 3:
                    {
                        make.left.equalTo(keyboardView.mas_centerX);
                    }
                        break;
                    case 4:
                    {
                        make.right.equalTo(keyboardView.mas_right);
                        [keyView setBackgroundColor:[UIColor colorWithRed:243 green:127 blue:38 alpha:1]];
                    }
                        break;
                    default:
                        break;
                }
            }
        }];
    }
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
