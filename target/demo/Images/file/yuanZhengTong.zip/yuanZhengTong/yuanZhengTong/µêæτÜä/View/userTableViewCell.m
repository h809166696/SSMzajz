//
//  userTableViewCell.m
//  yuanZhengTong
//
//  Created by jack on 2017/10/21.
//  Copyright © 2017年 tianyixin. All rights reserved.
//

#import "userTableViewCell.h"

@implementation userTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
