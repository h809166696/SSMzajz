//
//  userManager.h
//  yuanZhengTong
//
//  Created by jack on 2017/10/21.
//  Copyright © 2017年 tianyixin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "UserModel.h"
@interface userManager : NSObject
+(void)writeToToken:(NSDictionary *)token;
+(void)userMessageWriteToFile:(UserMessageModel *)model;
+(NSString *)getUserToken;
+(UserMessageModel *)getUserModel;
+(void)logOut;

@end
