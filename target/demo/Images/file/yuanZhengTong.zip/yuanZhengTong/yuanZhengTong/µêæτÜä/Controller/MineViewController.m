//
//  MineViewController.m
//  yuanZhengTong
//
//  Created by jack on 2017/10/17.
//  Copyright © 2017年 tianyixin. All rights reserved.
//

#import "MineViewController.h"
#import "MasonryTestVC3.h"
#import "UserModel.h"
#import "userTableViewCell.h"
#import "JXLayoutButton.h"
#import "loginViewController.h"
#import "userManager.h"
#import "yiJianFanKuiViewController.h"
#import "aboutViewController.h"
#import "userMessageViewController.h"
#import "CalculatorViewController.h"
#import "qianDaoViewController.h"
@interface MineViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic,strong)UITableView *userTableView;
@property (nonatomic,strong)NSMutableArray *dataArray;
@end

@implementation MineViewController
static NSString *celLReuse = @"cellReuse";
-(NSMutableArray *)dataArray{
    if (_dataArray == nil) {
        _dataArray = [[NSMutableArray alloc]init];
    }
    return _dataArray;
}
-(UITableView *)userTableView{
    if (_userTableView == nil) {
        _userTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, WIDTH, HEIGHT - TAB_BAR_HEIGHT) style:UITableViewStylePlain];
        [_userTableView registerNib:[UINib nibWithNibName:@"userTableViewCell" bundle:nil] forCellReuseIdentifier:celLReuse];
        _userTableView.rowHeight = 54;
        _userTableView.delegate = self;
        _userTableView.backgroundColor = [UIColor whiteColor];
        _userTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        
        _userTableView.dataSource = self;
        [self.view addSubview:_userTableView];
    }
    return _userTableView;
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    NSLog(@"---%@",[userManager getUserModel].ID);
    if (skyStringIsEmpty([userManager getUserToken])) {
        [self loginOut];
    }else
    {
        [self loginSuc];
    }
    self.navigationController.navigationBarHidden = YES;
}
-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    self.navigationController.navigationBarHidden = NO;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    if (IOS11) {
        self.userTableView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
    }else
    {
        self.automaticallyAdjustsScrollViewInsets = NO;
    }
    NSArray *imageNameArray = @[@"coupon",@"friends_recommend",@"calculator",@"security_center",@"feedback",@"about_us"];
     NSArray *NameArray = @[@"优惠券",@"好友推荐",@"计算器",@"安全中心",@"意见反馈",@"关于我们"];
    for (int i = 0; i<imageNameArray.count; i++) {
        UserModel *model = [[UserModel alloc]init];
        model.imageName = imageNameArray[i];
        model.name = NameArray[i];
        [self.dataArray addObject:model];
    }
    self.userTableView.tableHeaderView = [self createTableHeaderView];
    [self.userTableView reloadData];

}
-(UIView *)createTableHeaderView
{
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, WIDTH, NAVIGATION_BAR_HEIGHT+120)];
    view.backgroundColor = HJ_defaultOrange;
    JXLayoutButton *userButton = [JXLayoutButton buttonWithType:UIButtonTypeCustom];
    [userButton setImage:[UIImage imageNamed:@"ic_launcher"] forState:UIControlStateNormal];
    [userButton setTitle:@"注册/登录" forState:UIControlStateNormal];
    userButton.tag = 999;
    [userButton addTarget:self action:@selector(userButtonClick) forControlEvents:UIControlEventTouchUpInside];
    userButton.titleLabel.font = [UIFont systemFontOfSize:14];
    userButton.frame = CGRectMake(0, NAVIGATION_BAR_HEIGHT, WIDTH, 85);
     userButton.imageSize = CGSizeMake(50, 50);
    userButton.layoutStyle = JXLayoutButtonStyleUpImageDownTitle;
    [view addSubview:userButton];
    
    
    UILabel *navigationTitleLabel = [[UILabel alloc]initWithFrame:CGRectMake((WIDTH/2 - 75), STATUS_BAR_HEIGHT+10, 150, 20)];
    navigationTitleLabel.tag = 992;
    navigationTitleLabel.textAlignment = NSTextAlignmentCenter;
    navigationTitleLabel.textColor = [UIColor whiteColor];
    navigationTitleLabel.font = [UIFont systemFontOfSize:16];
    navigationTitleLabel.text = @"";
    [view addSubview:navigationTitleLabel];
    
    UIButton *qianDaoButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [qianDaoButton setBackgroundImage:[UIImage imageNamed:@"ic_toolbar_sign_in"] forState:UIControlStateNormal];
    qianDaoButton.tag = 991;
    [qianDaoButton addTarget:self action:@selector(qianDaoButtonClick) forControlEvents:UIControlEventTouchUpInside];
    qianDaoButton.frame = CGRectMake(WIDTH - 40, STATUS_BAR_HEIGHT+10, 25, 25);
    [view addSubview:qianDaoButton];
    UIView *whiteView = [[UIView alloc]initWithFrame:CGRectMake(0, view.height - 15, WIDTH, 15)];
    whiteView.backgroundColor = [UIColor whiteColor];
    [view addSubview:whiteView];
    
    return view;
    
}
#pragma mark---签到按钮方法
-(void)qianDaoButtonClick{
    qianDaoViewController *qianDaoVc = [[qianDaoViewController alloc]init];
    [self.navigationController pushViewController:qianDaoVc animated:YES];
}
-(void)userButtonClick
{
    if (skyStringIsEmpty([userManager getUserToken])) {
        WS(weakSelf);
        loginViewController *loginVC = [[loginViewController alloc]init];
        loginVC.loginB = ^(NSString *Token) {
               [weakSelf loginSuc];
        };
        [self presentViewController:loginVC animated:YES completion:nil];
    }else
    {
//        userMessageViewController *userVC = [[userMessageViewController alloc]init];
//        [self.navigationController pushViewController:userVC animated:YES];
    }

}
#pragma mark--登录成功操作
-(void)loginSuc{
    UserMessageModel *userModel = [userManager getUserModel];
    UIButton *loginButton = [self.userTableView.tableHeaderView viewWithTag:999];
    UIButton *qianDaoButton = [self.userTableView.tableHeaderView viewWithTag:991];
    UILabel *naviLabel = [self.userTableView.tableHeaderView viewWithTag:992];
    qianDaoButton.hidden = NO;
    UIImage *buttonImage;
    if (userModel.userImage != nil) {
        buttonImage = userModel.userImage;
    }else
    {
        buttonImage = [UIImage imageNamed:@"ic_launcher"];
    }
    [loginButton setImage:buttonImage forState:UIControlStateNormal];
    [loginButton setTitle:[NSString stringWithFormat:@"最近登录:%@",userModel.logintime.dateStr] forState:UIControlStateNormal];
    naviLabel.text = userModel.nickname;
    
    self.userTableView.tableFooterView = [self createTableViewFooterView];
    
}
-(UIView *)createTableViewFooterView{
    UIButton *logOutButton = [UIButton buttonWithType:UIButtonTypeCustom];
    logOutButton.frame = CGRectMake(0, 0, WIDTH, 50);
    [logOutButton setBackgroundColor:[UIColor redColor]];
    [logOutButton addTarget:self action:@selector(LogingOutClick) forControlEvents:UIControlEventTouchUpInside];
    [logOutButton setTitle:@"退出登录" forState:UIControlStateNormal];
    [logOutButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    return logOutButton;
}
-(void)LogingOutClick{
    [self showAlertCancleWithTitle:@"温馨提示" message:@"确定要退出登录吗?" confirmHandler:^(UIAlertAction *action) {
        [userManager logOut];
        [self loginOut];
    } cancleHandle:^(UIAlertAction *action) {
        
    }];
    
}
#pragma mark--未登录状态下的操作
-(void)loginOut{
    
    UIButton *loginButton = [self.userTableView.tableHeaderView viewWithTag:999];
    UIButton *qianDaoButton = [self.userTableView.tableHeaderView viewWithTag:991];
    UILabel *naviLabel = [self.userTableView.tableHeaderView viewWithTag:992];
    qianDaoButton.hidden = YES;
    [loginButton setImage:[UIImage imageNamed:@"ic_launcher"] forState:UIControlStateNormal];
    [loginButton setTitle:@"注册/登录" forState:UIControlStateNormal];
    naviLabel.text = @"";
    
    self.userTableView.tableFooterView = nil;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    userTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:celLReuse forIndexPath:indexPath];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.contentView.backgroundColor = skyColorWithHex(0xdddddd);
    UserModel *model = self.dataArray[indexPath.row];
    cell.leftImageView.image = [UIImage imageNamed:model.imageName];
    cell.nameLabel.text = model.name;
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    switch (indexPath.row) {
        case 0:
            {
                
            }
            break;
        case 1:
        {
            
        }
            break;
        case 2:
        {
            CalculatorViewController *calcVC = [[CalculatorViewController alloc]init];
            [self.navigationController pushViewController:calcVC animated:YES];
        }
            break;
        case 3:
        {
            
        }
            break;
        case 4:
        {
            yiJianFanKuiViewController *VC = [[yiJianFanKuiViewController alloc]init];
            [self.navigationController pushViewController:VC animated:YES];
        }
            break;
        case 5:
        {
            aboutViewController *aboutVC = [[aboutViewController alloc]init];
            [self.navigationController pushViewController:aboutVC animated:YES];
        }
            break;
        case 6:
        {
            
        }
            break;
            
        default:
            break;
    }
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
