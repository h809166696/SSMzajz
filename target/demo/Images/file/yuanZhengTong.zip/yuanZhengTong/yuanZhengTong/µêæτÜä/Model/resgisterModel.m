//
//  resgisterModel.m
//  yuanZhengTong
//
//  Created by jack on 2017/10/21.
//  Copyright © 2017年 tianyixin. All rights reserved.
//

#import "resgisterModel.h"

@implementation resgisterModel
+(void)registerGetCode:(NSString *)mobile isResgister:(BOOL)isRegister suc:(registerSUCBlock)sucB Fail:(registerFailBlock)FailB{
    NSString *bodyStr = isRegister?@"user_register_send_sms":@"user_reset_password_send_sms";
    
    [HJHTTPManager requestWithType:SkyHttpRequestTypePost UrlString:[TRUEURLHEAD addStr:bodyStr] Parameters:@{@"mobile":mobile,@"access_token":mobile} SuccessBlock:^(id responseObject) {
        NSLog(@"获取验证码成功");
        @try {
            NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
            sucB([NSString stringWithFormat:@"%@",dic[@"code"]]);
        } @catch (NSException *exception) {
            FailB(nil);
        } @finally {
            
        }
    } FailureBlock:^(NSError *error) {
        FailB(error);
    }];
}
+(void)registerUser:(NSString *)mobile password:(NSString *)password verifyCode:(NSString *)verfiCode suc:(registerSUCBlock)sucB Fail:(registerFailBlock)FailB;{
    [HJHTTPManager requestWithType:SkyHttpRequestTypePost UrlString:[TRUEURLHEAD addStr:@"user_register"] Parameters:@{@"mobile":mobile,@"password":password,@"verifyCode":verfiCode,@"access_token":mobile} SuccessBlock:^(id responseObject) {
        @try {
             NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
             sucB([NSString stringWithFormat:@"%@",dic[@"code"]]);
        } @catch (NSException *exception) {
             FailB(nil);
        } @finally {
            
        }
       
    } FailureBlock:^(NSError *error) {
        FailB(error);
    }];
}
+(void)resetPssword:(NSString *)mobile password:(NSString *)password verifyCode:(NSString *)verfiCode suc:(registerSUCBlock)sucB Fail:(registerFailBlock)FailB{
    [HJHTTPManager requestWithType:SkyHttpRequestTypePost UrlString:[TRUEURLHEAD addStr:@"user_reset_password"] Parameters:@{@"mobile":mobile,@"password":password,@"verifyCode":verfiCode,@"access_token":mobile} SuccessBlock:^(id responseObject) {
        @try {
            NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
            sucB([NSString stringWithFormat:@"%@",dic[@"code"]]);
        } @catch (NSException *exception) {
            FailB(nil);
        } @finally {
            
        }
        
    } FailureBlock:^(NSError *error) {
        FailB(error);
    }];
}
+(void)changeUserMessageWithToken:(NSString *)token email:(NSString *)email sex:(NSString *)sex nickname:(NSString *)nickName suc:(registerSUCBlock)sucB Fail:(registerFailBlock)FailB{
    [HJHTTPManager requestWithType:SkyHttpRequestTypePost UrlString:[TRUEURLHEAD addStr:@"user_info_update"] Parameters:@{@"token":token,@"email":@"",@"sex":sex,@"nickname":nickName} SuccessBlock:^(id responseObject) {
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
        sucB(dic[@"code"]);
    } FailureBlock:^(NSError *error) {
        FailB(error);
    }];
}
+(void)judgeVersion:(void(^)(NSDictionary *dataDic))sucB fail:(registerFailBlock)failb{
    [HJHTTPManager requestWithType:SkyHttpRequestTypeGet UrlString:[TRUEURLHEAD addStr:@"sysconfig_ios_version"] Parameters:@{} SuccessBlock:^(id responseObject) {
        @try {
            NSData *data = [responseObject dataUsingEncoding:NSUTF8StringEncoding];
            NSDictionary *dataDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
            if ([[NSString stringWithFormat:@"%@",dataDic[@"code"]] isEqualToString:@"0"]) {
                sucB(dataDic[@"data"]);
            }else
            {
                failb(nil);
            }
        } @catch (NSException *exception) {
             failb(nil);
        } @finally {
            
        }
    } FailureBlock:^(NSError *error) {
         failb(nil);
    }];
}
@end
