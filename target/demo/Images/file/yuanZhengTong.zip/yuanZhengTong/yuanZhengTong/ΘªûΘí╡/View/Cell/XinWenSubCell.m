//
//  XinWenSubCell.m
//  yuanZhengTong
//
//  Created by hongyj on 2017/10/21.
//  Copyright © 2017年 tianyixin. All rights reserved.
//

#import "XinWenSubCell.h"

@implementation XinWenSubCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
//        self.contentView.translatesAutoresizingMaskIntoConstraints = NO;
        self.descLabel = [[UILabel alloc]init];
        self.descLabel.numberOfLines = 0;
        self.descLabel.preferredMaxLayoutWidth = self.contentView.frame.size.width-10;
        [self.contentView addSubview:self.descLabel];
        [self.descLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.contentView).offset(10);
            make.right.equalTo(self.contentView).offset(-5);
            make.top.equalTo(self.contentView).offset(5);
            make.bottom.equalTo(self.contentView).offset(-5);
        }];
        
    }
    return self;
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
