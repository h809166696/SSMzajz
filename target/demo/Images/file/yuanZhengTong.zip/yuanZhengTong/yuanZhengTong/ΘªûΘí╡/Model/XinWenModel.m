//
//  XinWenModel.m
//  yuanZhengTong
//
//  Created by hongyj on 2017/10/20.
//  Copyright © 2017年 tianyixin. All rights reserved.
//

#import "XinWenModel.h"

@implementation XinWenModel
+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
    return @{@"ID": @"id",@"typeID":@"typeid"};
}
@end
