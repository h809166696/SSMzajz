//
//  FWDKModel.m
//  yuanZhengTong
//
//  Created by hongyj on 2017/10/21.
//  Copyright © 2017年 tianyixin. All rights reserved.
//

#import "FWDKModel.h"

@implementation FWDKModel
+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
    return @{@"ID": @"id",@"typeID":@"typeid",@"descriptionStr":@"description"};
}
+(void)getWangDaiDataWithNum:(NSString *)num suc:(SUCBlock)sucB Fail:(FailBlock)failB{
    NSMutableDictionary *para = [[NSMutableDictionary alloc]init];
    para[@"typeid"] = @2;
    para[@"limit"] = num;
    
    [HJHTTPManager requestWithType:SkyHttpRequestTypeGet UrlString:[TRUEURLHEAD addStr:@"article_list"] Parameters:para SuccessBlock:^(id responseObject) {
        @try {
            NSArray *modelArray = [responseObject hj_dealResponseData:[self class] DataKey:@"data"];
            sucB(modelArray);
        } @catch (NSException *exception) {
            failB(nil);
        } @finally {
            
        }
    } FailureBlock:^(NSError *error) {
        failB(error);
    }];
}
@end
