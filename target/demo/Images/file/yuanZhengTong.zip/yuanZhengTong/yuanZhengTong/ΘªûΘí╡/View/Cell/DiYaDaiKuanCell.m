//
//  DiYaDaiKuanCell.m
//  yuanZhengTong
//
//  Created by hongyj on 2017/10/20.
//  Copyright © 2017年 tianyixin. All rights reserved.
//

#import "DiYaDaiKuanCell.h"
#import "DiYaDaiKuaiCollectionCell.h"
#import <Masonry.h>
#import "BaseDaiKuanVC.h"
@implementation DiYaDaiKuanCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        self.imgArr = [NSArray arrayWithObjects:@"bang.png",@"home.png",@"car.png", nil];
        UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc] init];
        [flowLayout setItemSize:CGSizeMake(DaiKuanRZ_Height, DaiKuanRZ_Height)];
        [flowLayout setScrollDirection:UICollectionViewScrollDirectionHorizontal];
//        flowLayout.sectionInset = UIEdgeInsetsMake(10, 10 , 10, 10);
        CGFloat space = (WIDTH - 40 - 3 * DaiKuanRZ_Height)/2;
        flowLayout.minimumLineSpacing = space;
        UICollectionView *collectionView = [[UICollectionView alloc]initWithFrame:self.contentView.frame collectionViewLayout:flowLayout];
        collectionView.delegate = self;
        collectionView.dataSource = self;
        collectionView.contentInset = UIEdgeInsetsMake(0, 20, 0, 0);
        collectionView.backgroundColor = [UIColor whiteColor];
        collectionView.showsHorizontalScrollIndicator = NO;
        UINib *cellNib = [UINib nibWithNibName:@"DiYaDaiKuaiCollectionCell" bundle:nil];
        [collectionView registerNib:cellNib forCellWithReuseIdentifier:@"cell"];
        [self.contentView addSubview:collectionView];
        [collectionView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.width.equalTo(self.contentView);
            make.height.equalTo(self.contentView);
        }];
        
    }
    return self;
}
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return 3;
}
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    DiYaDaiKuaiCollectionCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"cell" forIndexPath:indexPath];
    cell.iconImage.image = [UIImage imageNamed:self.imgArr[indexPath.row]];
    return cell;
}
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    if (self.iconImageClick) {
        BaseDaiKuanVC *vc = [[BaseDaiKuanVC alloc]init];
        vc.type = (int)indexPath.row+1;
        self.iconImageClick(vc);
    }
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
