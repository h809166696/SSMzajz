//
//  BaseHTMLViewController.m
//  yuanZhengTong
//
//  Created by hongyj on 2017/10/21.
//  Copyright © 2017年 tianyixin. All rights reserved.
//

#import "BaseHTMLViewController.h"
#define TITLE_HEIGHT 44

@interface BaseHTMLViewController ()<UIScrollViewDelegate,UINavigationControllerDelegate>

@end

@implementation BaseHTMLViewController
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:YES animated:animated];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    UIView *statusBar = [[UIView alloc]initWithFrame:CGRectMake(0, 0, WIDTH, 20)];
    statusBar.backgroundColor = [UIColor orangeColor];
    [self.view addSubview:statusBar];
    
    [self.view addSubview: self.scrollView];
    [self.scrollView addSubview:self.headImage];
    
    self.view.backgroundColor = [UIColor whiteColor];
    self.navigationController.delegate = self;
    
    UIView* contentView = [UIView new];
    [self.scrollView addSubview:contentView];
    [contentView addSubview:self.timeLabel];
    [contentView addSubview:self.detailLabel];
    UILabel *placeView = [[UILabel alloc]init];
    [contentView addSubview:placeView];
    [contentView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.scrollView);
        make.width.equalTo(self.scrollView);
        make.height.mas_greaterThanOrEqualTo(HEIGHT-44);
    }];
    [self.timeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.scrollView.mas_top).offset(10);
        make.left.equalTo(self.scrollView.mas_left).offset(10);
        make.right.equalTo(self.scrollView.mas_right).offset(-10);
        make.height.mas_equalTo(20);
    }];
    
    [self.detailLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.timeLabel.mas_bottom).offset(10);
        make.left.equalTo(self.scrollView.mas_left).offset(10);
        make.right.equalTo(self.scrollView.mas_right).offset(-10);
    }];
   
    
    [placeView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.equalTo(self.scrollView);
        make.top.equalTo(self.detailLabel.mas_bottom);
        make.bottom.equalTo(contentView.mas_bottom);
    }];
    
    
    [self.view addSubview:self.topView];
    
    [self.detailLabel setContentHuggingPriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisVertical];
    [placeView setContentHuggingPriority:UILayoutPriorityDefaultLow forAxis:UILayoutConstraintAxisHorizontal];
    
    UIButton *backButton = [UIButton buttonWithType:UIButtonTypeCustom];
    backButton.frame = CGRectMake(5, STATUS_BAR_HEIGHT+12, 20, 20);
    [backButton addTarget:self action:@selector(backClick) forControlEvents:UIControlEventTouchUpInside];
    [backButton setImage:[UIImage imageNamed:@"newfanhui"] forState:UIControlStateNormal];
    [self.view addSubview:backButton];
    [self.view addSubview:self.titleLabel];
    // Do any additional setup after loading the view.
}
- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    CGFloat offsetY = scrollView.contentOffset.y;
    CGRect f = self.headImage.frame;
    f.origin.y= offsetY ;
    f.size.height=  -offsetY;
    self.headImage.frame= f;
    CGFloat pointY = TITLE_HEIGHT;
    if (-offsetY>=pointY) {
        CGRect titleF = self.titleLabel.frame;
        titleF.origin.y = -offsetY-TITLE_HEIGHT+STATUS_BAR_HEIGHT;
        CGFloat scale = (50-20)/(LunBoHeight+STATUS_BAR_HEIGHT-64);
        titleF.origin.x= (LunBoHeight+offsetY)*scale+20;
        titleF.size.width = WIDTH - titleF.origin.x;
        self.titleLabel.frame = titleF;
    }else{
        CGRect titleF = self.titleLabel.frame;
        titleF.origin.y = 20;
        titleF.origin.x= 50;
        titleF.size.width = WIDTH - 50;
        self.titleLabel.frame = titleF;
    }
    if (-offsetY<=pointY) {
        self.topView.alpha = 1;
    }else{
        self.topView.alpha = 0;
    }
    
    
}
- (UILabel *)timeLabel{
    if (!_timeLabel) {
        _timeLabel = [[UILabel alloc]init];
        _timeLabel.textColor = [UIColor grayColor];
        _timeLabel.font = [UIFont systemFontOfSize:13];
        
    }
    return _timeLabel;
}
- (UIView *)topView{
    if (!_topView) {
        _topView = [[UIView alloc]initWithFrame:CGRectMake(0, STATUS_BAR_HEIGHT, WIDTH, 44)];
        _topView.alpha=0;
        _topView.backgroundColor = [UIColor orangeColor];
        
    }
    return _topView;
}
- (UIImageView *)headImage{
    if (!_headImage) {
        _headImage = [[UIImageView alloc]initWithFrame:CGRectMake(0, -LunBoHeight, WIDTH, LunBoHeight)];
        _headImage.contentMode = UIViewContentModeScaleAspectFill;
        _headImage.clipsToBounds = YES;
    }
    return _headImage;
}
- (UILabel *)titleLabel{
    if (!_titleLabel) {
        _titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(10, 20, WIDTH, TITLE_HEIGHT)];
        _titleLabel.backgroundColor = [UIColor clearColor];
        _titleLabel.textColor = [UIColor whiteColor];
        _titleLabel.font = [UIFont fontWithName:@"Helvetica-Bold" size:20];
    }
    return _titleLabel;
}
- (UIScrollView *)scrollView{
    if (!_scrollView) {
        _scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, STATUS_BAR_HEIGHT, WIDTH, HEIGHT)];
        _scrollView.delegate = self;
        _scrollView.bounces = NO;
        _scrollView.contentInset = UIEdgeInsetsMake(LunBoHeight, 0, 0, 0);
    }
    return _scrollView;
}
- (void)backClick{
    [self.navigationController popViewControllerAnimated:YES];
}

- (UILabel *)detailLabel{
    if (!_detailLabel) {
        _detailLabel = [[UILabel alloc]init];
        _detailLabel.numberOfLines = 0;
        _detailLabel.textAlignment = NSTextAlignmentLeft;
        _detailLabel.preferredMaxLayoutWidth = WIDTH-20;
        
    }
    return _detailLabel;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
