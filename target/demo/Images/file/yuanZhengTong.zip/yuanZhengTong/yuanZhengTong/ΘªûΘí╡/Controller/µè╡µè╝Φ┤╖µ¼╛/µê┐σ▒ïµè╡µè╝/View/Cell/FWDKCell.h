//
//  FWDKCell.h
//  yuanZhengTong
//
//  Created by hongyj on 2017/10/21.
//  Copyright © 2017年 tianyixin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FWDKModel.h"
@interface FWDKCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *iconImage;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *detailLabel;
@property (weak, nonatomic) IBOutlet UILabel *timeLabel;
@property (nonatomic,strong)FWDKModel *model;

@end
