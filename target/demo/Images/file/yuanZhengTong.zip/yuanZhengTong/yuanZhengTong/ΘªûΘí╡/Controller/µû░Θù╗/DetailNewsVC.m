//
//  DetailNewsVC.m
//  yuanZhengTong
//
//  Created by hongyj on 2017/10/21.
//  Copyright © 2017年 tianyixin. All rights reserved.
//

#import "DetailNewsVC.h"
#define TITLE_HEIGHT 44
@interface DetailNewsVC ()<UIScrollViewDelegate,UINavigationControllerDelegate>

@end

@implementation DetailNewsVC
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
   [self.navigationController setNavigationBarHidden:YES animated:animated];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view addSubview: self.scrollView];
    [self.scrollView addSubview:self.headImage];
    
    self.view.backgroundColor = [UIColor whiteColor];
    self.navigationController.delegate = self;
    
    UIView* contentView = [UIView new];
    [self.scrollView addSubview:contentView];
    [contentView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.scrollView);
        make.width.equalTo(self.scrollView);
    }];
   
    [contentView addSubview:self.detailLabel];
    [self.detailLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.scrollView.mas_top).offset(50);
        make.left.equalTo(self.scrollView.mas_left).offset(10);
        make.right.equalTo(self.scrollView.mas_right).offset(-10);
        
    }];
    [contentView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.detailLabel.mas_bottom);
    }];
    [self.view addSubview:self.topView];
    [self.view addSubview:self.titleLabel];
    // Do any additional setup after loading the view.
}


- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    CGFloat offsetY = scrollView.contentOffset.y;
    CGRect f = self.headImage.frame;
    f.origin.y= offsetY ;
    f.size.height=  -offsetY;
    self.headImage.frame= f;
    CGFloat pointY = STATUS_BAR_HEIGHT+TITLE_HEIGHT;
    if (-offsetY>=pointY) {
        CGRect titleF = self.titleLabel.frame;
        titleF.origin.y = -offsetY-TITLE_HEIGHT;
        CGFloat scale = (50-20)/(LunBoHeight+STATUS_BAR_HEIGHT-64);
        titleF.origin.x= (LunBoHeight+STATUS_BAR_HEIGHT+offsetY)*scale+20;
        titleF.size.width = WIDTH - titleF.origin.x;
        self.titleLabel.frame = titleF;
    }else{
        CGRect titleF = self.titleLabel.frame;
        titleF.origin.y = 20;
        titleF.origin.x= 50;
        titleF.size.width = WIDTH - 50;
        self.titleLabel.frame = titleF;
    }
    if (-offsetY<=pointY) {
        self.topView.alpha = 1;
    }else{
        self.topView.alpha = 0;
    }
   
    
}
- (UIView *)topView{
    if (!_topView) {
        _topView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, WIDTH, 64)];
        _topView.alpha=0;
        _topView.backgroundColor = [UIColor orangeColor];
        UIButton *backButton = [UIButton buttonWithType:UIButtonTypeCustom];
        backButton.frame = CGRectMake(0, 20, 44, 44);
        [backButton addTarget:self action:@selector(backClick) forControlEvents:UIControlEventTouchUpInside];
        [backButton setImage:[UIImage imageNamed:@"newfanhui"] forState:UIControlStateNormal];
        [_topView addSubview:backButton];
    }
    return _topView;
}
- (UIImageView *)headImage{
    if (!_headImage) {
        _headImage = [[UIImageView alloc]initWithFrame:CGRectMake(0, -LunBoHeight, WIDTH, LunBoHeight)];
        _headImage.image = [UIImage imageNamed:@"default"];
        _headImage.contentMode = UIViewContentModeScaleAspectFill;
        _headImage.clipsToBounds = YES;
    }
    return _headImage;
}
- (UILabel *)titleLabel{
    if (!_titleLabel) {
        _titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(10, 20, WIDTH, TITLE_HEIGHT)];
        _titleLabel.backgroundColor = [UIColor clearColor];
        _titleLabel.textColor = [UIColor whiteColor];
        _titleLabel.text = @"个人信用体系未来会涵盖更多个人信用都能干些什么？";
    }
    return _titleLabel;
}
- (UIScrollView *)scrollView{
    if (!_scrollView) {
        _scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, WIDTH, HEIGHT)];
        _scrollView.delegate = self;
        _scrollView.bounces = NO;
        _scrollView.contentInset = UIEdgeInsetsMake(LunBoHeight, 0, 0, 0);
    }
    return _scrollView;
}
- (void)backClick{
    [self.navigationController popViewControllerAnimated:YES];
}
- (UILabel *)detailLabel{
    if (!_detailLabel) {
        _detailLabel = [[UILabel alloc]init];
        NSString *str = @"<p style=\'margin-top: 0px; margin-bottom: 25px; padding: 0px; line-height: 32px; color: rgb(68, 68, 68); text-align: justify; font-family: &quot;microsoft yahei&quot;, Arial, Helvetica, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\'>&nbsp; &nbsp; &nbsp; 前不久，ofo率先在上海宣布，芝麻信用分达到650可免去99元的租车押金。这样的实惠，提醒了不少人，“个人信用”原来还有这样的好处？其实，“个人信用”在如今的移动金融时代大有用处，现在就让我们一起来了解一下吧。</p><p style=\'margin-top: 0px; margin-bottom: 25px; padding: 0px; line-height: 32px; color: rgb(68, 68, 68); text-align: justify; font-family: &quot;microsoft yahei&quot;, Arial, Helvetica, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\'>　　随着现在消费方式从现金、刷卡到刷支付宝、微信，一些第三方征信机构积累的大量数据给个人信用的打分已经成为很多机构衡量个人“诚信度”的重要依据。芝麻信用带来的共享单车押金的减免也只是其中一项，大到银行贷款，小到租借雨伞、充电宝，个人信用的价值你是否全都知晓？</p><p style=\'margin-top: 0px; margin-bottom: 25px; padding: 0px; line-height: 32px; color: rgb(68, 68, 68); text-align: justify; font-family: &quot;microsoft yahei&quot;, Arial, Helvetica, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\'><strong>　　个人信用都能干些什么？</strong></p><p style=\'margin-top: 0px; margin-bottom: 25px; padding: 0px; line-height: 32px; color: rgb(68, 68, 68); text-align: justify; font-family: &quot;microsoft yahei&quot;, Arial, Helvetica, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\'>　　“在上海我的ofo单车就靠芝麻信用免去了99块钱押金，其实芝麻信用真的用处挺多。”在上海一家金融机构工作的西安人张雨凇感受明显，购物、生活缴费、信用卡还钱大多依靠网络的他积累了748分的芝麻信用，这在芝麻信用里显示为“信用极好”。这个“信用极好”并不是纸上谈兵，而是为他带来了切实的价值。“租车和住酒店可以免押金，连在一些平台租房都可以减免押金，出门在外，还能免费借个充电宝什么的，很方便。”在上海，张雨凇已经习惯了这样有“信用做靠山”的生活，连网购能申请的消费借贷都因为芝麻评分高而获得了高额的额度。</p><p style=\'margin-top: 0px; margin-bottom: 25px; padding: 0px; line-height: 32px; color: rgb(68, 68, 68); text-align: justify; font-family: &quot;microsoft yahei&quot;, Arial, Helvetica, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\'>　　根据芝麻信用发布的《全国城市信用免押服务报告》，全国381个城市已经开启信用免押服务，近2000万人已经享受过免押金的服务，合计免除押金已经超过150亿元。</p><p style=\'margin-top: 0px; margin-bottom: 25px; padding: 0px; line-height: 32px; color: rgb(68, 68, 68); text-align: justify; font-family: &quot;microsoft yahei&quot;, Arial, Helvetica, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\'>　　记者在芝麻信用里看到，自己720分的芝麻分，可以享受借贷、免押金办骑行卡、免押金租车、免押金借伞、免押金租智能手机、享受芝麻套餐的手机合约、在社交网站有高的信誉显示等等。其中，在“信用借还”中，可以根据地图选择你身边最近的商家，从充电宝、雨伞到玩具，都可以芝麻分600以上免押金借用。</p><p style=\'margin-top: 0px; margin-bottom: 25px; padding: 0px; line-height: 32px; color: rgb(68, 68, 68); text-align: justify; font-family: &quot;microsoft yahei&quot;, Arial, Helvetica, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\'>　　“北上广这些大城市，依靠个人信用在生活中能享受的便利很多，目前在西安还有局限。”张雨凇告诉记者，回西安休假的时候他也会偶尔打开芝麻信用，但并不是所有服务能都涵盖。“这需一个过程，越来越多的人重视个人信用，合作的商家和机构也会增多，个人信用的含金量也更好，能覆盖的生活面也自然会广。”张雨凇觉得。</p><p style=\'margin-top: 0px; margin-bottom: 25px; padding: 0px; line-height: 32px; color: rgb(68, 68, 68); text-align: justify; font-family: &quot;microsoft yahei&quot;, Arial, Helvetica, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\'><strong>　　如何更好地维护个人信用？</strong></p><p style=\'margin-top: 0px; margin-bottom: 25px; padding: 0px; line-height: 32px; color: rgb(68, 68, 68); text-align: justify; font-family: &quot;microsoft yahei&quot;, Arial, Helvetica, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\'>　　很多减免业务提到的“芝麻分”，其实是芝麻信用对海量信息数据的综合处理和评估，主要包含了用户信用历史、行为偏好、履约能力、身份特质、人脉关系五个维度。数据来源涵盖了信用卡还款、网购、转账、理财、水电煤缴费、租房信息、住址搬迁历史、社交关系等方面。通过大数据、云计算、机器学习等技术手段，以科学、客观、公正的评分机制综合计算得出。</p><p style=\'margin-top: 0px; margin-bottom: 25px; padding: 0px; line-height: 32px; color: rgb(68, 68, 68); text-align: justify; font-family: &quot;microsoft yahei&quot;, Arial, Helvetica, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\'>　　如何维护和提升自己的个人信用？“一定要了解自己大额债务的情况，一般循环债务总额越小，信用评分可能越高；准时还贷是必须做到的，这也是提高个人信用最佳办法，可能你在很多平台上借款，但一定要记得这些还款日期，即使不能全额还也要按时偿还最低还款额并支付利息。”长期从事金融贷款业务的西安卓信商务信息咨询有限公司经理沈冰也给出了一些建议，除了关注自己的债务和还款，其实个人的消费能力也是信用评分的一个依据，“比如你网购的额度、缴费的多少等等，这些都会影响你的个人信用。”</p><p style=\'margin-top: 0px; margin-bottom: 25px; padding: 0px; line-height: 32px; color: rgb(68, 68, 68); text-align: justify; font-family: &quot;microsoft yahei&quot;, Arial, Helvetica, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\'><strong>　　个人信用体系未来涵盖更多</strong></p><p style=\'margin-top: 0px; margin-bottom: 25px; padding: 0px; line-height: 32px; color: rgb(68, 68, 68); text-align: justify; font-family: &quot;microsoft yahei&quot;, Arial, Helvetica, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\'>　　目前，全国最权威的个人信用体系是中央人民银行征信中心的个人信用信息服务平台，接入了商业银行、农村信用社、信托公司、财务公司、汽车金融公司、小额贷款公司等放贷机构。但随着人们的消费的多样化，个人信用体系如何能覆盖到日常生活中是需要考虑的问题，这也正是类似芝麻信用等之类的第三方征信机构存在的必要。</p><p style=\'margin-top: 0px; margin-bottom: 25px; padding: 0px; line-height: 32px; color: rgb(68, 68, 68); text-align: justify; font-family: &quot;microsoft yahei&quot;, Arial, Helvetica, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\'>　　记者联系到了腾讯集团市场与公关部的赵烨，她也表示，腾讯信用评分及报告就来自于腾讯社交大数据优势，全面覆盖腾讯生态圈8亿活跃用户，通过先进大数据分析技术，准确量化信用风险，有效提供预测准确、性能稳定的信用评分体系及评估报告。</p><p style=\'margin-top: 0px; margin-bottom: 25px; padding: 0px; line-height: 32px; color: rgb(68, 68, 68); text-align: justify; font-family: &quot;microsoft yahei&quot;, Arial, Helvetica, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\'>　　赵烨认为，随着互联网金融的发展，很多并没有建立个人信用记录的个人，未来很多金融机构可能无法对这些用户的信用风险进行准确的判断，而腾讯正可以通过海量数据挖掘和分析技术来预测其风险表现和信用价值，为其建立个人信用评分。另外，未来个人信用体系也将会涵盖生活的更多方面，个人信用带来的经济价值不容被忽视。</p><p style=\'margin-top: 0px; margin-bottom: 25px; padding: 0px; line-height: 32px; color: rgb(68, 68, 68); text-align: justify; font-family: &quot;microsoft yahei&quot;, Arial, Helvetica, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\'><strong>　　【延伸阅读】</strong></p><p style=\'margin-top: 0px; margin-bottom: 25px; padding: 0px; line-height: 32px; color: rgb(68, 68, 68); text-align: justify; font-family: &quot;microsoft yahei&quot;, Arial, Helvetica, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\'><strong>　　互联网巨头纷纷布局移动金融</strong></p><p style=\'margin-top: 0px; margin-bottom: 25px; padding: 0px; line-height: 32px; color: rgb(68, 68, 68); text-align: justify; font-family: &quot;microsoft yahei&quot;, Arial, Helvetica, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\'>　　日前，《中国移动金融市场专题分析2017》报告显示，金融类用户在移动互联网领域渗透率处于提升阶段，其中移动支付规模再创新高，达192.8万亿。而在移动金融APP活跃用户排行中，也频现互联网企业身影。</p><p style=\'margin-top: 0px; margin-bottom: 25px; padding: 0px; line-height: 32px; color: rgb(68, 68, 68); text-align: justify; font-family: &quot;microsoft yahei&quot;, Arial, Helvetica, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\'>　　报告显示，银行服务类应用活跃规模持续增长，建行排名第一，工行、招行紧随其后；而在第三方移动互联网金融服务应用APP的2月份用户活跃度TOP10排名中，不仅有陆金所、天天基金网等专业金融网站，更有位列第一的京东金融，以及蚂蚁聚宝和小米金融等阿里、小米等互联网企业旗下产品。</p><p style=\'margin-top: 0px; margin-bottom: 25px; padding: 0px; line-height: 32px; color: rgb(68, 68, 68); text-align: justify; font-family: &quot;microsoft yahei&quot;, Arial, Helvetica, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\'>　　近年来随着金融类用户在移动互联网领域渗透率的提升，移动金融市场呈现竞合加剧势头，金融机构、通讯运营商、支付公司、互联网企业等主体，围绕核心用户共同完成资金流、信息流、产品服务流的传递，形成了多极主导创新的发展局面。</p><p style=\'margin-top: 0px; margin-bottom: 25px; padding: 0px; line-height: 32px; color: rgb(68, 68, 68); text-align: justify; font-family: &quot;microsoft yahei&quot;, Arial, Helvetica, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\'>　　分析师认为，通过量化金融模型以及智能化算法可以更好判别用户真实的风险承受水平、历史收益目标以及投资风格偏好等市场痛点，满足当前用户对新型金融服务的诉求。因此，金融科技将成为未来移动金融的核心竞争力，甚至将成为平台竞争中的生死线。京东金融就通过金融科技的全面应用，大大提高了反馈效率和风控强度，从而实现用户安全和用户体验的双方面提升。</p><p><br/></p>";
        NSAttributedString * attrStr = [[NSAttributedString alloc] initWithData:[str dataUsingEncoding:NSUnicodeStringEncoding] options:@{ NSDocumentTypeDocumentAttribute: NSHTMLTextDocumentType } documentAttributes:nil error:nil];
        _detailLabel.numberOfLines = 0;
        _detailLabel.preferredMaxLayoutWidth = WIDTH-20;
        _detailLabel.attributedText = attrStr;
    }
    return _detailLabel;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
