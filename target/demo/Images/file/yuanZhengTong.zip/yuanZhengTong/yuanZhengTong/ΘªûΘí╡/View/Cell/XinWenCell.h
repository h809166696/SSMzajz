//
//  XinWenCell.h
//  yuanZhengTong
//
//  Created by hongyj on 2017/10/20.
//  Copyright © 2017年 tianyixin. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void(^newsClick)(UIViewController *vc);
@interface XinWenCell : UITableViewCell<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic,strong)NSArray *dataSourceArr;
@property (nonatomic,copy)newsClick onClick ;
@end
