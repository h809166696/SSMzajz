//
//  MainViewController.h
//  yuanZhengTong
//
//  Created by jack on 2017/10/17.
//  Copyright © 2017年 tianyixin. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface ImageModel:NSObject
@property (nonatomic,copy)NSString *ID;
@property (nonatomic,copy)NSString *title;
@property (nonatomic,copy)NSString *target;
@property (nonatomic,copy)NSString *group_id;
@property (nonatomic,copy)NSString *pic;
@property (nonatomic,copy)NSString *rank;
@property (nonatomic,copy)NSString *is_show;
@end
@interface MainViewController : UIViewController

@end

