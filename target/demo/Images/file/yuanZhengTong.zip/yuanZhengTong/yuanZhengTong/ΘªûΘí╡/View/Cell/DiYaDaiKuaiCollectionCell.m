//
//  DiYaDaiKuaiCollectionCell.m
//  yuanZhengTong
//
//  Created by hongyj on 2017/10/20.
//  Copyright © 2017年 tianyixin. All rights reserved.
//

#import "DiYaDaiKuaiCollectionCell.h"

@implementation DiYaDaiKuaiCollectionCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
