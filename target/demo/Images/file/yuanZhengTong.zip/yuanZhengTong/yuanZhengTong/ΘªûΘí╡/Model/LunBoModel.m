//
//  LunBoModel.m
//  yuanZhengTong
//
//  Created by hongyj on 2017/10/22.
//  Copyright © 2017年 tianyixin. All rights reserved.
//

#import "LunBoModel.h"

@implementation LunBoModel
+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
    return @{@"ID": @"id"};
}
@end
