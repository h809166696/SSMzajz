//
//  FWDKCell.m
//  yuanZhengTong
//
//  Created by hongyj on 2017/10/21.
//  Copyright © 2017年 tianyixin. All rights reserved.
//

#import "FWDKCell.h"

@implementation FWDKCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
- (void)setModel:(FWDKModel *)model{
    hj_setImage(self.iconImage, model.litpic);
    self.titleLabel.text = model.title;
    self.detailLabel.text = model.descriptionStr;
//    self.detailLabel.attributedText = model.attrStr;
    self.detailLabel.lineBreakMode = NSLineBreakByTruncatingTail;
    // 设置字体大小
//    [attrStr addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:12] range:range];
    
//    self.detailLabel.attributedText = attrStr;
    
    NSDate *date = [model.pubdate date];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm"];
    NSString *pubdateStr = [dateFormatter stringFromDate:date];
    self.timeLabel.text = pubdateStr;
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
