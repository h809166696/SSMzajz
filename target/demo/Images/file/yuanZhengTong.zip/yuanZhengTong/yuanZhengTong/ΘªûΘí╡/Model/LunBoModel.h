//
//  LunBoModel.h
//  yuanZhengTong
//
//  Created by hongyj on 2017/10/22.
//  Copyright © 2017年 tianyixin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LunBoModel : NSObject
@property (nonatomic,copy)NSString *ID;
@property (nonatomic,copy)NSString *title;
@property (nonatomic,copy)NSString *target;
@property (nonatomic,copy)NSString *group_id;
@property (nonatomic,copy)NSString *pic;
@property (nonatomic,copy)NSString *rank;
@property (nonatomic,copy)NSString *is_show;
@end
