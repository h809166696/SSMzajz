//
//  MainViewController.m
//  yuanZhengTong
//
//  Created by jack on 2017/10/17.
//  Copyright © 2017年 tianyixin. All rights reserved.
//

#import "MainViewController.h"
#import <SDCycleScrollView.h>
#import "HJHTTPManager.h"
#import <MJExtension.h>
#import "DiYaDaiKuanCell.h"
#import "XinWenCell.h"
#import "BlankViewController.h"
#import "resgisterModel.h"
#define SECTIONHEAD_HEIGHT 40

@interface MainViewController ()<UITableViewDelegate,UITableViewDataSource,SDCycleScrollViewDelegate,UINavigationControllerDelegate>
@property (nonatomic,strong)UITableView *tableView;
@property (nonatomic,strong)SDCycleScrollView *cycleScrollView;

@end
@implementation ImageModel
+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
    return @{@"ID": @"id"};
}
@end
@implementation MainViewController
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:YES animated:animated];
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self judgeVersion];
    self.navigationController.delegate = self;
    __block NSMutableArray *imageArr = [NSMutableArray arrayWithCapacity:0];
    __weak MainViewController *weakSelf = self;
    NSString *url = [TRUEURLHEAD addStr:@"slide_list"];
    [HJHTTPManager requestWithType:SkyHttpRequestTypeGet UrlString:url Parameters:@{@"group_id":@0} SuccessBlock:^(id responseObject) {
        NSArray *arr = [responseObject hj_dealResponseData:[ImageModel class] DataKey:@"data"];
        [arr enumerateObjectsUsingBlock:^(ImageModel *model, NSUInteger idx, BOOL * _Nonnull stop) {
            NSString *imgUrl = [NSString stringWithFormat:@"%@%@",IMGURL,model.pic];
            [imageArr addObject:imgUrl];
        }];
        weakSelf.cycleScrollView.imageURLStringsGroup = imageArr;
        
    } FailureBlock:^(NSError *error) {
        
    }];
    
    
    [self.view addSubview:self.tableView];
    [self.tableView addSubview:self.cycleScrollView];
    
    // Do any additional setup after loading the view.
}
- (UITableView *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, WIDTH, HEIGHT) style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        if (IOS11) {
            _tableView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
        }else
        {
            self.automaticallyAdjustsScrollViewInsets = NO;
        }
        
        _tableView.scrollEnabled = NO;
        _tableView.sectionFooterHeight = 0;
        _tableView.sectionHeaderHeight = SECTIONHEAD_HEIGHT;
        _tableView.contentInset = UIEdgeInsetsMake(LunBoHeight, 0, 0, 0);
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    }
    return _tableView;
}
- (SDCycleScrollView *)cycleScrollView{
    if (!_cycleScrollView) {
        _cycleScrollView = [SDCycleScrollView cycleScrollViewWithFrame:CGRectMake(0, -LunBoHeight, WIDTH, LunBoHeight) delegate:self placeholderImage:[UIImage imageNamed:@"sign_in_bg.jpg"]];
        
    }
    return _cycleScrollView;
}
#pragma mark -SDCycleScrollViewDelegate
- (void)cycleScrollView:(SDCycleScrollView *)cycleScrollView didSelectItemAtIndex:(NSInteger)index{
    
    BlankViewController *vc = [BlankViewController new];
    [self.navigationController pushViewController:vc animated:YES];
}
#pragma mark -UITableViewDelegate
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, WIDTH, SECTIONHEAD_HEIGHT)];
    view.backgroundColor = [UIColor whiteColor];
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(10, 0, WIDTH, SECTIONHEAD_HEIGHT)];
    if (section ==0) {
        label.text = @"抵押贷款";
    }else{
        label.text = @"新闻";
    }
    label.backgroundColor = [UIColor whiteColor];
    [view addSubview:label];
    return view;
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 2;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return 1;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section==0) {
        return DaiKuanRZ_Height;
    }else{
        CGFloat height = HEIGHT-LunBoHeight-SECTIONHEAD_HEIGHT*2-DaiKuanRZ_Height-TAB_BAR_HEIGHT;
        return height;
    }
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.section == 0) {
        DiYaDaiKuanCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell1"];
        if (!cell) {
            cell = [[DiYaDaiKuanCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell1"];
        }
        cell.iconImageClick = ^(UIViewController *vc) {
            [self.navigationController pushViewController:vc animated:YES];
        };
        return cell;
    }else{
        XinWenCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell2"];
        if (!cell) {
            cell = [[XinWenCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell2"];
            
        }
        cell.onClick = ^(UIViewController *vc) {
            [self.navigationController pushViewController:vc animated:YES];
        };
        return cell;
    }
    return nil;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark--判断版本号
-(void)judgeVersion{
    NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
    NSString *app_build = [infoDictionary objectForKey:@"CFBundleShortVersionString"];
    WS(weakSelf);
  
    [resgisterModel judgeVersion:^(NSDictionary *dataDic) {
        NSString *versionValue = dataDic[@"value"];
        NSString *str = [weakSelf judgeVersionFunc:versionValue secondStr:app_build];
        [[NSUserDefaults standardUserDefaults] setObject:str forKey:IOSVersionJudge];
        [[NSUserDefaults standardUserDefaults] synchronize];
        if ([str isEqualToString:@"1"]) {
            [weakSelf showAlertCancleWithTitle2:[NSString stringWithFormat:@"%@版本已上线",dataDic[@"value"]] leftButtonTitle:@"更新" message:dataDic[@"info"] confirmHandler:^(UIAlertAction *action) {
                 NSString *str = [NSString stringWithFormat:@"itms-apps://itunes.apple.com/app/id%@", @"1166846252"];
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:str] options:NULL completionHandler:^(BOOL success) {
                    
                }];
//                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:str]];
               
            } cancleHandle:^(UIAlertAction *action) {
                
            }];
//            [weakSelf showAlertCancleWithTitle:[NSString stringWithFormat:@"%@版本已上线",dataDic[@"value"]] message:dataDic[@"info"] confirmHandler:^(UIAlertAction *action) {
//
//            } cancleHandle:^(UIAlertAction *action) {
//
//            }];
        }
    } fail:^(NSError *error) {
        [[NSUserDefaults standardUserDefaults] setObject:@"-1" forKey:IOSVersionJudge];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }];
}
-(NSString *)judgeVersionFunc:(NSString *)fristStr secondStr:(NSString *)secondStr{

    NSMutableArray *firstArray = (NSMutableArray *)[fristStr componentsSeparatedByString:@"."];
    if ([[firstArray lastObject] isEqualToString:@"0"]) {
        [firstArray removeLastObject];
    }
    NSMutableArray *secondArray = (NSMutableArray *)[secondStr componentsSeparatedByString:@"."];
    if ([[secondArray lastObject] isEqualToString:@"0"]) {
        [secondArray removeLastObject];
    }
    int count = (int)(firstArray.count > secondArray.count ? secondArray.count:firstArray.count);
    for (int i = 0; i<count; i++) {
        int num1 = [firstArray[i] intValue];
        int num2 = [secondArray[i] intValue];
        if (num1 > num2) {
            return @"1";
            break;
        }
        if (num1 < num2) {
            return @"-1";
            break;
        }
    }
    if (firstArray.count == secondArray.count) {
        return @"0";
    }else
    {
        return firstArray.count > secondArray.count? @"1":@"-1";
    }
    
}
/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end

