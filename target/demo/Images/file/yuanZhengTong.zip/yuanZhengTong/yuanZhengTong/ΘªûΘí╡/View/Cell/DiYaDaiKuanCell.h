//
//  DiYaDaiKuanCell.h
//  yuanZhengTong
//
//  Created by hongyj on 2017/10/20.
//  Copyright © 2017年 tianyixin. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void(^collectionClick)(UIViewController *vc);
@interface DiYaDaiKuanCell : UITableViewCell<UICollectionViewDelegate,UICollectionViewDataSource>
@property (nonatomic,strong)NSArray *imgArr;

@property (nonatomic,copy)collectionClick iconImageClick ;
@end
