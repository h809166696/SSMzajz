//
//  XinWenCell.m
//  yuanZhengTong
//
//  Created by hongyj on 2017/10/20.
//  Copyright © 2017年 tianyixin. All rights reserved.
//

#import "XinWenCell.h"
#import "XinWenModel.h"
#import "XinWenSubCell.h"
#import "DetailNewsVC.h"
#import "BaseHTMLViewController.h"
@implementation XinWenCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.translatesAutoresizingMaskIntoConstraints = NO;
        [SVProgressHUD show];
        UITableView *tablview = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStylePlain];
        tablview.delegate = self;
        tablview.dataSource = self;
        tablview.separatorStyle = UITableViewCellSeparatorStyleNone;
        tablview.rowHeight = UITableViewAutomaticDimension;
        tablview.estimatedRowHeight = 100;
        
        [self.contentView addSubview:tablview];
        [tablview mas_makeConstraints:^(MASConstraintMaker *make) {
            make.width.equalTo(self.contentView);
            make.height.equalTo(self.contentView);
        }];
        __weak XinWenCell *weakSelf = self;
        [HJHTTPManager requestWithType:SkyHttpRequestTypeGet UrlString:@"http://jdb.tianluo.net.cn/dataApi/article_home_list" Parameters:@{} SuccessBlock:^(id responseObject) {
            [SVProgressHUD dismiss];
            NSArray *arr = [responseObject hj_dealResponseData:[XinWenModel class] DataKey:@"data"];
            weakSelf.dataSourceArr = arr;
            [tablview reloadData];
        } FailureBlock:^(NSError *error) {
            [SVProgressHUD showErrorWithStatus:@"请求失败,请稍后再试"];
        }];
    }
    return self;
}
- (NSInteger )tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 5;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    XinWenSubCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        cell = [[XinWenSubCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    XinWenModel *model = self.dataSourceArr[indexPath.row];
    cell.descLabel.text = model.title;
    return cell;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return UITableViewAutomaticDimension;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    XinWenModel *model = self.dataSourceArr[indexPath.row];
    BaseHTMLViewController *htmlVC = [[BaseHTMLViewController alloc]init];
    htmlVC.titleLabel.text = model.title;
    NSDate *date = [model.pubdate date];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm"];
    NSString *pubdateStr = [dateFormatter stringFromDate:date];
    htmlVC.timeLabel.text = pubdateStr;
    NSAttributedString * attrStr = [[NSAttributedString alloc] initWithData:[model.body dataUsingEncoding:NSUnicodeStringEncoding] options:@{ NSDocumentTypeDocumentAttribute: NSHTMLTextDocumentType } documentAttributes:nil error:nil];
    htmlVC.detailLabel.attributedText = attrStr;
    hj_setImage(htmlVC.headImage, model.litpic);
    if (self.onClick) {
        self.onClick(htmlVC);
    }
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
