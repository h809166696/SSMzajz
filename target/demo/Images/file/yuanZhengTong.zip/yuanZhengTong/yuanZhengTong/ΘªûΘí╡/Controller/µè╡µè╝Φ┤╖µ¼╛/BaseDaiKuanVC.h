//
//  BaseDaiKuanVC.h
//  yuanZhengTong
//
//  Created by hongyj on 2017/10/21.
//  Copyright © 2017年 tianyixin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseDaiKuanVC : UIViewController

@property (nonatomic,strong)UITableView *tableView;
@property (nonatomic,assign)int count;
@property (nonatomic,assign)int type;//1：银行代办；2：房屋抵押；3：汽车抵押
@property (nonatomic,strong)NSMutableArray *dataArray;
@end
