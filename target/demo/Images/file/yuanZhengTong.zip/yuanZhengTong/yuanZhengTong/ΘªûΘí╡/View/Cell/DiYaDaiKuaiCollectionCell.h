//
//  DiYaDaiKuaiCollectionCell.h
//  yuanZhengTong
//
//  Created by hongyj on 2017/10/20.
//  Copyright © 2017年 tianyixin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DiYaDaiKuaiCollectionCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *iconImage;

@end
