//
//  XinWenModel.h
//  yuanZhengTong
//
//  Created by hongyj on 2017/10/20.
//  Copyright © 2017年 tianyixin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XinWenModel : NSObject
@property (nonatomic,copy)NSString *ID;//
@property (nonatomic,copy)NSString *typeID;//
@property (nonatomic,copy)NSString *tuijian;
@property (nonatomic,copy)NSString *click;
@property (nonatomic,copy)NSString *title;
@property (nonatomic,copy)NSString *body;
@property (nonatomic,copy)NSString *writer;
@property (nonatomic,copy)NSString *source;
@property (nonatomic,copy)NSString *litpic;
@property (nonatomic,copy)NSString *pubdate;
@property (nonatomic,copy)NSString *addtime;
@property (nonatomic,copy)NSString *keywords;
@property (nonatomic,copy)NSString *seotitle;
@property (nonatomic,copy)NSString *descriptionStr;//
@property (nonatomic,copy)NSString *ischeck;
@property (nonatomic,copy)NSString *typeid2;
@property (nonatomic,copy)NSString *user_id;
@end
