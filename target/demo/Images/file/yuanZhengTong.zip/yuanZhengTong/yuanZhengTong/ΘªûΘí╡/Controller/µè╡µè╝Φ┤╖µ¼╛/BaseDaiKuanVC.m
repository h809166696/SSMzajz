//
//  BaseDaiKuanVC.m
//  yuanZhengTong
//
//  Created by hongyj on 2017/10/21.
//  Copyright © 2017年 tianyixin. All rights reserved.
//

#import "BaseDaiKuanVC.h"
#import "FWDKModel.h"
#import "FWDKCell.h"
#import "BaseHTMLViewController.h"
#import <SDCycleScrollView.h>
#import "LunBoModel.h"
#import "BlankViewController.h"
#define HEADVIEW_HEIGHT 200*SCREEN_SCALE
#define DATACOUNT 10
@interface BaseDaiKuanVC ()<UITableViewDelegate,UITableViewDataSource,SDCycleScrollViewDelegate>
@property (nonatomic,strong)SDCycleScrollView *cycleScrollView;
@end

@implementation BaseDaiKuanVC
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:NO animated:animated];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    switch (self.type) {
        case 1:
            self.title=@"银行代办";
            break;
        case 2:
            self.title=@"房屋抵押";
            break;
        case 3:
            self.title=@"汽车抵押";
            break;
        default:
            break;
    }
    
   
    self.view.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.cycleScrollView];
    UIView *grayView = [[UIView alloc]initWithFrame:CGRectMake(0, HEADVIEW_HEIGHT-10, WIDTH, 10)];
    grayView.backgroundColor = [UIColor lightGrayColor];
    [self.view addSubview:grayView];
    [self.view addSubview:self.tableView];
    [self bindRefrsh];
    [self.tableView.mj_header beginRefreshing];
    
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.equalTo(self.view);
        make.top.equalTo(grayView.mas_bottom);
        make.bottom.equalTo(self.view.mas_bottom);
    }];
    __block NSMutableArray *imageArr = [NSMutableArray arrayWithCapacity:0];
    NSString *url = [TRUEURLHEAD addStr:@"slide_list"];
    WS(weakSelf);
    [HJHTTPManager requestWithType:SkyHttpRequestTypeGet UrlString:url Parameters:@{@"group_id":[NSNumber numberWithInt:self.type]} SuccessBlock:^(id responseObject) {
        NSArray *arr = [responseObject hj_dealResponseData:[LunBoModel class] DataKey:@"data"];
        [arr enumerateObjectsUsingBlock:^(LunBoModel *model, NSUInteger idx, BOOL * _Nonnull stop) {
            NSString *imgUrl = [NSString stringWithFormat:@"%@%@",IMGURL,model.pic];
            [imageArr addObject:imgUrl];
        }];
        weakSelf.cycleScrollView.imageURLStringsGroup = imageArr;

    } FailureBlock:^(NSError *error) {

    }];
    // Do any additional setup after loading the view.
}
- (SDCycleScrollView *)cycleScrollView{
    if (!_cycleScrollView) {
        _cycleScrollView = [SDCycleScrollView cycleScrollViewWithFrame:CGRectMake(0, NAVIGATION_BAR_HEIGHT, WIDTH, HEADVIEW_HEIGHT-74) delegate:self placeholderImage:nil];
        
    }
    return _cycleScrollView;
}
#pragma mark -SDCycleScrollViewDelegate
- (void)cycleScrollView:(SDCycleScrollView *)cycleScrollView didSelectItemAtIndex:(NSInteger)index{
    
    BlankViewController *vc = [BlankViewController new];
    [self.navigationController pushViewController:vc animated:YES];
}
-(NSMutableArray *)dataArray
{
    if (_dataArray == nil) {
        _dataArray = [[NSMutableArray alloc]init];
    }
    return _dataArray;
}
#pragma mark---绑定刷新
-(void)bindRefrsh
{
    WS(weakSelf);
    
    self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        _count = 10;
        [weakSelf getData:[NSString stringWithFormat:@"%d",_count]];
    }];
    self.tableView.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        _count += 10;
        [weakSelf getData:[NSString stringWithFormat:@"%d",_count]];
    }];
    //    self.tableView.mj_footer = [MJRefreshAutoFooter footerWithRefreshingBlock:^{
    //        _count += 10;
    //        [weakSelf getData:[NSString stringWithFormat:@"%d",_count]];
    //    }];
}
#pragma mark--获取数据
-(void)getData:(NSString *)num{
    WS(weakSelf);
    NSMutableDictionary *para = [[NSMutableDictionary alloc]init];
    para[@"typeid"] = [NSNumber numberWithInt:self.type];
    para[@"limit"] = num;
    
    [HJHTTPManager requestWithType:SkyHttpRequestTypeGet UrlString:[TRUEURLHEAD addStr:@"article_list"] Parameters:para SuccessBlock:^(id responseObject) {
        @try {
            NSArray *modelArray = [responseObject hj_dealResponseData:[FWDKModel class] DataKey:@"data"];
            [weakSelf.dataArray removeAllObjects];
            [weakSelf.dataArray addObjectsFromArray:modelArray];
            [weakSelf.tableView.mj_header endRefreshing];
            if (modelArray.count < _count) {
                [weakSelf.tableView.mj_footer endRefreshingWithNoMoreData];
            }else
            {
                [weakSelf.tableView.mj_footer endRefreshing];
            }
            [weakSelf.tableView reloadData];
        } @catch (NSException *exception) {
        } @finally {
            
        }
    } FailureBlock:^(NSError *error) {
        if (_count != 10) {
            _count = _count - 10;
        }
        [weakSelf.tableView.mj_header endRefreshing];
        [weakSelf.tableView.mj_footer endRefreshing];
        [SVProgressHUD showErrorWithStatus:@"请求失败,请稍后再试"];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [SVProgressHUD dismiss];
        });
    }];
}
- (UITableView *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:[UIScreen mainScreen].bounds style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        if (IOS11) {
            _tableView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
        }else
        {
            self.automaticallyAdjustsScrollViewInsets = NO;
        }
        _tableView.estimatedRowHeight = 0;
        _tableView.tableFooterView = [UIView new];
        _tableView.estimatedSectionFooterHeight = 0;
        _tableView.estimatedSectionHeaderHeight = 0;
        UINib *cellNib = [UINib nibWithNibName:@"FWDKCell" bundle:nil];
        [_tableView registerNib:cellNib forCellReuseIdentifier:@"FWDKCell"];
    }
    return _tableView;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 100;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.dataArray.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    FWDKCell *cell = [tableView dequeueReusableCellWithIdentifier:@"FWDKCell" forIndexPath:indexPath];
    FWDKModel *model = self.dataArray[indexPath.row];
    cell.model = model;
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    FWDKModel *model = self.dataArray[indexPath.row];
    BaseHTMLViewController *htmlVC = [[BaseHTMLViewController alloc]init];
    htmlVC.titleLabel.text = model.title;
    NSDate *date = [model.pubdate date];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm"];
    NSString *pubdateStr = [dateFormatter stringFromDate:date];
    htmlVC.timeLabel.text = pubdateStr;
    NSAttributedString * attrStr = [[NSAttributedString alloc] initWithData:[model.body dataUsingEncoding:NSUnicodeStringEncoding] options:@{ NSDocumentTypeDocumentAttribute: NSHTMLTextDocumentType } documentAttributes:nil error:nil];
    htmlVC.detailLabel.attributedText = attrStr;
    hj_setImage(htmlVC.headImage, model.litpic);
    [self.navigationController pushViewController:htmlVC animated:YES];

}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
