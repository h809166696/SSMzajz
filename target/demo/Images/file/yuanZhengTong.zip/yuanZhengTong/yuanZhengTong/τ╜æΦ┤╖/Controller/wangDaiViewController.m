//
//  wangDaiViewController.m
//  yuanZhengTong
//
//  Created by jack on 2017/10/17.
//  Copyright © 2017年 tianyixin. All rights reserved.
//

#import "wangDaiViewController.h"
#import "wangDaiModel.h"
#import "wangDaiCollectionViewCell.h"
#import "WebDetailViewController.h"
@interface wangDaiViewController ()<UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>
@property (nonatomic,strong)UICollectionView *wangDaiCollectionView;
@property (nonatomic,strong)NSMutableArray   *dataArray;
@property (nonatomic,assign)int              count;
@end

@implementation wangDaiViewController
static NSString *celLReuse = @"cellresue";
-(NSMutableArray *)dataArray
{
    if (_dataArray == nil) {
        _dataArray = [[NSMutableArray alloc]init];
    }
    return _dataArray;
}
-(UICollectionView *)wangDaiCollectionView
{
    if (_wangDaiCollectionView == nil) {
        UICollectionViewFlowLayout *layOut = [[UICollectionViewFlowLayout alloc]init];
//        layOut.sectionInset = UIEdgeInsetsMake(0, 10, 0, 10);
        _wangDaiCollectionView = [[UICollectionView alloc]initWithFrame:[UIScreen mainScreen].bounds collectionViewLayout:layOut];
        _wangDaiCollectionView.delegate = self;
        _wangDaiCollectionView.dataSource = self;
        _wangDaiCollectionView.backgroundColor = kColorWithHex(0xdddddd);
        _wangDaiCollectionView.frame =CGRectMake(0, STATUS_BAR_HEIGHT, WIDTH, HEIGHT - TAB_BAR_HEIGHT - STATUS_BAR_HEIGHT);
        [_wangDaiCollectionView registerNib:[UINib nibWithNibName:@"wangDaiCollectionViewCell" bundle:nil] forCellWithReuseIdentifier:celLReuse];
        [self.view addSubview:_wangDaiCollectionView];
    }
    return _wangDaiCollectionView;
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = YES;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self fillStatus];
    self.count = 10;
    [self bindRefrsh];
    [self.wangDaiCollectionView.mj_header beginRefreshing];
    self.navigationController.navigationBarHidden = YES;
    if (IOS11) {
        self.wangDaiCollectionView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
    }else
    {
        self.automaticallyAdjustsScrollViewInsets = NO;
    }
    
    // Do any additional setup after loading the view.
}
#pragma mark--给状态栏弄一层橘黄色
-(void)fillStatus
{
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, WIDTH, STATUS_BAR_HEIGHT)];
    view.backgroundColor = HJ_defaultOrange;
    [self.view addSubview:view];
}
#pragma mark---绑定刷新
-(void)bindRefrsh
{
    WS(weakSelf);
    self.wangDaiCollectionView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        _count = 10;
        [weakSelf getData:[NSString stringWithFormat:@"%d",_count]];
    }];
    self.wangDaiCollectionView.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        _count += 10;
        [weakSelf getData:[NSString stringWithFormat:@"%d",_count]];
    }];
}
#pragma mark--获取数据
-(void)getData:(NSString *)num{
    WS(weakSelf);
    [wangDaiModel getWangDaiDataWithNum:num suc:^(NSArray *modelArray) {
        
        [weakSelf.dataArray removeAllObjects];
        [weakSelf.dataArray addObjectsFromArray:modelArray];
        [self.wangDaiCollectionView.mj_header endRefreshing];
         [weakSelf.wangDaiCollectionView.mj_header endRefreshing];
        if (modelArray.count < _count) {
           [weakSelf.wangDaiCollectionView.mj_footer endRefreshingWithNoMoreData];
        }else
        {
             [weakSelf.wangDaiCollectionView.mj_footer endRefreshing];
        }
        [weakSelf.wangDaiCollectionView reloadData];
       
    } Fail:^(NSError *error) {
        if (_count != 10) {
            _count = _count - 10;
        }
         [weakSelf.wangDaiCollectionView.mj_header endRefreshing];
         [weakSelf.wangDaiCollectionView.mj_footer endRefreshing];
        [SVProgressHUD showErrorWithStatus:@"请求失败,请稍后再试"];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [SVProgressHUD dismiss];
        });
    }];
}

#pragma mark---UICollectionViewDelegateAndDataSource
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.dataArray.count;
}
- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    wangDaiCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:celLReuse forIndexPath:indexPath];
    wangDaiModel *model = self.dataArray[indexPath.row];
    hj_setImage(cell.HeadImageview, model.pic);
    cell.wangDaiTitlelabel.text = model.title;
    cell.bodyLabel.text = model.body;
    cell.NameLabel.text = model.appname;
    cell.moneyLabel.text = model.money;
    cell.contentView.backgroundColor = [UIColor whiteColor];
    return cell;
}
-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake((WIDTH/2-1), 150);
}
- (CGFloat) collectionView:(UICollectionView *)collectionView
                    layout:(UICollectionViewLayout *)collectionViewLayout
minimumInteritemSpacingForSectionAtIndex:(NSInteger)section
{
    return 1;
}
- (CGFloat) collectionView:(UICollectionView *)collectionView
                    layout:(UICollectionViewLayout *)collectionViewLayout
minimumLineSpacingForSectionAtIndex:(NSInteger)section
{
    return 1;
}
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    wangDaiModel *model = self.dataArray[indexPath.row];
    WebDetailViewController *webvc = [[WebDetailViewController alloc]init];
    webvc.webTitle = model.appname;
    webvc.detailUrlStr = model.url;
    [self.navigationController pushViewController:webvc animated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
