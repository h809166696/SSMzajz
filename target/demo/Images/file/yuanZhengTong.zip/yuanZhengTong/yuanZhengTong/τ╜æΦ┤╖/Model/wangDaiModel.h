//
//  wangDaiModel.h
//  yuanZhengTong
//
//  Created by jack on 2017/10/20.
//  Copyright © 2017年 tianyixin. All rights reserved.
//

#import <Foundation/Foundation.h>
typedef void (^SUCBlock)(NSArray *modelArray);
typedef void (^FailBlock)(NSError *error);
@interface wangDaiModel : NSObject
@property (nonatomic,copy)NSString *ID;
@property (nonatomic,copy)NSString *TYPEID;
@property (nonatomic,copy)NSString *url;
@property (nonatomic,copy)NSString *pic;
@property (nonatomic,copy)NSString *appname;
@property (nonatomic,copy)NSString *money;
@property (nonatomic,copy)NSString *title;
@property (nonatomic,copy)NSString *body;
@property (nonatomic,copy)NSString *rank;
@property (nonatomic,copy)NSString *is_show;
+(void)getWangDaiDataWithNum:(NSString *)num suc:(SUCBlock)sucB Fail:(FailBlock)failB;
@end
