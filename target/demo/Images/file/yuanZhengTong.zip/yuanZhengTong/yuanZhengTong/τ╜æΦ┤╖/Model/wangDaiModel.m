//
//  wangDaiModel.m
//  yuanZhengTong
//
//  Created by jack on 2017/10/20.
//  Copyright © 2017年 tianyixin. All rights reserved.
//

#import "wangDaiModel.h"

@implementation wangDaiModel
+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
    return @{@"ID": @"id",@"TYPEID":@"typeid"};
}
+(void)getWangDaiDataWithNum:(NSString *)num suc:(SUCBlock)sucB Fail:(FailBlock)failB{
    NSMutableDictionary *para = [[NSMutableDictionary alloc]init];
    para[@"limit"] = num;
    
    [HJHTTPManager requestWithType:SkyHttpRequestTypeGet UrlString:[TRUEURLHEAD addStr:@"net_loan_list"] Parameters:para SuccessBlock:^(id responseObject) {
        @try {
            NSArray *modelArray = [responseObject hj_dealResponseData:[self class] DataKey:@"data"];
            sucB(modelArray);
        } @catch (NSException *exception) {
            failB(nil);
        } @finally {
            
        }
    } FailureBlock:^(NSError *error) {
        failB(error);
    }];
}
@end
