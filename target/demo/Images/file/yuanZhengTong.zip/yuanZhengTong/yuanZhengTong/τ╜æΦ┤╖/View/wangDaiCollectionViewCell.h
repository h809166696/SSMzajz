//
//  wangDaiCollectionViewCell.h
//  yuanZhengTong
//
//  Created by jack on 2017/10/20.
//  Copyright © 2017年 tianyixin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface wangDaiCollectionViewCell : UICollectionViewCell
@property (strong, nonatomic) IBOutlet UIImageView *HeadImageview;
@property (strong, nonatomic) IBOutlet UILabel *wangDaiTitlelabel;
@property (strong, nonatomic) IBOutlet UILabel *bodyLabel;
@property (strong, nonatomic) IBOutlet UILabel *NameLabel;
@property (strong, nonatomic) IBOutlet UILabel *moneyLabel;

@end
