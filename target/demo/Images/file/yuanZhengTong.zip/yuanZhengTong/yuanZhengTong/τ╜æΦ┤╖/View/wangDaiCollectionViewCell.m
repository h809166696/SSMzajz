//
//  wangDaiCollectionViewCell.m
//  yuanZhengTong
//
//  Created by jack on 2017/10/20.
//  Copyright © 2017年 tianyixin. All rights reserved.
//

#import "wangDaiCollectionViewCell.h"

@implementation wangDaiCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
