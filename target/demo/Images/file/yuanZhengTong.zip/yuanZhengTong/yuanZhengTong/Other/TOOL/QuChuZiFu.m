//
//  QuChuZiFu.m
//  去除字符串想去去除的特殊字符
//
//  Created by mac on 16/7/29.
//  Copyright © 2016年 洪锦. All rights reserved.
//

#import "QuChuZiFu.h"

@implementation QuChuZiFu
+(NSString *)filtrationString:(NSString *)String WithDeleteStringArray:(NSArray *)deleteStringArray
{
    if (String == NULL || [String isEqualToString:@""]) {
        return @"";
    }
    NSMutableString *str1 = [NSMutableString stringWithString:String];
    for (int i = 0; i<deleteStringArray.count; i++) {
        NSRange range = [str1 rangeOfString:deleteStringArray[i]];
        while (range.location != NSNotFound) {
            [str1 deleteCharactersInRange:range];
            range = [str1 rangeOfString:deleteStringArray[i]];
        }
    }
    return str1;

}


@end
