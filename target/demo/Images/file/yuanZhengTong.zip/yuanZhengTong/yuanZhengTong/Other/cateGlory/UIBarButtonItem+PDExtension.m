//
//  UIBarButtonItem+PDExtension.m
//  
//
//  Created by 颜培灯 on 16/7/13.
//
//

#import "UIBarButtonItem+PDExtension.h"
#import "UIView+PDExtension.h"

@implementation UIBarButtonItem (PDExtension)

+ (instancetype)itemWithImage:(NSString *)image highImage:(NSString *)highImage target:(id)target action:(SEL)action
{
    // 自定义按钮
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    // 设置背景图片
    [button setBackgroundImage:[UIImage imageNamed:image] forState:UIControlStateNormal];
    [button setBackgroundImage:[UIImage imageNamed:highImage] forState:UIControlStateHighlighted];
    // 设置按钮尺寸
    button.size = button.currentBackgroundImage.size;
    // 监听点击
    [button addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
    
    return [[self alloc] initWithCustomView:button];
}


@end
