//
//  WLZNavigationController.h
//  WenHuaLvYou
//
//  Created by 颜培灯 on 16/8/15.
//  Copyright © 2016年 颜培灯. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WLZNavigationController : UINavigationController

@end
