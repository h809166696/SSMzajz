//
//  UIViewController+Message.m
//  QRCodeDemo
//
//  Created by huanxin xiong on 2016/12/6.
//  Copyright © 2016年 xiaolu zhao. All rights reserved.
//

#import "UIViewController+Message.h"

@implementation UIViewController (Message)

- (void)showAlertWithTitle:(NSString *)title message:(NSString *)message handler:(void (^)(UIAlertAction *))handler
{
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:handler];
    [alert addAction:action];
    [self presentViewController:alert animated:YES completion:nil];
}
-(void)showAlertCancleWithTitle:(NSString *)title message:(NSString *)message confirmHandler:(void (^) (UIAlertAction *action))handler cancleHandle:(void (^) (UIAlertAction *action))cancleHandler
{
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:handler];
    [alert addAction:action];
     UIAlertAction *action2 = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleDefault handler:cancleHandler];
     [alert addAction:action2];
    [self presentViewController:alert animated:YES completion:nil];
}
-(void)showAlertCancleWithTitle2:(NSString *)title leftButtonTitle:(NSString *)leftButtonTitle message:(NSString *)message confirmHandler:(void (^) (UIAlertAction *action))handler cancleHandle:(void (^) (UIAlertAction *action))cancleHandler
{
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *action = [UIAlertAction actionWithTitle:leftButtonTitle style:UIAlertActionStyleDefault handler:handler];
    [alert addAction:action];
    UIAlertAction *action2 = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleDefault handler:cancleHandler];
    [alert addAction:action2];
    [self presentViewController:alert animated:YES completion:nil];
}
-(void)showErrorMessage{
    [SVProgressHUD showErrorWithStatus:@"请求失败"];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [SVProgressHUD dismiss];
    });
}
-(void)showErrorMessage2WithMessage:(NSString *)message{
    [SVProgressHUD showErrorWithStatus:message];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [SVProgressHUD dismiss];
    });
}
-(void)showinfoMessage:(NSString *)message{
    [SVProgressHUD showInfoWithStatus:message];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [SVProgressHUD dismiss];
    });
}
-(void)showErrorMessageAccordingCode:(NSString *)code{
    if ([code isEqualToString:@""]) {
        
    }
}
@end
