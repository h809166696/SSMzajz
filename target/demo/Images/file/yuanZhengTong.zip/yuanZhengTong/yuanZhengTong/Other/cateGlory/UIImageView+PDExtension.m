//
//  UIImageView+PDExtension.m
//  
//
//  Created by 颜培灯 on 16/7/13.
//
//

#import "UIImageView+PDExtension.h"
#import "UIImageView+WebCache.h"
#import "UIImage+WLZImage.h"

@implementation UIImageView (PDExtension)
- (void)setHeadImage:(NSString *)url palceholder:(NSString *)placeholder
{
    // 设置占位图片, 调用UIImage的分类方法circleImage， 返回一个圆形头像
    UIImage *placeHolder = [[UIImage imageNamed:placeholder] circleImage];
    
    // 加载图片
    [self sd_setImageWithURL:[NSURL URLWithString:url] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        // 判断 如果用户没有设置头像则使用占位图片
        self.image = image ? [image circleImage] : placeHolder;
    }];
}
@end
