//
//  UIButton+HJ.m
//  TravelAssistant
//
//  Created by h809166696 on 2017/6/18.
//  Copyright © 2017年 hj. All rights reserved.
//

#import "UIButton+HJ.h"

@implementation UIButton (HJ)
-(void)hj_setBorderRadius:(CGFloat)radius
{
    self.layer.cornerRadius = radius;
    self.clipsToBounds = YES;
}
@end
