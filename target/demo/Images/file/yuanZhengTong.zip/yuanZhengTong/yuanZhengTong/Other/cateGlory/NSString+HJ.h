//
//  NSString+HJ.h
//  TravelAssistant
//
//  Created by h809166696 on 2017/7/10.
//  Copyright © 2017年 hj. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (HJ)
/**
 **将返回数据转换成数组
 **/
-(NSArray *)hj_dealResponseData:(Class)tmpclass DataKey:(NSString *)datKey;

/**
 **将时间字符串与当前时间对比得到显示的字符串
 **/
-(NSString *)hj_dealDateStr;
/**
 **与当前时间比对0位小，1为大
 **/
-(int)judgeWithNow;
@end
