//
//  UIBarButtonItem+PDExtension.h
//  
//
//  Created by 颜培灯 on 16/7/13.
//
//

#import <UIKit/UIKit.h>

@interface UIBarButtonItem (PDExtension)
+ (instancetype)itemWithImage:(NSString *)image highImage:(NSString *)highImage target:(id)target action:(SEL)action;

@end
