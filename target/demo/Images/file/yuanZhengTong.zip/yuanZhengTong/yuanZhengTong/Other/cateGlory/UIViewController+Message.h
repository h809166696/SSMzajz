//
//  UIViewController+Message.h
//  QRCodeDemo
//
//  Created by huanxin xiong on 2016/12/6.
//  Copyright © 2016年 xiaolu zhao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (Message)

- (void)showAlertWithTitle:(NSString *)title message:(NSString *)message handler:(void (^) (UIAlertAction *action))handler;
-(void)showAlertCancleWithTitle:(NSString *)title message:(NSString *)message confirmHandler:(void (^) (UIAlertAction *action))handler cancleHandle:(void (^) (UIAlertAction *action))cancleHandler;
-(void)showErrorMessage;
-(void)showErrorMessage2WithMessage:(NSString *)message;
-(void)showinfoMessage:(NSString *)message;
-(void)showErrorMessageAccordingCode:(NSString *)code;
-(void)showAlertCancleWithTitle2:(NSString *)title leftButtonTitle:(NSString *)leftButtonTitle message:(NSString *)message confirmHandler:(void (^) (UIAlertAction *action))handler cancleHandle:(void (^) (UIAlertAction *action))cancleHandler;
@end
