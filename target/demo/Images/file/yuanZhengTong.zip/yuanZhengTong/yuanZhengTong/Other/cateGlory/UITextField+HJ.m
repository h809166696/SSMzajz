//
//  UITextField+HJ.m
//  TravelAssistant
//
//  Created by h809166696 on 2017/6/6.
//  Copyright © 2017年 hj. All rights reserved.
//

#import "UITextField+HJ.h"

@implementation UITextField (HJ)
-(void)setTextFiledLeftImage:(NSString*)image margin:(CGFloat)margin
{
    
    UIImage *picImage = [UIImage imageNamed:image];
    CGFloat viewWidth = picImage.size.width+margin;
    UIView *leftView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, viewWidth, self.frame.size.height)];
    leftView.backgroundColor = [UIColor clearColor];
    //添加图片
    UIImageView *headView = [[UIImageView alloc]initWithFrame:CGRectMake(margin, (self.frame.size.height-picImage.size.height)/2, picImage.size.width, picImage.size.height)];
    headView.image = picImage;
    [leftView addSubview:headView];
    
    self.leftView = leftView;
    self.leftViewMode = UITextFieldViewModeAlways;
}
-(void)setTextFieldImgAndMargin:(NSString*)image marginleft:(CGFloat)marginleft marginRight:(CGFloat)marginRight
{
    UIImage *picImage = [UIImage imageNamed:image];
    CGFloat viewWidth = picImage.size.width+marginleft+marginRight;
    UIView *leftView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, viewWidth, self.frame.size.height)];
    leftView.backgroundColor = [UIColor clearColor];
    //添加图片
    UIImageView *headView = [[UIImageView alloc]initWithFrame:CGRectMake(marginleft, (self.frame.size.height-picImage.size.height)/2, picImage.size.width, picImage.size.height)];
    headView.image = picImage;
    [leftView addSubview:headView];
    
    self.leftView = leftView;
    self.leftViewMode = UITextFieldViewModeAlways;
}
-(void)setPlaceHolderTextColor:(UIColor *)color holderFont:(UIFont *)font placeholderStyle:(HJTextFieldholderStyle)HJstyle placeHolder:(NSString *)placeholder
{
    if (color != nil) {
        [self setValue:[UIColor redColor] forKeyPath:@"_placeholderLabel.textColor"];
    }
    if (font != nil) {
        [self setValue:[UIFont boldSystemFontOfSize:16] forKeyPath:@"_placeholderLabel.font"];
    }
     NSMutableParagraphStyle *style = [self.defaultTextAttributes[NSParagraphStyleAttributeName] mutableCopy];
    if (HJstyle == HJTextFieldholderStyleCenter) {
       
        style.alignment = NSTextAlignmentCenter;
        
    }
    
    style.minimumLineHeight = self.font.lineHeight - (self.font.lineHeight - [UIFont systemFontOfSize:14.0].lineHeight) / 2.0;
    
    self.attributedPlaceholder = [[NSAttributedString alloc] initWithString:placeholder
                                  
                                                                 attributes:@{
                                                                              
                                                                              NSForegroundColorAttributeName: [UIColor colorWithRed:255/255.0f green:255/255.0f blue:255/255.0f alpha:0.7f],
                                                                              
                                                                              NSFontAttributeName : [UIFont systemFontOfSize:14.0],
                                                                              
                                                                              NSParagraphStyleAttributeName : style
                                                                              
                                                                              }
                                  
                                  ];
    
}
//-(void)hj_setTextFiledplaceholderColor:(UIColor *)color focusColor:(UIColor *)focusColor
//{
//    
//}
@end
