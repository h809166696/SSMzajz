//
//  HJTextView.m
//  TravelAssistant
//
//  Created by h809166696 on 2017/6/6.
//  Copyright © 2017年 hj. All rights reserved.
//

#import "HJTextView.h"
@interface HJTextView()
@property (nonatomic,strong)UITextView *textView;
@property (nonatomic,strong)UILabel    *placeholderLabel;
@property (nonatomic,strong)UILabel    *countLabel;
@end
@implementation HJTextView
@synthesize contentText=_contentText;
-(instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        self.textView = [[UITextView alloc]initWithFrame:CGRectMake(0, 0, frame.size.width, frame.size.height)];
        
        [self addSubview:self.textView];
        self.placeholderLabel = [[UILabel alloc]initWithFrame:CGRectMake(5, 5, frame.size.width, 20)];
        self.placeholderLabel.textColor = kColorWithHex(0xdddddd);
        [self.textView addSubview:self.placeholderLabel];
        
        UILabel *countlabel = [[UILabel alloc]initWithFrame:CGRectMake(frame.size.width - 90, frame.size.height-20, 80, 20)];
        countlabel.textColor = skyColorWithHex(0xdddddd);
        countlabel.textAlignment = NSTextAlignmentRight;
        countlabel.font = [UIFont systemFontOfSize:13];
        countlabel.text = @"0";
        countlabel.hidden = YES;
        [self addSubview:countlabel];
        self.countLabel = countlabel;
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]init];
        [tap addTarget:self action:@selector(tapLabel)];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(HJtextViewChange:)   name:UITextViewTextDidChangeNotification object:nil];
    }
    return self;
}
//点到label方法
-(void)tapLabel
{
    [self.textView becomeFirstResponder];
}
-(void)setPlaceholder:(NSString *)placeholder
{
    _placeholder = placeholder;
    self.placeholderLabel.text = placeholder;
}
-(void)setTextFont:(UIFont *)textFont
{
    _textFont = textFont;
    self.placeholderLabel.font = textFont;
    self.textView.font = textFont;
}
- (void)setPlaceholderColor:(UIColor *)placeholderColor
{
    _placeholderColor = placeholderColor;
    self.placeholderLabel.textColor = placeholderColor;
}
- (void)setContentColor:(UIColor *)contentColor
{
    _contentColor = contentColor;
    self.textView.textColor = contentColor;
}
- (void)setBackColor:(UIColor *)backColor
{
    _backColor = backColor;
    self.textView.backgroundColor = backColor;
}
//监听输入改变
- (void)HJtextViewChange:(NSNotification *)notification{
    self.countLabel.text = [NSString stringWithFormat:@"%ld",self.textView.text.length];
    self.placeholderLabel.alpha = self.textView.text.length == 0?1:0;
    self.contentText = self.textView.text;
}
-(void)setContentText:(NSString *)contentText
{
    if (_contentText != contentText) {
        _contentText = contentText;
        self.textView.text = contentText;
        self.placeholderLabel.alpha = self.textView.text.length == 0?1:0;
    }

}
- (NSString *)contentText
{
    return self.textView.text;
}
-(void)setShowCountLabel:(BOOL)showCountLabel
{
    _showCountLabel = showCountLabel;
    if (showCountLabel) {
        CGFloat preHeight = self.textView.height;
        self.textView.height = preHeight - 25;
        self.countLabel.hidden = NO;
    }
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
