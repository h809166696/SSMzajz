//
//  UIView+HJ.m
//  TravelAssistant
//
//  Created by h809166696 on 2017/10/17.
//  Copyright © 2017年 hj. All rights reserved.
//

#import "UIView+HJ.h"

@implementation UIView (HJ)
-(void)hj_setRadiusAndShadow:(UIView *)parentView Frame:(CGRect)rect Radius:(CGFloat)radius borderWidth:(CGFloat)borderWidth borderColor:(UIColor *)color shadowOpacity:(CGFloat)shadowOpacity shadowColor:(UIColor *)shadowColor shadowOffset:(CGSize)shadowOffset shadowRadius:(CGFloat)shadowRadius{
    
    UIView *ContentView = [[UIView alloc]init];
    ContentView.frame = rect;
    ContentView.layer.shadowOpacity = shadowOpacity;
    ContentView.layer.shadowColor = shadowColor.CGColor;
    ContentView.layer.shadowRadius = shadowRadius;
    ContentView.layer.shadowOffset = shadowOffset;
    
 
    self.frame = CGRectMake(0, 0, ContentView.width, ContentView.height);
    skyViewBorderRadius(self, radius, borderWidth, color);
    
    [ContentView addSubview:self];
    [parentView addSubview:ContentView];
    
}
-(void)hj_setRadiusAndShadow2:(UIView *)parentView center:(CGPoint)frameCenter bounds:(CGRect)frameBounds Radius:(CGFloat)radius borderWidth:(CGFloat)borderWidth borderColor:(UIColor *)color shadowOpacity:(CGFloat)shadowOpacity shadowColor:(UIColor *)shadowColor shadowOffset:(CGSize)shadowOffset shadowRadius:(CGFloat)shadowRadius{
    UIView *ContentView = [[UIView alloc]init];
    ContentView.bounds = frameBounds;
    ContentView.center = frameCenter;
    ContentView.layer.shadowOpacity = shadowOpacity;
    ContentView.layer.shadowColor = shadowColor.CGColor;
    ContentView.layer.shadowRadius = shadowRadius;
    ContentView.layer.shadowOffset = shadowOffset;
    
    
    self.frame = CGRectMake(0, 0, ContentView.width, ContentView.height);
    skyViewBorderRadius(self, radius, borderWidth, color);
    
    [ContentView addSubview:self];
    [parentView addSubview:ContentView];
}
@end
