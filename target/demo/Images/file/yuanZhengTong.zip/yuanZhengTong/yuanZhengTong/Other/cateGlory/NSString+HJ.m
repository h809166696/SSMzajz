//
//  NSString+HJ.m
//  TravelAssistant
//
//  Created by h809166696 on 2017/7/10.
//  Copyright © 2017年 hj. All rights reserved.
//

#import "NSString+HJ.h"

@implementation NSString (HJ)
-(NSArray *)hj_dealResponseData:(Class)tmpclass DataKey:(NSString *)datKey{

    NSData *data = [self dataUsingEncoding:NSUTF8StringEncoding];
    NSDictionary *dataDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
    if ([[NSString stringWithFormat:@"%@",dataDic[@"code"]] isEqualToString:@"0"]) {
        NSArray *modelArray = [tmpclass mj_objectArrayWithKeyValuesArray:dataDic[datKey]];
        return modelArray;
    }
  return nil;
}
-(int)judgeWithNow
{
    NSDateFormatter *formter = [[NSDateFormatter alloc]init];
    [formter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSTimeZone *zone = [NSTimeZone systemTimeZone];
    [formter setTimeZone:zone];
    NSDate *date = [formter dateFromString:self];
    NSInteger interval1 = [zone secondsFromGMTForDate: date];
    date =[date  dateByAddingTimeInterval: interval1];
    NSDate *date1 = [NSDate date];
    
    
    NSInteger interval = [zone secondsFromGMTForDate: date1];
    NSDate *now = [date1  dateByAddingTimeInterval: interval];
    
    //    NSDate *now = [[NSDate alloc]init];
    NSTimeInterval time = [date timeIntervalSinceDate:now];
    return time > 0? 1:0;
   
}
-(NSString *)hj_dealDateStr{
    NSDateFormatter *formter = [[NSDateFormatter alloc]init];
    [formter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
     NSTimeZone *zone = [NSTimeZone systemTimeZone];
   [formter setTimeZone:zone];
    NSDate *date = [formter dateFromString:self];
 NSInteger interval1 = [zone secondsFromGMTForDate: date];
    date =[date  dateByAddingTimeInterval: interval1];
    NSDate *date1 = [NSDate date];
 
   
    NSInteger interval = [zone secondsFromGMTForDate: date1];
    NSDate *now = [date1  dateByAddingTimeInterval: interval];
    
//    NSDate *now = [[NSDate alloc]init];
    NSTimeInterval time = [now timeIntervalSinceDate:date];
    int day=((int)time)/(3600*24);
    int hour=((int)time)%(3600*24)/3600;
    int minute=((int)time)%(3600*24)/60;
    NSString *returnStr = @"";
    if(day > 10)
    {
        returnStr = self;
    }else if (day != 0 && day < 10){
        
        returnStr = [NSString stringWithFormat:@"%d天前",day];
    }else if (hour != 0){
        returnStr = [NSString stringWithFormat:@"%d小时前",hour];
    }
    else if (minute != 0) {
        returnStr =  [NSString stringWithFormat:@"%d分钟前",minute];
    } else
    {
        returnStr = @"刚刚";
    }
    return returnStr;
}
@end
