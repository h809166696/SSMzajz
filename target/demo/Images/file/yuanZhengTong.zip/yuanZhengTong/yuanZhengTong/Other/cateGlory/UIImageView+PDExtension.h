//
//  UIImageView+PDExtension.h
//  
//
//  Created by 颜培灯 on 16/7/13.
//
//

#import <UIKit/UIKit.h>

@interface UIImageView (PDExtension)
/** 设置圆形头像*/
- (void)setHeadImage:(NSString *)url palceholder:(NSString *)placeholder;
@end
