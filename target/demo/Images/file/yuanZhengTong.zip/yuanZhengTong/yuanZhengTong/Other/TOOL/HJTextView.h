//
//  HJTextView.h
//  TravelAssistant
//
//  Created by h809166696 on 2017/6/6.
//  Copyright © 2017年 hj. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HJTextView : UIView
@property (nonatomic,strong)UIColor *backColor;
@property (nonatomic,strong)UIColor *contentColor;
@property (nonatomic,strong)UIColor *placeholderColor;
@property (nonatomic,strong)NSString *placeholder;
@property (nonatomic,strong)NSString *contentText;
@property (nonatomic,strong)UIFont   *textFont;
@property (nonatomic,assign)BOOL      showCountLabel;
@end
