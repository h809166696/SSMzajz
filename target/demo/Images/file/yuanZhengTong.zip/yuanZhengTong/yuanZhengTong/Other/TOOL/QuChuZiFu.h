//
//  QuChuZiFu.h
//  去除字符串想去去除的特殊字符
//
//  Created by mac on 16/7/29.
//  Copyright © 2016年 洪锦. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface QuChuZiFu : NSObject
+(NSString *)filtrationString:(NSString *)String WithDeleteStringArray:(NSArray *)deleteStringArray;

@end
