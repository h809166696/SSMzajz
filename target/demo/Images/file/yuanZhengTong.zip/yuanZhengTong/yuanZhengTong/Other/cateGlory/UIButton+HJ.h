//
//  UIButton+HJ.h
//  TravelAssistant
//
//  Created by h809166696 on 2017/6/18.
//  Copyright © 2017年 hj. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton (HJ)
-(void)hj_setBorderRadius:(CGFloat)radius;
@end
