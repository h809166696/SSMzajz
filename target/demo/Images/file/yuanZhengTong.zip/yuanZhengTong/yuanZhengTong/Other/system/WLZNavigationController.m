//
//  WLZNavigationController.m
//  WenHuaLvYou
//
//  Created by 颜培灯 on 16/8/15.
//  Copyright © 2016年 颜培灯. All rights reserved.
//

#import "WLZNavigationController.h"

#import "UIView+PDExtension.h"
#import "SVProgressHUD.h"

typedef void (^rightBlock)();
@interface WLZNavigationController ()
@property (nonatomic,assign)BOOL isClear;
@end

@implementation WLZNavigationController
#pragma mark - 在这个方法中初始化公共属性，只会调用一次
+ (void)initialize
{
    // 导航栏标题
    UINavigationBar *bar = [UINavigationBar appearance];
    [bar setTitleTextAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:17],NSForegroundColorAttributeName:[UIColor whiteColor]}];
//    kColorWithHex(0x00a9ff)
    [bar setBarTintColor:HJ_defaultOrange];
    [bar setTintColor:[UIColor whiteColor]];
    UIBarButtonItem *item = [UIBarButtonItem appearance];
    
    // 导航栏item normal
    NSMutableDictionary *itemAttrs = [NSMutableDictionary dictionary];
    itemAttrs[NSFontAttributeName] = [UIFont systemFontOfSize:17];
    itemAttrs[NSForegroundColorAttributeName] = [UIColor whiteColor];
    [item setTitleTextAttributes:itemAttrs forState:UIControlStateNormal];
    
    // 导航栏item disable
    NSMutableDictionary *itemDisabledAttrs = [NSMutableDictionary dictionary];
    itemDisabledAttrs[NSForegroundColorAttributeName] = [UIColor whiteColor];
    [item setTitleTextAttributes:itemDisabledAttrs forState:UIControlStateDisabled];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 如果滑动移除控制器的功能失效，清空代理(让导航控制器重新设置这个功能)
    self.interactivePopGestureRecognizer.delegate = nil;
}

/**
 * 可以在这个方法中拦截所有push进来的控制器
 */
- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    [SVProgressHUD setDefaultMaskType:SVProgressHUDMaskTypeNone];
    [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 0)];
    if (self.childViewControllers.count > 0) { // 如果push进来的不是第一个控制器
        // 自定义按钮
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        // 设置文字及图片
//        [button setTitle:@"返回" forState:UIControlStateNormal];
      
        [button setImage:[UIImage imageNamed:@"newfanhui"] forState:UIControlStateNormal];
        [button setImage:[UIImage imageNamed:@"newfanhui"] forState:UIControlStateHighlighted];
        // 设置尺寸
        button.size = CGSizeMake(70, 30);
        // 让按钮内部的所有内容左对齐
        button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        // 让按钮的内容往左边偏移10
        button.contentEdgeInsets = UIEdgeInsetsMake(0, -10, 0, 0);
        // 设置按钮颜色
        [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [button setTitleColor:[UIColor redColor] forState:UIControlStateHighlighted];
        // 监听点击
        [button addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
        
        // 修改导航栏左边的item
        viewController.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:button];
        
        // 隐藏tabbar
        viewController.hidesBottomBarWhenPushed = YES;

        
        
    }
//    if ([viewController isKindOfClass:[WLZMakeTripViewController class]]||[viewController isKindOfClass:[TravelDetailTableViewController class]]) {
//        self.isClear = YES;
//    }else
//    {
//        self.isClear = NO;
//    }
//    if ([viewController isKindOfClass:[TravelDetailTableViewController class]]) {
//        self.isClear = YES;
//    }else
//    {
//        self.isClear = NO;
//
//    }
    // 这句super的push要放在后面, 让viewController可以覆盖上面设置的leftBarButtonItem
    [super pushViewController:viewController animated:animated];
}

- (void)back
{
    [SVProgressHUD dismiss];
//    SLog(@"%ld",self.childViewControllers.count);
    
    
//    if ([self.viewControllers[self.viewControllers.count-1] isKindOfClass:[TravelDetailTableViewController class]]) {
//       __block int count = 0;
//        [self.viewControllers enumerateObjectsUsingBlock:^(__kindof UIViewController * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
//            if ([obj isKindOfClass:[TravelDetailTableViewController class]]) {
//                count++;
//            }
//        }];
//        if (count>1) {
//            [self popToRootViewControllerAnimated:YES];
//        }else
//        {
//              [self popViewControllerAnimated:YES];
//        }
//    }else
//    {
         [self popViewControllerAnimated:YES];
//    }
   
}
@end
