//
//  UIView+PDExtension.h
//  
//
//  Created by 颜培灯 on 16/7/12.
//
//

#import <UIKit/UIKit.h>
typedef  NS_ENUM(NSUInteger,HJBorderCorner){
    HJBorderCornerTopLeft = 0,
    HJBorderCornerTopRight ,
    HJBorderCornerBottonRight,
    HJBorderCornerBottonLeft
};
@interface UIView (PDExtension)

@property (nonatomic, assign) CGSize size;
@property (nonatomic, assign) CGFloat width;
@property (nonatomic, assign) CGFloat height;
@property (nonatomic, assign) CGFloat x;
@property (nonatomic, assign) CGFloat y;
@property (nonatomic, assign) CGFloat centerX;
@property (nonatomic, assign) CGFloat centerY;
@property (nonatomic,assign)CGFloat   maxX;
@property (nonatomic,assign)CGFloat   maxY;
/**
 * 判断一个控件是否真正显示在主窗口
 */
- (BOOL)isShowingOnKeyWindow;

/**
 * 快速加载xib
 */
+ (instancetype)viewFromXib;
/**
 * 设定某个角圆角
 */
//-(void)setBorder:(HJBorderCorner)corner;
@end
