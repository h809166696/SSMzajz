//
//  WLZTabBarController.m
//  WenHuaLvYou
//
//  Created by 颜培灯 on 16/8/15.
//  Copyright © 2016年 颜培灯. All rights reserved.
//

#import "WLZTabBarController.h"
#import "UIImage+WLZImage.h"
#import "WLZNavigationController.h"
#import "HJHTTPManager.h"
#import "MainViewController.h"
#import "wangDaiViewController.h"
#import "MineViewController.h"
@interface WLZTabBarController ()

@end

@implementation WLZTabBarController

+ (void)initialize
{
    [HJHTTPManager startNetWorkMonitoring];
    // tabBarItem normal
//    NSMutableDictionary *attrs = [[NSMutableDictionary alloc]init];
//    attrs[NSFontAttributeName] = [UIFont systemFontOfSize:12];
//    attrs[NSForegroundColorAttributeName] = [UIColor grayColor];
    NSDictionary *attrs = @{NSFontAttributeName:[UIFont systemFontOfSize:12],NSForegroundColorAttributeName:[UIColor grayColor]};
    // tabBarItem selected
    NSMutableDictionary *selectedAttrs = [NSMutableDictionary dictionary];
    selectedAttrs[NSFontAttributeName] = attrs[NSFontAttributeName];
    // 89 165 225
    selectedAttrs[NSForegroundColorAttributeName] = HJ_defaultOrange;
    
    // tabBarItem
    UITabBarItem *item = [UITabBarItem appearance];
    [item setTitleTextAttributes:attrs forState:UIControlStateNormal];
    [item setTitleTextAttributes:selectedAttrs forState:UIControlStateSelected];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self setupAllChildViewController];
    
//    [self setupAllTitleButton];
}

#pragma mark - 添加所有子控制器
- (void)setupAllChildViewController
{
    MainViewController *MyTravelVC = [[MainViewController alloc]init];
    WLZNavigationController *nav1 = [[WLZNavigationController alloc]initWithRootViewController:MyTravelVC];
    nav1.tabBarItem.title = @"首页";
    nav1.tabBarItem.image = [UIImage imageNamed:@"ic_tab_home_normal"];
    nav1.tabBarItem.selectedImage = [UIImage imageOriginalWithName:@"ic_tab_home_pressed"];
    [self addChildViewController:nav1];
    
    wangDaiViewController *wangDaiVC = [[wangDaiViewController alloc]init];
    WLZNavigationController *nav2 = [[WLZNavigationController alloc]initWithRootViewController:wangDaiVC];
    nav2.tabBarItem.title = @"网贷";
    nav2.tabBarItem.image = [UIImage imageNamed:@"ic_tab_net_loan_normal"];
    nav2.tabBarItem.selectedImage = [UIImage imageOriginalWithName:@"ic_tab_net_loan_pressed"];
    [self addChildViewController:nav2];
    
    
    MineViewController *wangDaiVC2 = [[MineViewController alloc]init];
    WLZNavigationController *nav3 = [[WLZNavigationController alloc]initWithRootViewController:wangDaiVC2];
    nav3.tabBarItem.title = @"我的";
    nav3.tabBarItem.image = [UIImage imageNamed:@"ic_tab_mine_normal"];
    nav3.tabBarItem.selectedImage = [UIImage imageOriginalWithName:@"ic_tab_mine_pressed"];
    [self addChildViewController:nav3];

//    MineViewController *mineVC = [[MineViewController alloc]init];
//    WLZNavigationController *nav4 = [[WLZNavigationController alloc]initWithRootViewController:mineVC];
//    nav4.tabBarItem.title = @"我的";
//    nav4.tabBarItem.image = [UIImage imageNamed:@"homemine"];
//    nav4.tabBarItem.selectedImage = [UIImage imageOriginalWithName:@"homeselmine"];
//    [self addChildViewController:nav4];
    
//    UITabBarController *tabBarVC = [[UITabBarController alloc]init];
//    tabBarVC.viewControllers = @[nav3,nav1,nav2];
    
}

//// 设置tabBar上所有按钮内容
//- (void)setupAllTitleButton
//{
//    // 0:nav
//    UINavigationController *nav = self.childViewControllers[0];
//    nav.tabBarItem.title = @"首页";
//    nav.tabBarItem.image = [UIImage imageNamed:@"travel_plan1"];
//    // 快速生成一个没有渲染图片
//    nav.tabBarItem.selectedImage = [UIImage imageOriginalWithName:@"travel_plan1_press"];
//
//    // 1:行程助手
//    UINavigationController *nav1 = self.childViewControllers[1];
//    nav1.tabBarItem.title = @"行程助手";
//    nav1.tabBarItem.image = [UIImage imageNamed:@"find"];
//    nav1.tabBarItem.selectedImage = [UIImage imageOriginalWithName:@"find_press"];
//
//    // 2.我的
//    UINavigationController *nav2 = self.childViewControllers[2];
//    nav2.tabBarItem.title = @"我的";
//    nav2.tabBarItem.image = [UIImage imageNamed:@"me"];
//    nav2.tabBarItem.selectedImage = [UIImage imageOriginalWithName:@"me_press"];
//
//
//}

- (BOOL)shouldAutorotate
{
    return NO;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
