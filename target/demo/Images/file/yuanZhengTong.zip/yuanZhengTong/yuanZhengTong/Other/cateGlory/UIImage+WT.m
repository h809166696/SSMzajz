//
//  UIImage+WT.m
//  WTSDK
//
//  Created by 张威庭 on 15/12/16.
//  Copyright © 2015年 zwt. All rights reserved.
//

#import "UIImage+WT.h"
#import <AssetsLibrary/AssetsLibrary.h>
#import <objc/runtime.h>
@implementation UIImage (WT)

/**
 *  截屏吧 截部分视图也行
 */
+ (UIImage *)captureWithView:(UIView *)view {
    UIGraphicsBeginImageContextWithOptions(view.bounds.size, view.opaque, [UIScreen mainScreen].scale);
    
    // IOS7及其后续版本
    if ([self respondsToSelector:@selector(drawViewHierarchyInRect:afterScreenUpdates:)]) {
        NSInvocation *invocation = [NSInvocation invocationWithMethodSignature:
                                    [self methodSignatureForSelector:
                                     @selector(drawViewHierarchyInRect:afterScreenUpdates:)]];
        [invocation setTarget:self];
        [invocation setSelector:@selector(drawViewHierarchyInRect:afterScreenUpdates:)];
        CGRect arg2 = view.bounds;
        BOOL arg3 = YES;
        [invocation setArgument:&arg2 atIndex:2];
        [invocation setArgument:&arg3 atIndex:3];
        [invocation invoke];
    } else { // IOS7之前的版本
        [view.layer renderInContext:UIGraphicsGetCurrentContext()];
    }
    
    UIImage *screenshot = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return screenshot;
}

- (UIImage *)imageFromImage:(UIImage *)image inRect:(CGRect)rect {
    CGImageRef sourceImageRef = [image CGImage];
    CGImageRef newImageRef = CGImageCreateWithImageInRect(sourceImageRef, rect);
    UIImage *newImage = [UIImage imageWithCGImage:newImageRef];
    //    CGImageRelease(sourceImageRef);
    CGImageRelease(newImageRef);
    return newImage;
}

/**
 *  纯色图片
 */
+ (UIImage *)coloreImage:(UIColor *)color size:(CGSize)size {
    CGRect rect = (CGRect){{0.0f, 0.0f}, size};
    //开启一个图形上下文
    UIGraphicsBeginImageContextWithOptions(rect.size, NO, 0.0f);
    //获取图形上下文
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, color.CGColor);
    CGContextFillRect(context, rect);
    //获取图像
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    //关闭上下文
    UIGraphicsEndImageContext();
    return image;
}

+ (UIImage *)coloreImage:(UIColor *)color {
    CGSize size = CGSizeMake(1.0f, 1.0f);
    return [self coloreImage:color size:size];
}

/**
 *  按比例 重设图片大小
 */
- (UIImage *)resize_Rate:(CGFloat)rate {
    return [self resize_Quality:kCGInterpolationNone Rate:rate];
}
/**
 *  按比例 质量 重设图片大小
 */
- (UIImage *)resize_Quality:(CGInterpolationQuality)quality Rate:(CGFloat)rate {
    UIImage *resized = nil;
    CGFloat width = self.size.width * rate;
    CGFloat height = self.size.height * rate;
    
    UIGraphicsBeginImageContext(CGSizeMake(width, height));
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetInterpolationQuality(context, quality);
    [self drawInRect:CGRectMake(0, 0, width, height)];
    resized = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return resized;
}

- (UIImage *)allowMaxImg {
    return [self allowMaxImg_thum:NO];
}

/**
 *  按最大比例压缩图片
 */
- (UIImage *)allowMaxImg_thum:(BOOL)thumbnail {
    if (self == nil) {
        return nil;
    }
    CGFloat height = self.size.height;
    CGFloat width = self.size.width;
    CGFloat Max_H_W = 800; //要显示的图片 我能容忍的 最大长或宽（800）
    if (thumbnail) {
        Max_H_W = 150; //thumbnail（缩略图时） 最大长或宽
    }
    if ((MAX(height, width)) < (Max_H_W)) {
        return self; //不需要再改了
    }
    if (MAX(height, width) > Max_H_W) { //超过了限制 按比例压缩长宽
        CGFloat Max = MAX(height, width);
        height = height * (Max_H_W / Max);
        width = width * (Max_H_W / Max);
    }
    UIImage *newimage;
    UIGraphicsBeginImageContext(CGSizeMake((int) width, (int) height));
    [self drawInRect:CGRectMake(0, 0, (int) width, (int) height)];
    newimage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return newimage;
}

//图片要求的最大长宽
- (CGSize)reSetMaxWH:(CGFloat)WH {
    if (self == nil) {
        return CGSizeZero;
    }
    CGFloat height = self.size.height / self.scale;
    CGFloat width = self.size.width / self.scale;
    CGFloat Max_H_W = WH; //要显示的图片 我能容忍的 最大长或宽（）
    if ((MAX(height, width)) < (Max_H_W)) {
        return self.size; //不需要再改了
    }
    if (MAX(height, width) > Max_H_W) { //超过了限制 按比例压缩长宽
        CGFloat Max = MAX(height, width);
        height = height * (Max_H_W / Max);
        width = width * (Max_H_W / Max);
    }
    return CGSizeMake(width, height);
}

#pragma mark -

/**
 *  保存到指定相册名字
 */
- (void)savedToAlbum_AlbumName:(NSString *)AlbumName sucBlack:(void (^)())completeBlock failBlock:(void (^)())failBlock {
    ALAssetsLibrary *ass = [[ALAssetsLibrary alloc] init];
    [ass writeImageToSavedPhotosAlbum:self.CGImage orientation:(ALAssetOrientation) self.imageOrientation completionBlock:^(NSURL *assetURL, NSError *error) {
        __block BOOL albumWasFound = NO;
        ALAssetsLibrary *assetsLibrary = [[ALAssetsLibrary alloc] init];
        //search all photo albums in the library
        [assetsLibrary enumerateGroupsWithTypes:ALAssetsGroupAlbum usingBlock:^(ALAssetsGroup *group, BOOL *stop) {
            //判断相册是否存在
            if ([AlbumName compare:[group valueForProperty:ALAssetsGroupPropertyName]] == NSOrderedSame) {
                //存在
                albumWasFound = YES;
                [assetsLibrary assetForURL:assetURL resultBlock:^(ALAsset *asset) {
                    if ([group addAsset:asset]) {
                        completeBlock();
                    }
                }
                              failureBlock:^(NSError *error) {
                                  failBlock();
                              }];
                return;
            }
            //如果不存在该相册创建
            if (group == nil && albumWasFound == NO) {
                __weak ALAssetsLibrary *weakSelf = assetsLibrary;
                //创建相册
                [assetsLibrary addAssetsGroupAlbumWithName:AlbumName resultBlock:^(ALAssetsGroup *group) {
                    [weakSelf assetForURL:assetURL
                              resultBlock:^(ALAsset *asset) {
                                  if ([group addAsset:asset]) {
                                      completeBlock();
                                  }
                              }
                             failureBlock:^(NSError *error) {
                                 failBlock();
                             }];
                }
                                              failureBlock:^(NSError *error) {
                                                  failBlock();
                                              }];
                return;
            }
        }
                                   failureBlock:^(NSError *error) {
                                       failBlock();
                                   }];
    }];
}

/**
 *  保存相册
 *
 *  @param completeBlock 成功回调
 *  @param completeBlock 出错回调
 */
- (void)savedToAlbum:(void (^)())completeBlock failBlock:(void (^)())failBlock {
    UIImageWriteToSavedPhotosAlbum(self, self, @selector(image:didFinishSavingWithError:contextInfo:), NULL);
    self.completeBlock = completeBlock;
    self.failBlock = failBlock;
}

- (void)image:(UIImage *)image didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo {
    if (error == nil) {
        if (self.completeBlock != nil) self.completeBlock();
    } else {
        if (self.failBlock != nil) self.failBlock();
    }
}

/*
 *  模拟成员变量
 */
- (void (^)())failBlock {
    return objc_getAssociatedObject(self, failBlockKey);
}
- (void)setfailBlock:(void (^)())failBlock {
    objc_setAssociatedObject(self, failBlockKey, failBlock, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}
- (void (^)())completeBlock {
    return objc_getAssociatedObject(self, completeBlockKey);
}

- (void)setcompleteBlock:(void (^)())completeBlock {
    objc_setAssociatedObject(self, completeBlockKey, completeBlock, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

#pragma mark - function😇

/**
 *  加水印
 */
- (UIImage *)waterWithText:(NSString *)text direction:(ImageWaterDirect)direction fontColor:(UIColor *)fontColor fontPoint:(CGFloat)fontPoint marginXY:(CGPoint)marginXY {
    CGSize size = self.size;
    CGRect rect = (CGRect){CGPointZero, size};
    //新建图片图形上下文
    UIGraphicsBeginImageContextWithOptions(size, NO, 0.0f);
    //绘制图片
    [self drawInRect:rect];
    //绘制文本
    NSDictionary *attr = @{NSFontAttributeName : [UIFont systemFontOfSize:fontPoint], NSForegroundColorAttributeName : fontColor};
    CGRect strRect = [self calWidth:text attr:attr direction:direction rect:rect marginXY:marginXY];
    [text drawInRect:strRect withAttributes:attr];
    //获取图片
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    //结束图片图形上下文
    UIGraphicsEndImageContext();
    return newImage;
}

- (CGRect)calWidth:(NSString *)str attr:(NSDictionary *)attr direction:(ImageWaterDirect)direction rect:(CGRect)rect marginXY:(CGPoint)marginXY {
    CGSize size = [str sizeWithAttributes:attr];
    CGRect calRect = [self rectWithRect:rect size:size direction:direction marginXY:marginXY];
    return calRect;
}

- (CGRect)rectWithRect:(CGRect)rect size:(CGSize)size direction:(ImageWaterDirect)direction marginXY:(CGPoint)marginXY {
    CGPoint point = CGPointZero;
    //右上
    if (ImageWaterDirectTopRight == direction) point = CGPointMake(rect.size.width - size.width, 0);
    //左下
    if (ImageWaterDirectBottomLeft == direction) point = CGPointMake(0, rect.size.height - size.height);
    //右下
    if (ImageWaterDirectBottomRight == direction) point = CGPointMake(rect.size.width - size.width, rect.size.height - size.height);
    //正中
    if (ImageWaterDirectCenter == direction) point = CGPointMake((rect.size.width - size.width) * .5f, (rect.size.height - size.height) * .5f);
    point.x += marginXY.x;
    point.y += marginXY.y;
    CGRect calRect = (CGRect){point, size};
    return calRect;
}

/**
 *  加水印
 */
- (UIImage *)waterWithWaterImage:(UIImage *)waterImage direction:(ImageWaterDirect)direction waterSize:(CGSize)waterSize marginXY:(CGPoint)marginXY {
    CGSize size = self.size;
    CGRect rect = (CGRect){CGPointZero, size};
    //新建图片图形上下文
    UIGraphicsBeginImageContextWithOptions(size, NO, 0.0f);
    //绘制图片
    [self drawInRect:rect];
    //计算水印的rect
    CGSize waterImageSize = CGSizeEqualToSize(waterSize, CGSizeZero) ? waterImage.size : waterSize;
    CGRect calRect = [self rectWithRect:rect size:waterImageSize direction:direction marginXY:marginXY];
    //绘制水印图片
    [waterImage drawInRect:calRect];
    //获取图片
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    //结束图片图形上下文
    UIGraphicsEndImageContext();
    
    return newImage;
}

- (UIImage *)fixOrientation {
    
    // No-op if the orientation is already correct
    if (self.imageOrientation == UIImageOrientationUp) return self;
    
    // We need to calculate the proper transformation to make the image upright.
    // We do it in 2 steps: Rotate if Left/Right/Down, and then flip if Mirrored.
    CGAffineTransform transform = CGAffineTransformIdentity;
    
    switch (self.imageOrientation) {
        case UIImageOrientationDown:
        case UIImageOrientationDownMirrored:
            transform = CGAffineTransformTranslate(transform, self.size.width, self.size.height);
            transform = CGAffineTransformRotate(transform, M_PI);
            break;
            
        case UIImageOrientationLeft:
        case UIImageOrientationLeftMirrored:
            transform = CGAffineTransformTranslate(transform, self.size.width, 0);
            transform = CGAffineTransformRotate(transform, M_PI_2);
            break;
            
        case UIImageOrientationRight:
        case UIImageOrientationRightMirrored:
            transform = CGAffineTransformTranslate(transform, 0, self.size.height);
            transform = CGAffineTransformRotate(transform, -M_PI_2);
            break;
        case UIImageOrientationUp:
        case UIImageOrientationUpMirrored:
            break;
    }
    
    switch (self.imageOrientation) {
        case UIImageOrientationUpMirrored:
        case UIImageOrientationDownMirrored:
            transform = CGAffineTransformTranslate(transform, self.size.width, 0);
            transform = CGAffineTransformScale(transform, -1, 1);
            break;
            
        case UIImageOrientationLeftMirrored:
        case UIImageOrientationRightMirrored:
            transform = CGAffineTransformTranslate(transform, self.size.height, 0);
            transform = CGAffineTransformScale(transform, -1, 1);
            break;
        case UIImageOrientationUp:
        case UIImageOrientationDown:
        case UIImageOrientationLeft:
        case UIImageOrientationRight:
            break;
    }
    
    // Now we draw the underlying CGImage into a new context, applying the transform
    // calculated above.
    CGContextRef ctx = CGBitmapContextCreate(NULL, self.size.width, self.size.height,
                                             CGImageGetBitsPerComponent(self.CGImage), 0,
                                             CGImageGetColorSpace(self.CGImage),
                                             CGImageGetBitmapInfo(self.CGImage));
    CGContextConcatCTM(ctx, transform);
    switch (self.imageOrientation) {
        case UIImageOrientationLeft:
        case UIImageOrientationLeftMirrored:
        case UIImageOrientationRight:
        case UIImageOrientationRightMirrored:
            // Grr...
            CGContextDrawImage(ctx, CGRectMake(0, 0, self.size.height, self.size.width), self.CGImage);
            break;
            
        default:
            CGContextDrawImage(ctx, CGRectMake(0, 0, self.size.width, self.size.height), self.CGImage);
            break;
    }
    
    // And now we just create a new UIImage from the drawing context
    CGImageRef cgimg = CGBitmapContextCreateImage(ctx);
    UIImage *img = [UIImage imageWithCGImage:cgimg];
    CGContextRelease(ctx);
    CGImageRelease(cgimg);
    return img;
}
#pragma mark --- 图片剪切
+(UIImage*)image:(UIImage*)image forTargetSize: (CGSize)targetSize
{
    
    UIImage*sourceImage = image;
    
    CGSize imageSize = sourceImage.size;//图片的size
    
    CGFloat imageWidth = imageSize.width;//图片宽度
    
    CGFloat imageHeight = imageSize.height;//图片高度
    
    NSInteger judge = 0;//声明一个判断属性
    
    //判断是否需要调整尺寸(这个地方的判断标准又个人决定,在此我是判断高大于宽),因为图片是800*480,所以也可以变成480*800
    
    if((imageHeight - imageWidth) > 0) {
        
        //在这里我将目标尺寸修改成480*800
        
        CGFloat tempW = targetSize.width;
        
        CGFloat tempH = targetSize.height;
        
        targetSize.height= tempW;
        
        targetSize.width= tempH;
        
    }
    
    CGFloat targetWidth = targetSize.width;//获取最终的目标宽度尺寸
    
    CGFloat targetHeight = targetSize.height;//获取最终的目标高度尺寸
    
    CGFloat scaleFactor = 0.0 ;//先声明拉伸的系数
    
    CGFloat scaledWidth = targetWidth;
    
    CGFloat scaledHeight = targetHeight;
    
    CGPoint thumbnailPoint =CGPointMake(0.0,0.0);//这个是图片剪切的起点位置
    
    //第一个判断,图片大小宽跟高都小于目标尺寸,直接返回image
    
//    if( imageHeight < targetHeight && imageWidth < targetWidth) {
//        
//        return image;
//        
//    }
    
    CGFloat widthFactor = targetWidth / imageWidth;  //这里是目标宽度除以图片宽度
    
    CGFloat heightFactor = targetHeight / imageHeight; //这里是目标高度除以图片高度
    
    //分四种情况,
    
    //第一种,widthFactor,heightFactor都小于1,也就是图片宽度跟高度都比目标图片大,要缩小
    
    if(widthFactor <1 && heightFactor<1){
        
        //第一种,需要判断要缩小哪一个尺寸,这里看拉伸尺度,我们的scale在小于1的情况下,谁越小,等下就用原图的宽度高度✖️那一个系数(这里不懂的话,代个数想一下,例如目标800*480  原图1600*800  系数就采用宽度系数widthFactor = 1/2  )
        
        if(widthFactor > heightFactor){
            
            judge =1;//右部分空白
            
            scaleFactor = widthFactor; //修改最后的拉伸系数是高度系数(也就是最后要*这个值)
            
        }
        
        else
            
        {
            
            judge =2;//下部分空白
            
            scaleFactor = widthFactor;
            
        }
        
    }
    
    else if(widthFactor >1 && heightFactor <1){
        
        //第二种,宽度不够比例,高度缩小一点点(widthFactor大于一,说明目标宽度比原图片宽度大,此时只要拉伸高度系数)
        
        judge =3;//下部分空白
        
        //采用高度拉伸比例
        
        scaleFactor = imageWidth / targetWidth;// 计算高度缩小系数
        
    }
    if(heightFactor >1 && widthFactor <1){
        
        //第三种,高度不够比例,宽度缩小一点点(heightFactor大于一,说明目标高度比原图片高度大,此时只要拉伸宽度系数)
        
        judge =4;//下边空白
        
        //采用高度拉伸比例
        
        scaleFactor = imageHeight / targetWidth;
        
    }else{
        
        //第四种,此时宽度高度都小于目标尺寸,不必要处理放大(如果有处理放大的,在这里写).
        
    }
    
    scaledWidth= imageWidth * scaleFactor;
    
    scaledHeight = imageHeight * scaleFactor;
    
    if(judge == 1){
        
        //右部分空白
        
        targetWidth = scaledWidth;//此时把原来目标剪切的宽度改小,例如原来可能是800,现在改成780
        
    }else if(judge ==2){
        
        //下部分空白
        
        targetHeight = scaledHeight;
        
    }else if(judge ==3){
        
        //第三种,高度不够比例,宽度缩小一点点
        
        targetWidth  = scaledWidth;
        
    }else{
        
        //第三种,高度不够比例,宽度缩小一点点
        
        targetHeight= scaledHeight;
        
    }
    
    UIGraphicsBeginImageContext(targetSize);//开始剪切
    
    CGRect thumbnailRect =CGRectZero;//剪切起点(0,0)
    
    thumbnailRect.origin= thumbnailPoint;
    
    thumbnailRect.size.width= scaledWidth;
    
    thumbnailRect.size.height= scaledHeight;
    
    [sourceImage drawInRect:thumbnailRect];
    
    UIImage*newImage =UIGraphicsGetImageFromCurrentImageContext();//截图拿到图片
    
    return newImage;
    
}
#pragma mark --- 图片压缩
+(UIImage *)compressImageWith:(UIImage *)image

{
    
    float imageWidth = image.size.width;
    
    float imageHeight = image.size.height;
    
    float width = SCREEN_WIDTH/4;
    
    float height = image.size.height/(image.size.width/width);
    
    float widthScale = imageWidth /width;
    
    float heightScale = imageHeight /height;
    
    // 创建一个bitmap的context
    
    // 并把它设置成为当前正在使用的context
    
    UIGraphicsBeginImageContext(CGSizeMake(width, height));
    
    if (widthScale > heightScale) {
        
        [image drawInRect:CGRectMake(0, 0, imageWidth /heightScale , height)];
        
    }
    
    else {
        
        [image drawInRect:CGRectMake(0, 0, width , imageHeight /widthScale)];
        
    }
    
    // 从当前context中创建一个改变大小后的图片
    
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    
    // 使当前的context出堆栈
    
    UIGraphicsEndImageContext();
    
    return newImage;
    
}
@end
