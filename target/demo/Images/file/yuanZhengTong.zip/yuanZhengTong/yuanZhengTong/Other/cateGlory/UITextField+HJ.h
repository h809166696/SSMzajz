//
//  UITextField+HJ.h
//  TravelAssistant
//
//  Created by h809166696 on 2017/6/6.
//  Copyright © 2017年 hj. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITextField (HJ)
typedef NS_ENUM(NSUInteger,HJTextFieldholderStyle)
{
    //placeholder在左边
  HJTextFieldholderStyleLeft = 0,
    //居中
  HJTextFieldholderStyleCenter
};
//设置输入框左边图片和距左边距离
-(void)setTextFiledLeftImage:(NSString*)image margin:(CGFloat)margin;
-(void)setTextFieldImgAndMargin:(NSString*)image marginleft:(CGFloat)marginleft marginRight:(CGFloat)marginRight;
//设置背景文字和颜色
-(void)setPlaceHolderTextColor:(UIColor *)color holderFont:(UIFont *)font placeholderStyle:(HJTextFieldholderStyle)HJstyle placeHolder:(NSString *)placeholder;
//-(void)hj_setTextFiledplaceholderColor:(UIColor *)color focusColor:(UIColor *)focusColor;
@end
