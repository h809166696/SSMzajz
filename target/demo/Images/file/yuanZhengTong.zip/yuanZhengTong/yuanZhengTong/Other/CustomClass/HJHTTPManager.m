//
//  HJHTTPManager.m
//  HJHTTPManager
//
//  Created by h809166696 on 2016/12/5.
//  Copyright © 2016年 hj. All rights reserved.
//

#import "HJHTTPManager.h"
#import "AFHTTPSessionManager.h"
//#import "AFNetworkReachabilityManager.h"
#import "AFNetworkActivityIndicatorManager.h"
@implementation HJHTTPManager
static HJHTTPManager *httpClient;

+ (instancetype)share
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        httpClient = [[self alloc]init];
    });
    return httpClient;
}


static AFHTTPSessionManager *magager;

+ (AFHTTPSessionManager *)sharedAFManager
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        magager = [AFHTTPSessionManager manager];
        magager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/json", @"text/javascript", @"text/html", @"text/xml", @"text/plain", nil];
        // 设置超时时间
        magager.requestSerializer = [AFHTTPRequestSerializer serializer];
        magager.responseSerializer = [AFHTTPResponseSerializer serializer];
        magager.requestSerializer.timeoutInterval = HTTP_TIMEOUT;
    });
    return magager;
}

+ (void)requestWithType:(SkyHttpRequestType)type
              UrlString:(NSString *)urlString
             Parameters:(NSDictionary *)parameters
           SuccessBlock:(SkyHTTPRequestSuccessBlock)successBlock
           FailureBlock:(SkyHTTPRequestFailedBlock)failureBlock
{
    if (urlString == nil)
    {
        return;
    }
    NSString *URLString = [urlString stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
    if (type == SkyHttpRequestTypeGet)
    {
        
        [[self sharedAFManager] GET:URLString parameters:parameters progress:^(NSProgress * _Nonnull downloadProgress) {
            
        } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            
            if (successBlock)
            {
//                NSStringEncoding encoding = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
//                NSString *str= [[NSString alloc] initWithData:responseObject encoding:encoding];

                NSString *str = [[NSString alloc]initWithData:responseObject encoding:NSUTF8StringEncoding];
                //过滤无用字符
                str = [str filtrationStringWithDeleteStringArray:@[@"\r\n",@"\n",@"\t"]];

                successBlock(str); 


            }
            
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            
            if (error.code !=-999) {
                if (failureBlock)
                {
                    failureBlock(error);
                }
            }
            else{
                NSLog(@"取消队列了");
            }
        }];
        
    }else if (type == SkyHttpRequestTypePost)
    {
        
        [[self sharedAFManager] POST:URLString parameters:parameters progress:^(NSProgress * _Nonnull uploadProgress) {
            
        } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            
            if (successBlock)
            {
                successBlock(responseObject);
            }
            
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            
            if (error.code !=-999) {
                if (failureBlock)
                {
                    failureBlock(error);
                }
            }
            else{
                NSLog(@"取消队列了");
            }
            
        }];
    }
}
+ (void)uploadImageUrlString:(NSString *)urlString
         Parameters:(NSDictionary *)parameters image:(UIImage *)image
       SuccessBlock:(SkyHTTPRequestSuccessBlock)successBlock
       FailureBlock:(SkyHTTPRequestFailedBlock)failureBlock{
    [[self sharedAFManager] POST:urlString parameters:parameters constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        //根据当前系统时间生成图片名称
        NSDate *date = [NSDate date];
        NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
        [formatter setDateFormat:@"yyyyMMddHHMMSS"];
        
        NSString *dateString = [formatter stringFromDate:date];
        
        NSString *fileName = [NSString stringWithFormat:@"%@%d.png",dateString,arc4random()%10];
        UIImage *image1 = image;
        fileName = @"avatar.jpg";
        NSData *imageData = UIImageJPEGRepresentation(image1, 1);
     
        [formData appendPartWithFileData:imageData name:[NSString stringWithFormat:@"%d",arc4random()%10] fileName:fileName  mimeType:@"image/jpg/png/jpeg"];
   
        
    } progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
    
        successBlock(responseObject);
 
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        failureBlock(error);
    }];
}
+ (void)startNetWorkMonitoring
{
    AFNetworkReachabilityManager *manager = [AFNetworkReachabilityManager sharedManager];
    [AFNetworkActivityIndicatorManager sharedManager].enabled = YES;
    [manager setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        switch (status)
        {
            case AFNetworkReachabilityStatusUnknown: // 未知网络
//                NSLog(@"未知网络");
                HJ_NetWork.netWorkStatus = SkyNetworkStatusUnknown;
              HJ_NetWork.netWorkState = @"0";
                break;
            case AFNetworkReachabilityStatusNotReachable: // 没有网络(断网)
//                NSLog(@"没有网络");
                HJ_NetWork.netWorkStatus = SkyNetworkStatusNotReachable;
               HJ_NetWork.netWorkState = @"1";
                break;
            case AFNetworkReachabilityStatusReachableViaWWAN: // 2G/3G/4G
//                NSLog(@"手机自带网络");
                HJ_NetWork.netWorkStatus = SkyNetworkStatusReachableViaWWAN;
               HJ_NetWork.netWorkState = @"2";
                break;
            case AFNetworkReachabilityStatusReachableViaWiFi: // WIFI
                HJ_NetWork.netWorkStatus = SkyNetworkStatusReachableViaWiFi;
                 HJ_NetWork.netWorkState = @"3";
//                NSLog(@"WIFI--%lu", (unsigned long)HJ_NetWork.netWorkStatus);
                break;
        }
    }];
    [manager startMonitoring];
}
+(void)cancelDataTask
{
    NSMutableArray *dataTasks = [NSMutableArray arrayWithArray:[self sharedAFManager].dataTasks];
    for (NSURLSessionDataTask *taskObj in dataTasks) {
        [taskObj cancel];
    }
}
+ (void)cancleAllTask
{
    [magager.operationQueue cancelAllOperations];
}
@end
