//
//  HJSearchBar.h
//  HitstorySchoolUnion
//
//  Created by h809166696 on 2016/12/18.
//  Copyright © 2016年 hj. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HJSearchBar : UITextField

@end
