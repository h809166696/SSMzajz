//
//  UIImage+WLZImage.h
//  WenHuaLvYou
//
//  Created by 颜培灯 on 16/8/15.
//  Copyright © 2016年 颜培灯. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (WLZImage)
/**
 * 圆形图片
 */
- (UIImage *)circleImage;
+ (instancetype)imageOriginalWithName:(NSString *)imageName;
/*
 * 图片裁剪，适用于圆形头像之类
 */
+ (UIImage *)imageWithClipImage:(UIImage *)image borderWidth:(CGFloat)borderWidth borderColor:(UIColor *)color;
/*
 * 根据颜色生成图片
 */
+ (UIImage *)imageWithColor:(UIColor *)color size:(CGSize)size;
//修改大小的属性
- (UIImage *)imageByScalingToSize:(CGSize)targetSize;
@end
