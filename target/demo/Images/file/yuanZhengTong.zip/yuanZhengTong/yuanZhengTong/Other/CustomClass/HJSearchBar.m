//
//  HJSearchBar.m
//  HitstorySchoolUnion
//
//  Created by h809166696 on 2016/12/18.
//  Copyright © 2016年 hj. All rights reserved.
//

#import "HJSearchBar.h"

@implementation HJSearchBar
-(instancetype)init{
    if (self = [super init]) {
//        self.frame = frame;
        self.font = [UIFont systemFontOfSize:12];
        self.placeholder = @"请输入您要搜索的目的地";
        
        // 提前在Xcode上设置图片中间拉伸
//        self.background = [UIImage imageNamed:@"searchbar_textfield_background"];
        self.backgroundColor = [UIColor whiteColor];
        // 通过init初始化的控件大多都没有尺寸
        UIImageView *searchIcon = [[UIImageView alloc] init];
        searchIcon.image = [UIImage imageNamed:@"newsearch"];
        // contentMode：default is UIViewContentModeScaleToFill，要设置为UIViewContentModeCenter：使图片居中，防止图片填充整个imageView
        searchIcon.contentMode = UIViewContentModeCenter;
        searchIcon.size = CGSizeMake(21, 21);
        
        self.leftView = searchIcon;
        self.leftViewMode = UITextFieldViewModeAlways;
    }
    return self;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
