//
//  UIView+HJ.h
//  TravelAssistant
//
//  Created by h809166696 on 2017/10/17.
//  Copyright © 2017年 hj. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (HJ)
/**
 **同时设置圆角和阴影
 **/
-(void)hj_setRadiusAndShadow:(UIView *)parentView Frame:(CGRect)rect Radius:(CGFloat)radius borderWidth:(CGFloat)borderWidth borderColor:(UIColor *)color shadowOpacity:(CGFloat)shadowOpacity shadowColor:(UIColor *)shadowColor shadowOffset:(CGSize)shadowOffset shadowRadius:(CGFloat)shadowRadius;
-(void)hj_setRadiusAndShadow2:(UIView *)parentView center:(CGPoint)frameCenter bounds:(CGRect)frameBounds Radius:(CGFloat)radius borderWidth:(CGFloat)borderWidth borderColor:(UIColor *)color shadowOpacity:(CGFloat)shadowOpacity shadowColor:(UIColor *)shadowColor shadowOffset:(CGSize)shadowOffset shadowRadius:(CGFloat)shadowRadius;
@end
